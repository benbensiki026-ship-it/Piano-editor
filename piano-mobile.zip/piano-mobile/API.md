# 🎹 Mobile Piano API Documentation

## Table of Contents
1. [Core Classes](#core-classes)
2. [Data Structures](#data-structures)
3. [API Reference](#api-reference)
4. [Platform-Specific APIs](#platform-specific-apis)
5. [Code Examples](#code-examples)

## Core Classes

### MobilePiano
Main piano engine class providing all core functionality.

```cpp
class MobilePiano {
public:
    MobilePiano();
    ~MobilePiano();
    
    // Initialization
    bool initialize(int screenWidth, int screenHeight);
    void shutdown();
    
    // Touch/Key control
    void handleTouchEvent(const TouchEvent& event);
    void pressKey(int keyNumber, int velocity);
    void releaseKey(int keyNumber);
    
    // Recording
    void startRecording();
    void stopRecording();
    bool saveRecording(const std::string& filename);
    
    // Settings
    void setTranspose(int semitones);
    void setMasterVolume(float volume);
    void toggleSustain();
    
    // Metronome
    void startMetronome(int bpm, int beatsPerBar = 4);
    void stopMetronome();
    
    // State queries
    bool isKeyPressed(int keyNumber) const;
    std::vector<int> getPressedKeys() const;
    bool getIsRecording() const;
    int getRecordedEventCount() const;
};
```

## Data Structures

### PianoKey
Represents a single piano key.

```cpp
struct PianoKey {
    int keyNumber;        // 1-88
    int midiNote;         // 21-108 (A0 to C8)
    double frequency;     // Frequency in Hz
    std::string noteName; // "C4", "A#5", etc.
    bool isBlack;         // Black or white key
    bool isPressed;       // Currently being played
    double pressTime;     // Timestamp when pressed
    int velocity;         // Touch velocity (0-127)
    float x, y;           // Touch coordinates
    float width, height;  // Key dimensions
};
```

### TouchEvent
Multi-touch event data.

```cpp
struct TouchEvent {
    int id;               // Touch ID for multi-touch tracking
    float x, y;           // Touch coordinates
    enum Type { DOWN, MOVE, UP } type;
    double timestamp;     // Event timestamp
    float pressure;       // Touch pressure (0.0 to 1.0)
};
```

### MidiEvent
MIDI recording event.

```cpp
struct MidiEvent {
    double time;          // Time in seconds
    int note;             // MIDI note number (0-127)
    int velocity;         // Note velocity (0-127)
    bool isNoteOn;        // Note on/off event
    int channel;          // MIDI channel (0-15)
};
```

### SoundPreset
Sound/instrument preset.

```cpp
struct SoundPreset {
    std::string name;           // Preset name
    std::string description;    // Description
    std::vector<KeySample> samples;
    float volume;               // Preset volume
    float attack;               // ADSR attack time
    float decay;                // ADSR decay time
    float sustain;              // ADSR sustain level
    float release;              // ADSR release time
};
```

### PianoSettings
Configuration settings.

```cpp
struct PianoSettings {
    bool showKeyLabels;         // Display note names
    bool enableVibration;       // Haptic feedback
    bool enableSustain;         // Sustain pedal
    bool enableMetronome;       // Metronome on/off
    int transpose;              // Transpose amount (-12 to +12)
    float masterVolume;         // Master volume (0.0 to 1.0)
    int sensitivity;            // Touch sensitivity (1-10)
    bool multiTouch;            // Multi-touch support
    int maxPolyphony;           // Max simultaneous notes
    std::string theme;          // UI theme name
};
```

## API Reference

### Initialization

#### initialize()
```cpp
bool initialize(int screenWidth, int screenHeight);
```
Initialize the piano engine with screen dimensions.

**Parameters:**
- `screenWidth`: Screen width in pixels
- `screenHeight`: Screen height in pixels

**Returns:** `true` on success, `false` on failure

**Example:**
```cpp
MobilePiano piano;
if (piano.initialize(1080, 2400)) {
    // Successfully initialized
}
```

#### shutdown()
```cpp
void shutdown();
```
Clean up and release all resources.

### Touch Handling

#### handleTouchEvent()
```cpp
void handleTouchEvent(const TouchEvent& event);
```
Process a single touch event.

**Parameters:**
- `event`: Touch event data

**Example:**
```cpp
TouchEvent event;
event.id = 0;
event.x = 540.0f;
event.y = 2000.0f;
event.type = TouchEvent::DOWN;
event.pressure = 0.8f;
piano.handleTouchEvent(event);
```

#### handleMultiTouch()
```cpp
void handleMultiTouch(const std::vector<TouchEvent>& events);
```
Process multiple simultaneous touch events.

**Parameters:**
- `events`: Vector of touch events

### Key Control

#### pressKey()
```cpp
void pressKey(int keyNumber, int velocity);
```
Trigger a key press programmatically.

**Parameters:**
- `keyNumber`: Key number (1-88)
- `velocity`: Note velocity (1-127)

**Example:**
```cpp
// Play middle C with medium velocity
piano.pressKey(40, 80);
```

#### releaseKey()
```cpp
void releaseKey(int keyNumber);
```
Release a pressed key.

**Parameters:**
- `keyNumber`: Key number (1-88)

#### releaseAllKeys()
```cpp
void releaseAllKeys();
```
Release all currently pressed keys.

### MIDI Control

#### playMidiNote()
```cpp
void playMidiNote(int midiNote, int velocity, int channel = 0);
```
Play a MIDI note directly.

**Parameters:**
- `midiNote`: MIDI note number (0-127)
- `velocity`: Note velocity (1-127)
- `channel`: MIDI channel (0-15)

#### stopMidiNote()
```cpp
void stopMidiNote(int midiNote, int channel = 0);
```
Stop a playing MIDI note.

**Parameters:**
- `midiNote`: MIDI note number (0-127)
- `channel`: MIDI channel (0-15)

### Recording

#### startRecording()
```cpp
void startRecording();
```
Begin recording performance.

#### stopRecording()
```cpp
void stopRecording();
```
Stop recording performance.

#### pauseRecording()
```cpp
void pauseRecording();
```
Pause current recording.

#### resumeRecording()
```cpp
void resumeRecording();
```
Resume paused recording.

#### saveRecording()
```cpp
bool saveRecording(const std::string& filename);
```
Save recording to MIDI file.

**Parameters:**
- `filename`: Output filename

**Returns:** `true` on success, `false` on failure

**Example:**
```cpp
piano.startRecording();
// ... play notes ...
piano.stopRecording();
if (piano.saveRecording("my_song.mid")) {
    // Successfully saved
}
```

### MIDI File Operations

#### loadMidiFile()
```cpp
bool loadMidiFile(const std::string& filename);
```
Load a MIDI file for playback.

**Parameters:**
- `filename`: MIDI file path

**Returns:** `true` on success, `false` on failure

#### playRecording()
```cpp
void playRecording();
```
Play loaded or recorded MIDI sequence.

#### stopPlayback()
```cpp
void stopPlayback();
```
Stop MIDI playback.

### Sound Presets

#### loadSoundPreset()
```cpp
void loadSoundPreset(int presetIndex);
```
Load a sound preset.

**Parameters:**
- `presetIndex`: Preset index (0 to getPresetCount()-1)

#### getPresetCount()
```cpp
int getPresetCount() const;
```
Get number of available presets.

**Returns:** Number of presets

#### getPresetName()
```cpp
std::string getPresetName(int index) const;
```
Get name of preset at index.

**Parameters:**
- `index`: Preset index

**Returns:** Preset name

**Example:**
```cpp
for (int i = 0; i < piano.getPresetCount(); i++) {
    std::cout << i << ": " << piano.getPresetName(i) << std::endl;
}
piano.loadSoundPreset(1); // Load second preset
```

### Settings

#### updateSettings()
```cpp
void updateSettings(const PianoSettings& newSettings);
```
Update piano settings.

**Parameters:**
- `newSettings`: New settings structure

#### setTranspose()
```cpp
void setTranspose(int semitones);
```
Set transpose amount.

**Parameters:**
- `semitones`: Transpose amount (-12 to +12)

#### setMasterVolume()
```cpp
void setMasterVolume(float volume);
```
Set master volume.

**Parameters:**
- `volume`: Volume level (0.0 to 1.0)

#### toggleSustain()
```cpp
void toggleSustain();
```
Toggle sustain pedal on/off.

### Metronome

#### startMetronome()
```cpp
void startMetronome(int bpm, int beatsPerBar = 4);
```
Start metronome.

**Parameters:**
- `bpm`: Beats per minute (40-240)
- `beatsPerBar`: Time signature (default 4)

**Example:**
```cpp
piano.startMetronome(120, 4); // 120 BPM, 4/4 time
```

#### stopMetronome()
```cpp
void stopMetronome();
```
Stop metronome.

#### setMetronomeBPM()
```cpp
void setMetronomeBPM(int bpm);
```
Change metronome tempo.

**Parameters:**
- `bpm`: New tempo (40-240)

### State Queries

#### isKeyPressed()
```cpp
bool isKeyPressed(int keyNumber) const;
```
Check if key is currently pressed.

**Parameters:**
- `keyNumber`: Key number (1-88)

**Returns:** `true` if pressed, `false` otherwise

#### getPressedKeys()
```cpp
std::vector<int> getPressedKeys() const;
```
Get list of currently pressed keys.

**Returns:** Vector of pressed key numbers

#### getIsRecording()
```cpp
bool getIsRecording() const;
```
Check if recording is active.

**Returns:** `true` if recording, `false` otherwise

#### getRecordedEventCount()
```cpp
int getRecordedEventCount() const;
```
Get number of recorded events.

**Returns:** Event count

### Key Information

#### getAllKeys()
```cpp
std::vector<PianoKey> getAllKeys() const;
```
Get information about all 88 keys.

**Returns:** Vector of PianoKey structures

**Example:**
```cpp
auto keys = piano.getAllKeys();
for (const auto& key : keys) {
    std::cout << "Key " << key.keyNumber << ": " 
              << key.noteName << " (" << key.frequency << " Hz)\n";
}
```

#### getVisibleKeys()
```cpp
std::vector<PianoKey> getVisibleKeys(int startKey, int endKey) const;
```
Get keys in a specific range.

**Parameters:**
- `startKey`: First key number
- `endKey`: Last key number

**Returns:** Vector of PianoKey structures

## Platform-Specific APIs

### Android (JNI)

#### Creating Piano Instance
```java
public class PianoEngine {
    private long nativeHandle;
    
    public PianoEngine() {
        nativeHandle = nativeCreate();
    }
    
    private native long nativeCreate();
    
    static {
        System.loadLibrary("mobile-piano");
    }
}
```

#### Touch Handling
```java
public void onTouchEvent(MotionEvent event) {
    int action = event.getActionMasked();
    int pointerIndex = event.getActionIndex();
    int pointerId = event.getPointerId(pointerIndex);
    float x = event.getX(pointerIndex);
    float y = event.getY(pointerIndex);
    float pressure = event.getPressure(pointerIndex);
    
    switch (action) {
        case MotionEvent.ACTION_DOWN:
            nativeTouchDown(nativeHandle, pointerId, x, y, pressure);
            break;
        case MotionEvent.ACTION_MOVE:
            nativeTouchMove(nativeHandle, pointerId, x, y, pressure);
            break;
        case MotionEvent.ACTION_UP:
            nativeTouchUp(nativeHandle, pointerId, x, y);
            break;
    }
}
```

### iOS (Objective-C++)

#### Creating Piano Instance
```objc
@interface PianoViewController : UIViewController
@property (nonatomic, strong) PianoEngineWrapper *pianoEngine;
@end

@implementation PianoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.pianoEngine = [[PianoEngineWrapper alloc] 
        initWithScreenSize:self.view.bounds.size];
}

@end
```

#### Touch Handling
```objc
- (void)touchesBegan:(NSSet<UITouch *> *)touches 
           withEvent:(UIEvent *)event {
    [self.pianoEngine touchesBegan:touches withEvent:event];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches 
           withEvent:(UIEvent *)event {
    [self.pianoEngine touchesMoved:touches withEvent:event];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches 
           withEvent:(UIEvent *)event {
    [self.pianoEngine touchesEnded:touches withEvent:event];
}
```

## Code Examples

### Complete Recording Session
```cpp
MobilePiano piano;
piano.initialize(1080, 2400);

// Configure settings
piano.setMasterVolume(0.8f);
piano.setTranspose(0);

// Start recording
piano.startRecording();

// Play a melody
int melody[] = {40, 42, 44, 45, 47, 49, 51, 52}; // C major scale
for (int note : melody) {
    piano.pressKey(note, 80);
    std::this_thread::sleep_for(std::chrono::milliseconds(400));
    piano.releaseKey(note);
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
}

// Save recording
piano.stopRecording();
piano.saveRecording("c_major_scale.mid");
```

### Multi-Touch Chord Playing
```cpp
std::vector<TouchEvent> events;

// C major chord (C, E, G)
for (int i = 0; i < 3; i++) {
    TouchEvent event;
    event.id = i;
    event.x = 200.0f + (i * 150.0f);
    event.y = 2000.0f;
    event.type = TouchEvent::DOWN;
    event.pressure = 0.7f;
    events.push_back(event);
}

piano.handleMultiTouch(events);
```

### Practice Loop
```cpp
// Load a song
piano.loadMidiFile("song.mid");

// Set to half speed for practice
piano.setPlaybackSpeed(0.5f);

// Loop a difficult section (time in seconds)
piano.enableLoopMode(10.0, 20.0);

// Start playback
piano.playRecording();
```

### Custom Settings
```cpp
PianoSettings settings;
settings.showKeyLabels = true;
settings.enableVibration = true;
settings.enableSustain = false;
settings.transpose = 0;
settings.masterVolume = 0.75f;
settings.sensitivity = 8;
settings.multiTouch = true;
settings.maxPolyphony = 10;
settings.theme = "dark";

piano.updateSettings(settings);
```

## Error Handling

All file operations return boolean values:
```cpp
if (!piano.loadMidiFile("song.mid")) {
    // Handle error - file not found or invalid format
}

if (!piano.saveRecording("output.mid")) {
    // Handle error - unable to write file
}
```

## Best Practices

1. **Initialize once**: Call `initialize()` only once per session
2. **Release keys**: Always release keys when done to prevent hanging notes
3. **Memory management**: Call `shutdown()` before destroying the piano object
4. **Thread safety**: Most operations are not thread-safe; call from main thread
5. **Error checking**: Always check return values from file operations
6. **Performance**: Limit polyphony on older devices to maintain performance

---

For more information, see the [README](README.md) or the example code in `TestMain.cpp`.
