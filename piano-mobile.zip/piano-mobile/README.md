# 🎹 Mobile Piano - 88 Keys

A professional-grade mobile piano application in C++ with SDL2, featuring a full 88-key piano range (A0 to C8) with touch/mouse support, recording capabilities, and MIDI import/export!

## 🌟 Features

### 🎹 Full Piano Keyboard
- **88 Keys** - Complete piano range from A0 (27.5 Hz) to C8 (4186 Hz)
- **52 White Keys** + **36 Black Keys**
- **Touch/Multi-touch Support** - Play multiple notes simultaneously
- **Mouse Support** - Works with mouse clicks and drags
- **Visual Feedback** - Keys highlight when pressed
- **Note Labels** - Display note names on keys

### 🎵 Professional Features
- **Multi-touch Input** - Up to 10 simultaneous touches
- **Touch Slide** - Slide between keys for glissando effects
- **Velocity Sensitivity** - Adjustable key velocity (0-127)
- **Sustain Pedal** - Toggle sustain for held notes
- **Octave Display** - Scientific pitch notation

### 📼 Recording & Playback
- **Real-time Recording** - Capture your performances
- **Multiple Recordings** - Save and manage multiple recordings
- **MIDI Export** - Export recordings to MIDI files
- **MIDI Import** - Load and play MIDI files
- **Timestamp Tracking** - Precise timing for playback

### 🎚️ Controls & Settings
- **Master Volume** - Adjustable from 0-100%
- **Key Velocity** - Control note dynamics
- **Keyboard Scrolling** - Pan across all 88 keys
- **Zoom/Scale** - Adjust key size for comfort
- **Metronome** - Built-in metronome (40-240 BPM)
- **Settings Panel** - Easy configuration

### 📱 Mobile-Optimized UI
- **Responsive Design** - Adapts to any screen size
- **Touch-Friendly Buttons** - Large, easy-to-tap controls
- **Status Display** - Real-time performance info
- **Menu System** - Easy navigation
- **Recording List** - View and manage recordings

## 🚀 Quick Start

### Ubuntu/Debian
```bash
sudo apt-get install libsdl2-dev libsdl2-ttf-dev
make
./mobile-piano
```

### Run with different resolutions
```bash
./mobile-piano 1280 720    # HD
./mobile-piano 1920 1080   # Full HD
./mobile-piano 800 600     # Mobile size
```

## 🎮 Controls

**Top UI Buttons:** MENU | REC | LIST | SET | SUSTAIN | ◄ | ► | ZOOM

**Keyboard:**
- `ESC` - Exit
- `SPACE` - Toggle sustain
- `←/→` - Scroll keyboard
- `↑/↓` - Adjust velocity
- `R` - Toggle recording
- `M` - Open menu

**Touch/Mouse:** Click or touch piano keys to play!

## 📦 Full Documentation

See complete documentation in:
- **README.md** - This file
- **BUILD.md** - Detailed build instructions  
- **FEATURES.md** - Complete feature list
- **ANDROID.md** - Mobile deployment guide

## 🎵 Usage

1. **Play**: Touch or click piano keys
2. **Record**: Tap REC button, play, tap again to stop
3. **Navigate**: Use ◄/► to scroll across 88 keys
4. **Settings**: Adjust volume, velocity, and preferences

## 🏗️ Technical

- **Language**: C++17
- **Graphics**: SDL2 + SDL2_ttf
- **Keys**: 88 (MIDI 21-108, A0-C8)
- **Multi-touch**: Up to 10 simultaneous
- **Platforms**: Linux, Windows, macOS (Android/iOS possible)

---

**Made with ❤️ for musicians!** 🎹✨
