# 🔨 Build Instructions - Mobile Piano

Complete guide for building the Mobile Piano application on different platforms.

## Prerequisites

### Required
- C++ compiler with C++17 support (g++ 7+, clang++ 5+, MSVC 2017+)
- SDL2 2.0.0 or later
- SDL2_ttf 2.0.0 or later
- Make (optional but recommended)

### Optional
- pkg-config (for automatic SDL2 detection)
- Git (for version control)
- Android NDK (for Android builds)

## Platform-Specific Instructions

### 📱 Ubuntu / Debian Linux

#### Install Dependencies
```bash
# Update package list
sudo apt-get update

# Install SDL2 and development tools
sudo apt-get install -y \
    libsdl2-dev \
    libsdl2-ttf-dev \
    g++ \
    make \
    pkg-config

# Install fonts (recommended)
sudo apt-get install fonts-dejavu-core fonts-liberation
```

#### Build
```bash
# Extract the archive
unzip piano-mobile.zip
cd piano-mobile

# Build with Make
make

# Or build manually
g++ -std=c++17 -O2 -o mobile-piano main.cpp MobilePiano.cpp \
    $(pkg-config --cflags --libs sdl2 SDL2_ttf)
```

#### Run
```bash
./mobile-piano

# With custom resolution
./mobile-piano 1280 720
```

### 🔴 Fedora / RHEL / CentOS

#### Install Dependencies
```bash
# Fedora
sudo dnf install SDL2-devel SDL2_ttf-devel gcc-c++ make

# RHEL/CentOS (enable EPEL first)
sudo yum install epel-release
sudo yum install SDL2-devel SDL2_ttf-devel gcc-c++ make
```

#### Build
```bash
make
```

### 🔵 Arch Linux

#### Install Dependencies
```bash
sudo pacman -S sdl2 sdl2_ttf gcc make
```

#### Build
```bash
make
```

### 🍎 macOS

#### Install Dependencies
```bash
# Install Homebrew if not installed
# https://brew.sh

# Install SDL2
brew install sdl2 sdl2_ttf

# Install Xcode Command Line Tools if needed
xcode-select --install
```

#### Build
```bash
make

# Or manually
clang++ -std=c++17 -O2 -o mobile-piano main.cpp MobilePiano.cpp \
    $(pkg-config --cflags --libs sdl2 SDL2_ttf)
```

### 🪟 Windows

#### Option 1: MinGW

1. **Install MinGW-w64**
   - Download from: https://mingw-w64.org/
   - Or use MSYS2: https://www.msys2.org/

2. **Install SDL2**
   ```bash
   # In MSYS2 terminal
   pacman -S mingw-w64-x86_64-SDL2 mingw-w64-x86_64-SDL2_ttf
   ```

3. **Build**
   ```bash
   g++ -std=c++17 -O2 -o mobile-piano.exe main.cpp MobilePiano.cpp \
       -lmingw32 -lSDL2main -lSDL2 -lSDL2_ttf
   ```

#### Option 2: Visual Studio

1. **Install Visual Studio 2019 or later** with C++ support

2. **Install SDL2**
   - Download SDL2 development libraries from: https://www.libsdl.org/
   - Download SDL2_ttf from: https://www.libsdl.org/projects/SDL_ttf/
   - Extract to a known location (e.g., C:\SDL2)

3. **Create Visual Studio Project**
   - New Project → Empty C++ Project
   - Add main.cpp and MobilePiano.cpp
   - Project Properties:
     - C/C++ → General → Additional Include Directories: `C:\SDL2\include`
     - Linker → General → Additional Library Directories: `C:\SDL2\lib\x64`
     - Linker → Input → Additional Dependencies: `SDL2.lib SDL2main.lib SDL2_ttf.lib`

4. **Build and Run**
   - Copy SDL2.dll and SDL2_ttf.dll to output directory
   - Build solution (Ctrl+Shift+B)
   - Run (F5)

#### Option 3: WSL (Windows Subsystem for Linux)

```bash
# In WSL Ubuntu
sudo apt-get install libsdl2-dev libsdl2-ttf-dev g++ make
make

# Run with X server (VcXsrv, Xming)
./mobile-piano
```

## Build Options

### Makefile Targets

```bash
# Build the application
make

# Build and run
make run

# Run with HD resolution
make run-hd          # 1280x720

# Run with Full HD resolution
make run-fullhd      # 1920x1080

# Run with mobile resolution
make run-mobile      # 800x600

# Clean build artifacts
make clean

# Install dependencies (Ubuntu/Debian only)
make install-deps

# Check SDL2 installation
make check-sdl
```

### Manual Build with Different Compilers

#### GCC
```bash
g++ -std=c++17 -Wall -Wextra -O2 -o mobile-piano \
    main.cpp MobilePiano.cpp \
    $(pkg-config --cflags --libs sdl2 SDL2_ttf)
```

#### Clang
```bash
clang++ -std=c++17 -Wall -Wextra -O2 -o mobile-piano \
    main.cpp MobilePiano.cpp \
    $(pkg-config --cflags --libs sdl2 SDL2_ttf)
```

#### Debug Build
```bash
g++ -std=c++17 -Wall -Wextra -g -O0 -o mobile-piano-debug \
    main.cpp MobilePiano.cpp \
    $(pkg-config --cflags --libs sdl2 SDL2_ttf)
```

#### With Address Sanitizer
```bash
g++ -std=c++17 -Wall -Wextra -g -fsanitize=address -o mobile-piano \
    main.cpp MobilePiano.cpp \
    $(pkg-config --cflags --libs sdl2 SDL2_ttf)
```

## Optimization Flags

### For Production
```bash
# Maximum optimization
g++ -std=c++17 -O3 -march=native -flto -o mobile-piano \
    main.cpp MobilePiano.cpp \
    $(pkg-config --cflags --libs sdl2 SDL2_ttf)
```

### For Size
```bash
# Optimize for size
g++ -std=c++17 -Os -s -o mobile-piano \
    main.cpp MobilePiano.cpp \
    $(pkg-config --cflags --libs sdl2 SDL2_ttf)
```

## Cross-Compilation

### For Raspberry Pi (from x86_64 Linux)
```bash
# Install cross-compiler
sudo apt-get install g++-arm-linux-gnueabihf

# Cross-compile
arm-linux-gnueabihf-g++ -std=c++17 -O2 -o mobile-piano-arm \
    main.cpp MobilePiano.cpp \
    -I/usr/include/SDL2 -lSDL2 -lSDL2_ttf
```

### For Windows (from Linux)
```bash
# Install MinGW cross-compiler
sudo apt-get install mingw-w64

# Cross-compile
x86_64-w64-mingw32-g++ -std=c++17 -O2 -o mobile-piano.exe \
    main.cpp MobilePiano.cpp \
    -I/path/to/SDL2/include -L/path/to/SDL2/lib \
    -lmingw32 -lSDL2main -lSDL2 -lSDL2_ttf
```

## Troubleshooting

### "SDL2 not found"
```bash
# Check if SDL2 is installed
pkg-config --modversion sdl2

# Find SDL2 libraries
ldconfig -p | grep SDL2

# If not found, install:
make install-deps  # Ubuntu/Debian
```

### "undefined reference to SDL_*"
```bash
# Make sure to link SDL2 libraries
# Add: -lSDL2 -lSDL2_ttf

# Check library path
export LD_LIBRARY_PATH=/usr/local/lib:$LD_LIBRARY_PATH
```

### "fatal error: SDL.h: No such file or directory"
```bash
# Install development headers
sudo apt-get install libsdl2-dev

# Or specify include path
-I/usr/include/SDL2
```

### "cannot find -lSDL2"
```bash
# Check library installation
dpkg -L libsdl2-dev | grep libSDL2

# Install if missing
sudo apt-get install libsdl2-2.0-0
```

### Font Loading Issues
```bash
# Install common fonts
sudo apt-get install fonts-dejavu-core

# Or specify font path in code
TTF_OpenFont("/path/to/font.ttf", size);
```

## Verification

### Check Build
```bash
# Run with version info
./mobile-piano --version 2>&1 || echo "Build successful!"

# Check dependencies
ldd mobile-piano  # Linux
otool -L mobile-piano  # macOS
```

### Test Run
```bash
# Run in window mode
./mobile-piano 800 600

# Check for errors
echo $?  # Should be 0 on clean exit
```

## Performance Tips

1. **Use release build** (`-O2` or `-O3`)
2. **Enable native optimizations** (`-march=native`)
3. **Use VSync** (already enabled in code)
4. **Close unnecessary applications**
5. **Use appropriate screen resolution**

## Next Steps

After successful build:
1. See [README.md](README.md) for usage instructions
2. Check [FEATURES.md](FEATURES.md) for feature details
3. Try running: `./mobile-piano 1280 720`

---

**Happy Building!** 🔨🎹
