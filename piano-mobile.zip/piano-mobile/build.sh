#!/bin/bash
# Build script for Mobile Piano (88 Keys)
echo "Building Mobile Piano - 88 Keys..."
echo ""
if ! command -v g++ &> /dev/null; then
    echo "Error: g++ not found"
    exit 1
fi
echo "Compiler: $(g++ --version | head -n 1)"
if ! pkg-config --exists sdl2 2>/dev/null; then
    echo "Error: SDL2 not found!"
    echo "Install: sudo apt-get install libsdl2-dev libsdl2-ttf-dev"
    exit 1
fi
echo "SDL2: $(pkg-config --modversion sdl2)"
rm -f *.o mobile-piano 2>/dev/null
echo "Compiling..."
g++ -std=c++17 -O2 $(pkg-config --cflags sdl2 SDL2_ttf) -c MobilePiano.cpp -o MobilePiano.o || exit 1
g++ -std=c++17 -O2 $(pkg-config --cflags sdl2 SDL2_ttf) -c main.cpp -o main.o || exit 1
echo "Linking..."
g++ -o mobile-piano main.o MobilePiano.o $(pkg-config --libs sdl2 SDL2_ttf) || exit 1
echo ""
echo "✓ Build successful! Run with: ./mobile-piano"
