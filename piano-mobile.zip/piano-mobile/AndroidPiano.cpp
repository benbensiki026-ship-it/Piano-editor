#include "AndroidPiano.h"
#include <string>

AndroidPiano::AndroidPiano() 
    : MobilePiano()
    , engineObject(nullptr)
    , engineEngine(nullptr)
    , outputMixObject(nullptr)
    , playerObject(nullptr)
    , playerPlay(nullptr)
    , playerBufferQueue(nullptr)
    , assetManager(nullptr)
    , vibratorObject(nullptr)
    , vibrateMethod(nullptr) {
}

AndroidPiano::~AndroidPiano() {
    shutdownAudioEngine();
}

bool AndroidPiano::initializeAndroid(JNIEnv* env, jobject context, int screenWidth, int screenHeight) {
    if (!initialize(screenWidth, screenHeight)) {
        return false;
    }
    
    // Get vibrator service
    jclass contextClass = env->GetObjectClass(context);
    jmethodID getSystemServiceMethod = env->GetMethodID(
        contextClass, "getSystemService", "(Ljava/lang/String;)Ljava/lang/Object;");
    
    jstring vibratorService = env->NewStringUTF("vibrator");
    jobject vibrator = env->CallObjectMethod(context, getSystemServiceMethod, vibratorService);
    
    if (vibrator) {
        vibratorObject = env->NewGlobalRef(vibrator);
        jclass vibratorClass = env->GetObjectClass(vibrator);
        vibrateMethod = env->GetMethodID(vibratorClass, "vibrate", "(J)V");
    }
    
    return initializeAudioEngine();
}

bool AndroidPiano::initializeAudioEngine() {
    SLresult result;
    
    // Create engine
    result = slCreateEngine(&engineObject, 0, nullptr, 0, nullptr, nullptr);
    if (result != SL_RESULT_SUCCESS) {
        LOGE("Failed to create OpenSL ES engine");
        return false;
    }
    
    result = (*engineObject)->Realize(engineObject, SL_BOOLEAN_FALSE);
    if (result != SL_RESULT_SUCCESS) {
        LOGE("Failed to realize engine");
        return false;
    }
    
    result = (*engineObject)->GetInterface(engineObject, SL_IID_ENGINE, &engineEngine);
    if (result != SL_RESULT_SUCCESS) {
        LOGE("Failed to get engine interface");
        return false;
    }
    
    // Create output mix
    result = (*engineEngine)->CreateOutputMix(engineEngine, &outputMixObject, 0, nullptr, nullptr);
    if (result != SL_RESULT_SUCCESS) {
        LOGE("Failed to create output mix");
        return false;
    }
    
    result = (*outputMixObject)->Realize(outputMixObject, SL_BOOLEAN_FALSE);
    if (result != SL_RESULT_SUCCESS) {
        LOGE("Failed to realize output mix");
        return false;
    }
    
    LOGI("OpenSL ES audio engine initialized");
    return true;
}

void AndroidPiano::shutdownAudioEngine() {
    if (playerObject) {
        (*playerObject)->Destroy(playerObject);
        playerObject = nullptr;
    }
    
    if (outputMixObject) {
        (*outputMixObject)->Destroy(outputMixObject);
        outputMixObject = nullptr;
    }
    
    if (engineObject) {
        (*engineObject)->Destroy(engineObject);
        engineObject = nullptr;
    }
}

void AndroidPiano::setAssetManager(AAssetManager* manager) {
    assetManager = manager;
}

void AndroidPiano::vibrate(int duration) {
    // Vibration will be called from Java side through JNI
    LOGI("Vibrate: %d ms", duration);
}

// JNI implementations
extern "C" {

JNIEXPORT jlong JNICALL
Java_com_piano_mobile_PianoEngine_nativeCreate(JNIEnv* env, jobject thiz) {
    AndroidPiano* piano = new AndroidPiano();
    return reinterpret_cast<jlong>(piano);
}

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeDestroy(JNIEnv* env, jobject thiz, jlong handle) {
    AndroidPiano* piano = reinterpret_cast<AndroidPiano*>(handle);
    delete piano;
}

JNIEXPORT jboolean JNICALL
Java_com_piano_mobile_PianoEngine_nativeInitialize(
    JNIEnv* env, jobject thiz, jlong handle, jobject context,
    jint screenWidth, jint screenHeight) {
    
    AndroidPiano* piano = reinterpret_cast<AndroidPiano*>(handle);
    return piano->initializeAndroid(env, context, screenWidth, screenHeight) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeTouchDown(
    JNIEnv* env, jobject thiz, jlong handle, jint touchId,
    jfloat x, jfloat y, jfloat pressure) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    TouchEvent event;
    event.id = touchId;
    event.x = x;
    event.y = y;
    event.type = TouchEvent::DOWN;
    event.pressure = pressure;
    piano->handleTouchEvent(event);
}

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeTouchMove(
    JNIEnv* env, jobject thiz, jlong handle, jint touchId,
    jfloat x, jfloat y, jfloat pressure) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    TouchEvent event;
    event.id = touchId;
    event.x = x;
    event.y = y;
    event.type = TouchEvent::MOVE;
    event.pressure = pressure;
    piano->handleTouchEvent(event);
}

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeTouchUp(
    JNIEnv* env, jobject thiz, jlong handle, jint touchId,
    jfloat x, jfloat y) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    TouchEvent event;
    event.id = touchId;
    event.x = x;
    event.y = y;
    event.type = TouchEvent::UP;
    event.pressure = 0.0f;
    piano->handleTouchEvent(event);
}

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativePressKey(
    JNIEnv* env, jobject thiz, jlong handle, jint keyNumber, jint velocity) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    piano->pressKey(keyNumber, velocity);
}

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeReleaseKey(
    JNIEnv* env, jobject thiz, jlong handle, jint keyNumber) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    piano->releaseKey(keyNumber);
}

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeStartRecording(
    JNIEnv* env, jobject thiz, jlong handle) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    piano->startRecording();
}

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeStopRecording(
    JNIEnv* env, jobject thiz, jlong handle) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    piano->stopRecording();
}

JNIEXPORT jboolean JNICALL
Java_com_piano_mobile_PianoEngine_nativeSaveRecording(
    JNIEnv* env, jobject thiz, jlong handle, jstring filename) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    const char* filenameStr = env->GetStringUTFChars(filename, nullptr);
    bool result = piano->saveRecording(filenameStr);
    env->ReleaseStringUTFChars(filename, filenameStr);
    return result ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_piano_mobile_PianoEngine_nativeLoadMidiFile(
    JNIEnv* env, jobject thiz, jlong handle, jstring filename) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    const char* filenameStr = env->GetStringUTFChars(filename, nullptr);
    bool result = piano->loadMidiFile(filenameStr);
    env->ReleaseStringUTFChars(filename, filenameStr);
    return result ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeSetTranspose(
    JNIEnv* env, jobject thiz, jlong handle, jint semitones) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    piano->setTranspose(semitones);
}

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeSetMasterVolume(
    JNIEnv* env, jobject thiz, jlong handle, jfloat volume) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    piano->setMasterVolume(volume);
}

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeToggleSustain(
    JNIEnv* env, jobject thiz, jlong handle) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    piano->toggleSustain();
}

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeStartMetronome(
    JNIEnv* env, jobject thiz, jlong handle, jint bpm, jint beatsPerBar) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    piano->startMetronome(bpm, beatsPerBar);
}

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeStopMetronome(
    JNIEnv* env, jobject thiz, jlong handle) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    piano->stopMetronome();
}

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeLoadPreset(
    JNIEnv* env, jobject thiz, jlong handle, jint presetIndex) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    piano->loadSoundPreset(presetIndex);
}

JNIEXPORT jint JNICALL
Java_com_piano_mobile_PianoEngine_nativeGetPresetCount(
    JNIEnv* env, jobject thiz, jlong handle) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    return piano->getPresetCount();
}

JNIEXPORT jstring JNICALL
Java_com_piano_mobile_PianoEngine_nativeGetPresetName(
    JNIEnv* env, jobject thiz, jlong handle, jint index) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    std::string name = piano->getPresetName(index);
    return env->NewStringUTF(name.c_str());
}

JNIEXPORT jintArray JNICALL
Java_com_piano_mobile_PianoEngine_nativeGetPressedKeys(
    JNIEnv* env, jobject thiz, jlong handle) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    std::vector<int> pressed = piano->getPressedKeys();
    
    jintArray result = env->NewIntArray(pressed.size());
    if (result) {
        env->SetIntArrayRegion(result, 0, pressed.size(), pressed.data());
    }
    return result;
}

JNIEXPORT jboolean JNICALL
Java_com_piano_mobile_PianoEngine_nativeIsRecording(
    JNIEnv* env, jobject thiz, jlong handle) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    return piano->getIsRecording() ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jint JNICALL
Java_com_piano_mobile_PianoEngine_nativeGetRecordedEventCount(
    JNIEnv* env, jobject thiz, jlong handle) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    return piano->getRecordedEventCount();
}

JNIEXPORT jstring JNICALL
Java_com_piano_mobile_PianoEngine_nativeGetKeyName(
    JNIEnv* env, jobject thiz, jlong handle, jint keyNumber) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    auto keys = piano->getAllKeys();
    if (keyNumber >= 1 && keyNumber <= 88) {
        return env->NewStringUTF(keys[keyNumber - 1].noteName.c_str());
    }
    return env->NewStringUTF("");
}

JNIEXPORT jfloat JNICALL
Java_com_piano_mobile_PianoEngine_nativeGetKeyFrequency(
    JNIEnv* env, jobject thiz, jlong handle, jint keyNumber) {
    
    MobilePiano* piano = reinterpret_cast<MobilePiano*>(handle);
    auto keys = piano->getAllKeys();
    if (keyNumber >= 1 && keyNumber <= 88) {
        return static_cast<jfloat>(keys[keyNumber - 1].frequency);
    }
    return 0.0f;
}

} // extern "C"
