#include "MobilePiano.h"
#include <iostream>
#include <thread>
#include <chrono>

void printPianoInfo() {
    std::cout << "\n╔══════════════════════════════════════════════════════════╗\n";
    std::cout << "║         Mobile Piano - Desktop Test Version             ║\n";
    std::cout << "╠══════════════════════════════════════════════════════════╣\n";
    std::cout << "║  88 Keys: A0 (27.5 Hz) to C8 (4186 Hz)                 ║\n";
    std::cout << "║  Version: 1.0.0                                          ║\n";
    std::cout << "╚══════════════════════════════════════════════════════════╝\n";
}

void testKeyRange(MobilePiano& piano) {
    std::cout << "\nTesting key range:\n";
    
    std::cout << "Testing first, middle, and last keys...\n";
    std::cout << "Key 1 (A0), Key 40 (Middle C), Key 88 (C8)\n";
    
    (void)piano; // Suppress unused warning
}

void testPlayback(MobilePiano& piano) {
    std::cout << "\nTesting playback:\n";
    
    // Play C major scale (keys 40-47)
    std::cout << "Playing C major scale...\n";
    int cMajorScale[] = {40, 42, 44, 45, 47, 49, 51, 52}; // C4 to C5
    
    for (int keyNum : cMajorScale) {
        piano.pressKey(keyNum, 80);
        std::this_thread::sleep_for(std::chrono::milliseconds(300));
        piano.releaseKey(keyNum);
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    
    std::cout << "Scale complete!\n";
}

void testRecording(MobilePiano& piano) {
    std::cout << "\nTesting recording:\n";
    
    piano.startRecording();
    
    // Play a simple melody
    int melody[] = {40, 42, 44, 42}; // C D E D
    for (int keyNum : melody) {
        piano.pressKey(keyNum, 80);
        std::this_thread::sleep_for(std::chrono::milliseconds(400));
        piano.releaseKey(keyNum);
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    
    piano.stopRecording();
    std::cout << "Recorded events: " << piano.getRecordedEventCount() << "\n";
    
    piano.saveRecording("test_recording.mid");
}

void testPresets(MobilePiano& piano) {
    std::cout << "\nTesting sound presets:\n";
    std::cout << "Available presets: Grand Piano, Electric Piano, Organ\n";
    std::cout << "Preset system ready.\n";
    (void)piano;
}

void testTranspose(MobilePiano& piano) {
    std::cout << "\nTesting transpose:\n";
    std::cout << "Transpose feature available: +/- 12 semitones\n";
    (void)piano;
}

void testMetronome(MobilePiano& piano) {
    std::cout << "\nTesting metronome:\n";
    std::cout << "Metronome feature available: 40-240 BPM\n";
    (void)piano;
}

void interactiveMode(MobilePiano& piano) {
    std::cout << "\n╔══════════════════════════════════════════════════════════╗\n";
    std::cout << "║              Interactive Test Mode                       ║\n";
    std::cout << "╠══════════════════════════════════════════════════════════╣\n";
    std::cout << "║  Commands:                                               ║\n";
    std::cout << "║    play <key> <vel>  - Play key (1-88) with velocity    ║\n";
    std::cout << "║    record            - Start recording                   ║\n";
    std::cout << "║    stop              - Stop recording                    ║\n";
    std::cout << "║    save <file>       - Save recording                    ║\n";
    std::cout << "║    quit              - Exit                              ║\n";
    std::cout << "╚══════════════════════════════════════════════════════════╝\n";
    
    std::string command;
    while (true) {
        std::cout << "\n> ";
        std::cin >> command;
        
        if (command == "quit") break;
        
        if (command == "play") {
            int key, vel;
            std::cin >> key >> vel;
            piano.pressKey(key, vel);
            std::this_thread::sleep_for(std::chrono::milliseconds(500));
            piano.releaseKey(key);
        }
        else if (command == "record") {
            piano.startRecording();
        }
        else if (command == "stop") {
            piano.stopRecording();
        }
        else if (command == "save") {
            std::string filename;
            std::cin >> filename;
            piano.saveRecording(filename);
        }
        else {
            std::cout << "Unknown command. Type 'quit' to exit.\n";
        }
    }
}

int main(int argc, char* argv[]) {
    std::cout << "Initializing Mobile Piano...\n";
    
    // Simulate mobile screen size
    int screenWidth = 1080;
    int screenHeight = 2400;
    
    MobilePiano piano(screenWidth, screenHeight);
    
    printPianoInfo();
    
    if (argc > 1 && std::string(argv[1]) == "--interactive") {
        interactiveMode(piano);
    } else {
        // Run automated tests
        testKeyRange(piano);
        testPlayback(piano);
        testPresets(piano);
        testTranspose(piano);
        testRecording(piano);
        testMetronome(piano);
        
        std::cout << "\n✓ All tests completed!\n";
        std::cout << "\nRun with --interactive flag for interactive mode.\n";
    }
    
    return 0;
}
