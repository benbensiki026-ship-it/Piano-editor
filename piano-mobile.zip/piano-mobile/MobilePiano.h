#ifndef MOBILE_PIANO_H
#define MOBILE_PIANO_H

#include <string>
#include <vector>
#include <map>
#include <memory>
#include <ctime>

// Piano key structure representing a physical piano key
struct PianoKey {
    int midiNote;           // MIDI note number (21-108 for 88 keys)
    double frequency;       // Frequency in Hz
    std::string name;       // Note name (A0, C4, C8, etc.)
    bool isBlack;          // Black key (sharp/flat)
    bool isPressed;        // Currently pressed
    double pressTime;      // When key was pressed
    int velocity;          // Press velocity (0-127)
    float x, y;            // Screen position
    float width, height;   // Key dimensions
};

// Touch/Click input structure
struct TouchInput {
    int id;                // Touch ID for multi-touch
    float x, y;            // Touch position
    bool active;           // Currently touching
    int assignedKey;       // Which piano key is being touched (-1 if none)
    double startTime;      // When touch started
};

// MIDI Event for recording/playback
struct MidiEvent {
    double time;           // Time in seconds from start
    int note;              // MIDI note number
    int velocity;          // Note velocity (0-127)
    bool isNoteOn;         // true = note on, false = note off
};

// Recording session data
struct Recording {
    std::string name;
    std::vector<MidiEvent> events;
    double duration;
    time_t timestamp;
};

// Settings structure
struct PianoSettings {
    bool showNoteLabels;
    bool highlightPressed;
    bool sustainPedal;
    int octaveOffset;
    int masterVolume;
    int keyVelocity;
    bool showKeyboard;
    bool multiTouch;
    int scrollPosition;    // For scrolling across 88 keys
    float keyScale;        // Zoom level for keys
    bool metronomeEnabled;
    int metronomeBPM;
};

// Main Mobile Piano class
class MobilePiano {
private:
    std::vector<PianoKey> keys;           // All 88 piano keys
    std::vector<TouchInput> touches;      // Multi-touch support (up to 10)
    std::vector<MidiEvent> recordingBuffer;
    std::vector<Recording> savedRecordings;
    
    PianoSettings settings;
    bool isRecording;
    double recordingStartTime;
    double currentTime;
    
    int screenWidth;
    int screenHeight;
    
    // Key layout calculations
    int whiteKeyCount;
    int blackKeyCount;
    float whiteKeyWidth;
    float whiteKeyHeight;
    float blackKeyWidth;
    float blackKeyHeight;
    
    void initializeKeys();
    void calculateKeyPositions();
    void calculateKeyDimensions(int width, int height);
    double midiNoteToFrequency(int midiNote);
    std::string midiNoteToName(int midiNote);
    bool isBlackKey(int midiNote);
    
public:
    MobilePiano(int width, int height);
    ~MobilePiano();
    
    // Core functionality
    void handleTouchDown(int touchId, float x, float y, int velocity = 64);
    void handleTouchMove(int touchId, float x, float y);
    void handleTouchUp(int touchId, float x, float y);
    int getTouchedKey(float x, float y);
    
    // Piano operations
    void pressKey(int midiNote, int velocity = 64);
    void releaseKey(int midiNote);
    void releaseAllKeys();
    
    // Recording features
    void startRecording();
    void stopRecording();
    void saveRecording(const std::string& name);
    void loadRecording(int index);
    void playRecording(int index);
    void deleteRecording(int index);
    std::vector<Recording>& getRecordings() { return savedRecordings; }
    
    // MIDI import/export
    bool importMidiFile(const std::string& filename);
    bool exportMidiFile(const std::string& filename);
    bool exportRecordingToMidi(int recordingIndex, const std::string& filename);
    
    // Settings and controls
    void setOctaveOffset(int offset);
    void scrollKeyboard(int direction);
    void setKeyScale(float scale);
    void toggleSustainPedal();
    void setMasterVolume(int volume);
    void setKeyVelocity(int velocity);
    void toggleMetronome();
    void setMetronomeBPM(int bpm);
    
    // Display settings
    void setShowNoteLabels(bool show);
    void setHighlightPressed(bool highlight);
    void setMultiTouch(bool enabled);
    void setScreenSize(int width, int height);
    
    // Getters
    const std::vector<PianoKey>& getKeys() const { return keys; }
    const PianoSettings& getSettings() const { return settings; }
    bool getIsRecording() const { return isRecording; }
    int getRecordedEventCount() const { return recordingBuffer.size(); }
    double getCurrentTime() const { return currentTime; }
    
    // Update loop
    void update(double deltaTime);
    
    // Utility
    void reset();
    std::string getStatusString() const;
    void printKeyInfo(int midiNote) const;
};

#endif // MOBILE_PIANO_H
