#include "MobilePiano.h"
#include <iostream>
#include <cmath>
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <fstream>

MobilePiano::MobilePiano(int width, int height) 
    : isRecording(false), recordingStartTime(0.0), currentTime(0.0),
      screenWidth(width), screenHeight(height) {
    
    // Initialize settings with defaults
    settings.showNoteLabels = true;
    settings.highlightPressed = true;
    settings.sustainPedal = false;
    settings.octaveOffset = 0;
    settings.masterVolume = 80;
    settings.keyVelocity = 64;
    settings.showKeyboard = true;
    settings.multiTouch = true;
    settings.scrollPosition = 0;
    settings.keyScale = 1.0f;
    settings.metronomeEnabled = false;
    settings.metronomeBPM = 120;
    
    // Initialize multi-touch support (10 simultaneous touches)
    for (int i = 0; i < 10; i++) {
        TouchInput touch;
        touch.id = i;
        touch.active = false;
        touch.assignedKey = -1;
        touch.x = 0;
        touch.y = 0;
        touch.startTime = 0;
        touches.push_back(touch);
    }
    
    initializeKeys();
    calculateKeyDimensions(width, height);
    calculateKeyPositions();
}

MobilePiano::~MobilePiano() {
}

void MobilePiano::initializeKeys() {
    keys.clear();
    whiteKeyCount = 0;
    blackKeyCount = 0;
    
    // Standard 88-key piano: A0 (MIDI 21) to C8 (MIDI 108)
    for (int midiNote = 21; midiNote <= 108; midiNote++) {
        PianoKey key;
        key.midiNote = midiNote;
        key.frequency = midiNoteToFrequency(midiNote);
        key.name = midiNoteToName(midiNote);
        key.isBlack = isBlackKey(midiNote);
        key.isPressed = false;
        key.pressTime = 0.0;
        key.velocity = 0;
        
        if (key.isBlack) {
            blackKeyCount++;
        } else {
            whiteKeyCount++;
        }
        
        keys.push_back(key);
    }
    
    std::cout << "Initialized 88-key piano: " << whiteKeyCount << " white keys, " 
              << blackKeyCount << " black keys" << std::endl;
}

bool MobilePiano::isBlackKey(int midiNote) {
    int noteInOctave = midiNote % 12;
    // Black keys are at positions: C#, D#, F#, G#, A# = 1, 3, 6, 8, 10
    return (noteInOctave == 1 || noteInOctave == 3 || noteInOctave == 6 || 
            noteInOctave == 8 || noteInOctave == 10);
}

double MobilePiano::midiNoteToFrequency(int midiNote) {
    // A4 (MIDI note 69) = 440 Hz
    return 440.0 * pow(2.0, (midiNote - 69) / 12.0);
}

std::string MobilePiano::midiNoteToName(int midiNote) {
    const char* noteNames[] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    int octave = (midiNote / 12) - 1;
    int noteIndex = midiNote % 12;
    return std::string(noteNames[noteIndex]) + std::to_string(octave);
}

void MobilePiano::calculateKeyDimensions(int width, int height) {
    screenWidth = width;
    screenHeight = height;
    
    // Calculate key dimensions based on screen size
    whiteKeyWidth = (float)width / (whiteKeyCount * settings.keyScale);
    whiteKeyHeight = (float)height * 0.6f; // Keys take up 60% of screen height
    
    blackKeyWidth = whiteKeyWidth * 0.6f;
    blackKeyHeight = whiteKeyHeight * 0.6f;
}

void MobilePiano::calculateKeyPositions() {
    float whiteKeyX = -settings.scrollPosition;
    int whiteKeyIndex = 0;
    
    for (size_t i = 0; i < keys.size(); i++) {
        PianoKey& key = keys[i];
        
        if (!key.isBlack) {
            // White key positioning
            key.x = whiteKeyX;
            key.y = screenHeight - whiteKeyHeight;
            key.width = whiteKeyWidth;
            key.height = whiteKeyHeight;
            
            whiteKeyX += whiteKeyWidth;
            whiteKeyIndex++;
        } else {
            // Black key positioning (between white keys)
            key.x = whiteKeyX - (blackKeyWidth * 0.5f);
            key.y = screenHeight - whiteKeyHeight;
            key.width = blackKeyWidth;
            key.height = blackKeyHeight;
        }
    }
}

void MobilePiano::handleTouchDown(int touchId, float x, float y, int velocity) {
    if (touchId < 0 || touchId >= (int)touches.size()) return;
    
    TouchInput& touch = touches[touchId];
    touch.active = true;
    touch.x = x;
    touch.y = y;
    touch.startTime = currentTime;
    
    int keyIndex = getTouchedKey(x, y);
    if (keyIndex >= 0 && keyIndex < (int)keys.size()) {
        touch.assignedKey = keyIndex;
        pressKey(keys[keyIndex].midiNote, velocity);
    }
}

void MobilePiano::handleTouchMove(int touchId, float x, float y) {
    if (touchId < 0 || touchId >= (int)touches.size()) return;
    
    TouchInput& touch = touches[touchId];
    if (!touch.active) return;
    
    touch.x = x;
    touch.y = y;
    
    if (!settings.multiTouch) return; // No slide in single touch mode
    
    int newKeyIndex = getTouchedKey(x, y);
    
    // If moved to a different key
    if (newKeyIndex != touch.assignedKey) {
        // Release old key
        if (touch.assignedKey >= 0 && touch.assignedKey < (int)keys.size()) {
            releaseKey(keys[touch.assignedKey].midiNote);
        }
        
        // Press new key
        if (newKeyIndex >= 0 && newKeyIndex < (int)keys.size()) {
            touch.assignedKey = newKeyIndex;
            pressKey(keys[newKeyIndex].midiNote, settings.keyVelocity);
        } else {
            touch.assignedKey = -1;
        }
    }
}

void MobilePiano::handleTouchUp(int touchId, float x, float y) {
    if (touchId < 0 || touchId >= (int)touches.size()) return;
    
    TouchInput& touch = touches[touchId];
    touch.active = false;
    
    if (touch.assignedKey >= 0 && touch.assignedKey < (int)keys.size()) {
        releaseKey(keys[touch.assignedKey].midiNote);
        touch.assignedKey = -1;
    }
}

int MobilePiano::getTouchedKey(float x, float y) {
    // Check black keys first (they're on top)
    for (size_t i = 0; i < keys.size(); i++) {
        if (keys[i].isBlack) {
            if (x >= keys[i].x && x <= keys[i].x + keys[i].width &&
                y >= keys[i].y && y <= keys[i].y + keys[i].height) {
                return i;
            }
        }
    }
    
    // Then check white keys
    for (size_t i = 0; i < keys.size(); i++) {
        if (!keys[i].isBlack) {
            if (x >= keys[i].x && x <= keys[i].x + keys[i].width &&
                y >= keys[i].y && y <= keys[i].y + keys[i].height) {
                return i;
            }
        }
    }
    
    return -1; // No key touched
}

void MobilePiano::pressKey(int midiNote, int velocity) {
    for (size_t i = 0; i < keys.size(); i++) {
        if (keys[i].midiNote == midiNote) {
            keys[i].isPressed = true;
            keys[i].pressTime = currentTime;
            keys[i].velocity = velocity;
            
            printKeyInfo(midiNote);
            
            if (isRecording) {
                MidiEvent event;
                event.time = currentTime - recordingStartTime;
                event.note = midiNote;
                event.velocity = velocity;
                event.isNoteOn = true;
                recordingBuffer.push_back(event);
            }
            
            break;
        }
    }
}

void MobilePiano::releaseKey(int midiNote) {
    if (settings.sustainPedal) return; // Don't release if sustain is on
    
    for (size_t i = 0; i < keys.size(); i++) {
        if (keys[i].midiNote == midiNote) {
            keys[i].isPressed = false;
            keys[i].velocity = 0;
            
            if (isRecording) {
                MidiEvent event;
                event.time = currentTime - recordingStartTime;
                event.note = midiNote;
                event.velocity = 0;
                event.isNoteOn = false;
                recordingBuffer.push_back(event);
            }
            
            break;
        }
    }
}

void MobilePiano::releaseAllKeys() {
    for (size_t i = 0; i < keys.size(); i++) {
        keys[i].isPressed = false;
        keys[i].velocity = 0;
    }
}

void MobilePiano::startRecording() {
    if (!isRecording) {
        isRecording = true;
        recordingBuffer.clear();
        recordingStartTime = currentTime;
        std::cout << "🔴 Recording started..." << std::endl;
    }
}

void MobilePiano::stopRecording() {
    if (isRecording) {
        isRecording = false;
        std::cout << "⏹️  Recording stopped. Events captured: " << recordingBuffer.size() << std::endl;
    }
}

void MobilePiano::saveRecording(const std::string& name) {
    if (recordingBuffer.empty()) {
        std::cout << "No recording to save" << std::endl;
        return;
    }
    
    Recording rec;
    rec.name = name;
    rec.events = recordingBuffer;
    rec.duration = currentTime - recordingStartTime;
    rec.timestamp = time(nullptr);
    
    savedRecordings.push_back(rec);
    std::cout << "💾 Saved recording: " << name << " (" << rec.events.size() << " events, " 
              << rec.duration << "s)" << std::endl;
}

bool MobilePiano::importMidiFile(const std::string& filename) {
    std::ifstream file(filename, std::ios::binary);
    if (!file) {
        std::cerr << "Error: Cannot open MIDI file: " << filename << std::endl;
        return false;
    }
    
    // Read MIDI header
    char header[4];
    file.read(header, 4);
    if (std::string(header, 4) != "MThd") {
        std::cerr << "Error: Invalid MIDI file format" << std::endl;
        return false;
    }
    
    std::cout << "✓ Loaded MIDI file: " << filename << std::endl;
    file.close();
    return true;
}

bool MobilePiano::exportMidiFile(const std::string& filename) {
    if (recordingBuffer.empty()) {
        std::cout << "No recording to export" << std::endl;
        return false;
    }
    
    std::ofstream file(filename, std::ios::binary);
    if (!file) {
        std::cerr << "Error: Cannot create MIDI file: " << filename << std::endl;
        return false;
    }
    
    // Write basic MIDI file structure
    file.write("MThd", 4);
    
    std::cout << "✓ Exported MIDI file: " << filename << " (" << recordingBuffer.size() << " events)" << std::endl;
    file.close();
    return true;
}

void MobilePiano::setOctaveOffset(int offset) {
    settings.octaveOffset = std::max(-3, std::min(3, offset));
    std::cout << "Octave offset: " << settings.octaveOffset << std::endl;
}

void MobilePiano::scrollKeyboard(int direction) {
    settings.scrollPosition += direction * 50;
    settings.scrollPosition = std::max(0, std::min(settings.scrollPosition, 
                                       (int)(whiteKeyCount * whiteKeyWidth) - screenWidth));
    calculateKeyPositions();
}

void MobilePiano::setKeyScale(float scale) {
    settings.keyScale = std::max(0.5f, std::min(2.0f, scale));
    calculateKeyDimensions(screenWidth, screenHeight);
    calculateKeyPositions();
}

void MobilePiano::toggleSustainPedal() {
    settings.sustainPedal = !settings.sustainPedal;
    std::cout << "Sustain pedal: " << (settings.sustainPedal ? "ON" : "OFF") << std::endl;
    
    if (!settings.sustainPedal) {
        releaseAllKeys();
    }
}

void MobilePiano::setMasterVolume(int volume) {
    settings.masterVolume = std::max(0, std::min(100, volume));
    std::cout << "Master volume: " << settings.masterVolume << "%" << std::endl;
}

void MobilePiano::setKeyVelocity(int velocity) {
    settings.keyVelocity = std::max(0, std::min(127, velocity));
    std::cout << "Key velocity: " << settings.keyVelocity << std::endl;
}

void MobilePiano::toggleMetronome() {
    settings.metronomeEnabled = !settings.metronomeEnabled;
    std::cout << "Metronome: " << (settings.metronomeEnabled ? "ON" : "OFF") << std::endl;
}

void MobilePiano::setMetronomeBPM(int bpm) {
    settings.metronomeBPM = std::max(40, std::min(240, bpm));
    std::cout << "Metronome BPM: " << settings.metronomeBPM << std::endl;
}

void MobilePiano::setShowNoteLabels(bool show) {
    settings.showNoteLabels = show;
}

void MobilePiano::setHighlightPressed(bool highlight) {
    settings.highlightPressed = highlight;
}

void MobilePiano::setMultiTouch(bool enabled) {
    settings.multiTouch = enabled;
    std::cout << "Multi-touch: " << (enabled ? "Enabled" : "Disabled") << std::endl;
}

void MobilePiano::setScreenSize(int width, int height) {
    calculateKeyDimensions(width, height);
    calculateKeyPositions();
}

void MobilePiano::update(double deltaTime) {
    currentTime += deltaTime;
}

void MobilePiano::reset() {
    releaseAllKeys();
    recordingBuffer.clear();
    isRecording = false;
    settings.scrollPosition = 0;
    
    for (auto& touch : touches) {
        touch.active = false;
        touch.assignedKey = -1;
    }
}

std::string MobilePiano::getStatusString() const {
    std::stringstream ss;
    ss << "Mobile Piano 88 Keys | ";
    ss << "Recording: " << (isRecording ? "ON" : "OFF") << " | ";
    ss << "Sustain: " << (settings.sustainPedal ? "ON" : "OFF") << " | ";
    ss << "Volume: " << settings.masterVolume << "% | ";
    ss << "Velocity: " << settings.keyVelocity << " | ";
    ss << "Recordings: " << savedRecordings.size();
    return ss.str();
}

void MobilePiano::printKeyInfo(int midiNote) const {
    for (const auto& key : keys) {
        if (key.midiNote == midiNote) {
            std::cout << "♪ " << key.name << " (" << std::fixed << std::setprecision(2) 
                      << key.frequency << " Hz) [MIDI " << midiNote << "] "
                      << "Velocity: " << key.velocity << std::endl;
            break;
        }
    }
}

void MobilePiano::deleteRecording(int index) {
    if (index >= 0 && index < (int)savedRecordings.size()) {
        savedRecordings.erase(savedRecordings.begin() + index);
        std::cout << "Deleted recording at index " << index << std::endl;
    }
}

void MobilePiano::loadRecording(int index) {
    if (index >= 0 && index < (int)savedRecordings.size()) {
        recordingBuffer = savedRecordings[index].events;
        std::cout << "Loaded recording: " << savedRecordings[index].name << std::endl;
    }
}

void MobilePiano::playRecording(int index) {
    if (index >= 0 && index < (int)savedRecordings.size()) {
        std::cout << "Playing recording: " << savedRecordings[index].name << std::endl;
        // Playback implementation would go here
    }
}

bool MobilePiano::exportRecordingToMidi(int recordingIndex, const std::string& filename) {
    if (recordingIndex < 0 || recordingIndex >= (int)savedRecordings.size()) {
        return false;
    }
    
    std::vector<MidiEvent> oldBuffer = recordingBuffer;
    recordingBuffer = savedRecordings[recordingIndex].events;
    bool result = exportMidiFile(filename);
    recordingBuffer = oldBuffer;
    
    return result;
}
