# 📱 Android Build Guide - Mobile Piano

Guide for building Mobile Piano as an Android application using SDL2's Android port.

## Overview

SDL2 provides excellent Android support, allowing C++ SDL applications to run on Android devices with minimal changes. This guide covers the process of building Mobile Piano for Android.

## Prerequisites

### Required Software
- **Android Studio** (latest version)
- **Android NDK** r21 or later
- **Android SDK** (API level 21+, Android 5.0+)
- **Java Development Kit (JDK)** 8 or later
- **SDL2 Android Port**
- **SDL2_ttf Android Port**

### Knowledge Required
- Basic Android development
- Command line usage
- Java/Gradle basics

## Step 1: Install Android Studio

1. Download from: https://developer.android.com/studio
2. Install Android Studio
3. Open SDK Manager:
   - Install latest SDK Platform
   - Install SDK Build-Tools
   - Install Android NDK
   - Install CMake

## Step 2: Download SDL2 for Android

### SDL2
```bash
# Download SDL2 source
wget https://www.libsdl.org/release/SDL2-2.x.x.tar.gz
tar xzf SDL2-2.x.x.tar.gz

# Or clone from repository
git clone https://github.com/libsdl-org/SDL.git
cd SDL
git checkout release-2.x.x
```

### SDL2_ttf
```bash
# Download SDL2_ttf
wget https://www.libsdl.org/projects/SDL_ttf/release/SDL2_ttf-2.x.x.tar.gz
tar xzf SDL2_ttf-2.x.x.tar.gz

# Or clone
git clone https://github.com/libsdl-org/SDL_ttf.git
```

## Step 3: Create Android Project

### Using SDL2's Android Template

1. **Copy SDL2 Android project template**
   ```bash
   cp -r SDL/android-project MobilePianoAndroid
   cd MobilePianoAndroid
   ```

2. **Project Structure**
   ```
   MobilePianoAndroid/
   ├── app/
   │   ├── src/
   │   │   ├── main/
   │   │   │   ├── java/           # Java wrapper code
   │   │   │   ├── jni/            # C++ source files go here
   │   │   │   ├── assets/         # Resources (fonts, etc.)
   │   │   │   └── AndroidManifest.xml
   │   └── build.gradle
   ├── gradle/
   └── build.gradle
   ```

## Step 4: Add Piano Source Code

### Copy Source Files
```bash
cd app/src/main/jni
mkdir src

# Copy piano source files
cp /path/to/piano-mobile/main.cpp src/
cp /path/to/piano-mobile/MobilePiano.cpp src/
cp /path/to/piano-mobile/MobilePiano.h src/
```

### Create Android.mk
```makefile
# app/src/main/jni/src/Android.mk

LOCAL_PATH := $(call my-dir)

include $(CLEAR_VARS)

LOCAL_MODULE := main

SDL_PATH := ../SDL
SDL_TTF_PATH := ../SDL2_ttf

LOCAL_C_INCLUDES := $(LOCAL_PATH)/$(SDL_PATH)/include \
                    $(LOCAL_PATH)/$(SDL_TTF_PATH)

LOCAL_SRC_FILES := main.cpp MobilePiano.cpp

LOCAL_SHARED_LIBRARIES := SDL2 SDL2_ttf

LOCAL_LDLIBS := -lGLESv1_CM -lGLESv2 -llog

include $(BUILD_SHARED_LIBRARY)
```

### Create Application.mk
```makefile
# app/src/main/jni/Application.mk

APP_ABI := armeabi-v7a arm64-v8a x86 x86_64
APP_PLATFORM := android-21
APP_STL := c++_shared
APP_CPPFLAGS := -std=c++17
```

## Step 5: Link SDL2 Libraries

### Option 1: As Submodules
```bash
cd app/src/main/jni

# Add SDL2 as submodule
git submodule add https://github.com/libsdl-org/SDL.git SDL
git submodule add https://github.com/libsdl-org/SDL_ttf.git SDL2_ttf

# Update submodules
git submodule update --init --recursive
```

### Option 2: Copy Libraries
```bash
# Copy SDL2 source
cp -r /path/to/SDL app/src/main/jni/SDL

# Copy SDL2_ttf
cp -r /path/to/SDL2_ttf app/src/main/jni/SDL2_ttf
```

## Step 6: Configure Gradle

### app/build.gradle
```gradle
android {
    compileSdkVersion 33
    defaultConfig {
        applicationId "com.mobilepiano.app"
        minSdkVersion 21
        targetSdkVersion 33
        versionCode 1
        versionName "1.0"
        
        externalNativeBuild {
            ndkBuild {
                arguments "APP_PLATFORM=android-21"
                abiFilters 'armeabi-v7a', 'arm64-v8a', 'x86', 'x86_64'
            }
        }
    }
    
    buildTypes {
        release {
            minifyEnabled false
            proguardFiles getDefaultProguardFile('proguard-android.txt'), 'proguard-rules.pro'
        }
    }
    
    externalNativeBuild {
        ndkBuild {
            path 'src/main/jni/Android.mk'
        }
    }
}

dependencies {
    implementation fileTree(dir: 'libs', include: ['*.jar'])
}
```

## Step 7: Add Fonts and Assets

### Copy Font Files
```bash
# Create assets directory
mkdir -p app/src/main/assets/fonts

# Copy fonts
cp /usr/share/fonts/truetype/dejavu/DejaVuSans.ttf app/src/main/assets/fonts/
cp /usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf app/src/main/assets/fonts/
```

### Update Code to Load from Assets
```cpp
// In main.cpp, change font loading to:
#ifdef __ANDROID__
    font = TTF_OpenFont("fonts/DejaVuSans-Bold.ttf", 24);
    smallFont = TTF_OpenFont("fonts/DejaVuSans.ttf", 14);
#else
    // Original desktop paths
    font = TTF_OpenFont("/usr/share/fonts/...", 24);
#endif
```

## Step 8: Update AndroidManifest.xml

```xml
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.mobilepiano.app">
    
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"/>
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"/>
    
    <application
        android:label="Mobile Piano"
        android:icon="@drawable/icon"
        android:theme="@android:style/Theme.NoTitleBar.Fullscreen">
        
        <activity android:name="org.libsdl.app.SDLActivity"
            android:label="Mobile Piano - 88 Keys"
            android:screenOrientation="landscape"
            android:configChanges="keyboardHidden|orientation|screenSize">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
```

## Step 9: Build APK

### Using Android Studio

1. Open the project in Android Studio
2. Wait for Gradle sync
3. Build → Build Bundle(s) / APK(s) → Build APK(s)
4. Wait for build to complete
5. APK location: `app/build/outputs/apk/debug/app-debug.apk`

### Using Command Line

```bash
# Build debug APK
./gradlew assembleDebug

# Build release APK (requires signing)
./gradlew assembleRelease

# Install to connected device
./gradlew installDebug
```

## Step 10: Sign and Release (Optional)

### Generate Keystore
```bash
keytool -genkey -v -keystore my-release-key.jks \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -alias my-key-alias
```

### Configure Signing in build.gradle
```gradle
android {
    signingConfigs {
        release {
            storeFile file("my-release-key.jks")
            storePassword "your-password"
            keyAlias "my-key-alias"
            keyPassword "your-password"
        }
    }
    
    buildTypes {
        release {
            signingConfig signingConfigs.release
        }
    }
}
```

### Build Signed APK
```bash
./gradlew assembleRelease
```

## Optimization Tips

### Performance
- Use ARM64 for better performance on modern devices
- Enable hardware acceleration
- Optimize key rendering
- Use appropriate texture sizes

### Size Reduction
- Remove unused ABIs
- Enable ProGuard/R8
- Compress assets
- Remove debug symbols

### Battery Optimization
- Implement proper sleep/wake
- Optimize rendering loop
- Use power-efficient settings

## Testing

### On Emulator
```bash
# Start emulator
emulator -avd Pixel_4_API_30

# Install and run
./gradlew installDebug
adb shell am start -n com.mobilepiano.app/.SDLActivity
```

### On Physical Device
```bash
# Enable USB debugging on device
# Connect via USB

# Check device
adb devices

# Install
./gradlew installDebug

# View logs
adb logcat | grep -i mobilepiano
```

## Common Issues

### NDK Build Fails
- Check NDK version (r21+)
- Verify Android.mk paths
- Check C++17 support

### App Crashes on Start
- Check logcat for errors
- Verify SDL2 libraries linked
- Check font paths
- Verify assets copied

### Touch Not Working
- Ensure SDL2 Android touch support
- Check SDL_FINGERDOWN events
- Verify screen coordinates

### Audio Not Working
- SDL2 audio requires additional setup
- Add audio permissions
- Initialize SDL audio subsystem

## Publishing to Play Store

1. **Prepare Release Build**
   - Sign APK
   - Test thoroughly
   - Optimize size

2. **Create Play Store Listing**
   - Screenshots
   - Description
   - Icon
   - Feature graphic

3. **Upload APK**
   - Use Google Play Console
   - Fill out store listing
   - Set pricing and distribution

## Additional Resources

- [SDL2 Android README](https://github.com/libsdl-org/SDL/blob/main/docs/README-android.md)
- [Android NDK Documentation](https://developer.android.com/ndk/guides)
- [SDL2 Wiki - Android](https://wiki.libsdl.org/Android)

## Alternative: React Native Bridge

For easier development, consider wrapping in React Native:
- Use React Native UI
- Bridge to C++ SDL2 core
- Easier integration with Android features

## iOS Build

Similar process for iOS:
1. Use Xcode instead of Android Studio
2. Create iOS project
3. Add SDL2 frameworks
4. Build and sign
5. Submit to App Store

---

**Building for mobile requires patience but opens up great possibilities!** 📱🎹
