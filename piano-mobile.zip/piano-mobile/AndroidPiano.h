#ifndef ANDROID_PIANO_H
#define ANDROID_PIANO_H

#include "MobilePiano.h"
#include <jni.h>
#include <android/log.h>
#include <android/asset_manager.h>
#include <SLES/OpenSLES.h>
#include <SLES/OpenSLES_Android.h>

#define LOG_TAG "MobilePiano"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// Android-specific piano implementation
class AndroidPiano : public MobilePiano {
private:
    // OpenSL ES audio engine
    SLObjectItf engineObject;
    SLEngineItf engineEngine;
    SLObjectItf outputMixObject;
    SLObjectItf playerObject;
    SLPlayItf playerPlay;
    SLAndroidSimpleBufferQueueItf playerBufferQueue;
    
    // Asset manager for loading sounds
    AAssetManager* assetManager;
    
    // Vibration support
    jobject vibratorObject;
    jmethodID vibrateMethod;
    
    bool initializeAudioEngine();
    void shutdownAudioEngine();
    bool loadAssetSound(const std::string& assetPath);
    
public:
    AndroidPiano();
    ~AndroidPiano();
    
    bool initializeAndroid(JNIEnv* env, jobject context, int screenWidth, int screenHeight);
    void setAssetManager(AAssetManager* manager);
    void vibrate(int duration);
};

// JNI bridge functions
extern "C" {

// Piano lifecycle
JNIEXPORT jlong JNICALL
Java_com_piano_mobile_PianoEngine_nativeCreate(JNIEnv* env, jobject thiz);

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeDestroy(JNIEnv* env, jobject thiz, jlong handle);

JNIEXPORT jboolean JNICALL
Java_com_piano_mobile_PianoEngine_nativeInitialize(
    JNIEnv* env, jobject thiz, jlong handle, jobject context, 
    jint screenWidth, jint screenHeight);

// Touch handling
JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeTouchDown(
    JNIEnv* env, jobject thiz, jlong handle, jint touchId, 
    jfloat x, jfloat y, jfloat pressure);

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeTouchMove(
    JNIEnv* env, jobject thiz, jlong handle, jint touchId, 
    jfloat x, jfloat y, jfloat pressure);

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeTouchUp(
    JNIEnv* env, jobject thiz, jlong handle, jint touchId, 
    jfloat x, jfloat y);

// Key control
JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativePressKey(
    JNIEnv* env, jobject thiz, jlong handle, jint keyNumber, jint velocity);

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeReleaseKey(
    JNIEnv* env, jobject thiz, jlong handle, jint keyNumber);

// Recording
JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeStartRecording(
    JNIEnv* env, jobject thiz, jlong handle);

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeStopRecording(
    JNIEnv* env, jobject thiz, jlong handle);

JNIEXPORT jboolean JNICALL
Java_com_piano_mobile_PianoEngine_nativeSaveRecording(
    JNIEnv* env, jobject thiz, jlong handle, jstring filename);

JNIEXPORT jboolean JNICALL
Java_com_piano_mobile_PianoEngine_nativeLoadMidiFile(
    JNIEnv* env, jobject thiz, jlong handle, jstring filename);

// Settings
JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeSetTranspose(
    JNIEnv* env, jobject thiz, jlong handle, jint semitones);

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeSetMasterVolume(
    JNIEnv* env, jobject thiz, jlong handle, jfloat volume);

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeToggleSustain(
    JNIEnv* env, jobject thiz, jlong handle);

// Metronome
JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeStartMetronome(
    JNIEnv* env, jobject thiz, jlong handle, jint bpm, jint beatsPerBar);

JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeStopMetronome(
    JNIEnv* env, jobject thiz, jlong handle);

// Presets
JNIEXPORT void JNICALL
Java_com_piano_mobile_PianoEngine_nativeLoadPreset(
    JNIEnv* env, jobject thiz, jlong handle, jint presetIndex);

JNIEXPORT jint JNICALL
Java_com_piano_mobile_PianoEngine_nativeGetPresetCount(
    JNIEnv* env, jobject thiz, jlong handle);

JNIEXPORT jstring JNICALL
Java_com_piano_mobile_PianoEngine_nativeGetPresetName(
    JNIEnv* env, jobject thiz, jlong handle, jint index);

// State queries
JNIEXPORT jintArray JNICALL
Java_com_piano_mobile_PianoEngine_nativeGetPressedKeys(
    JNIEnv* env, jobject thiz, jlong handle);

JNIEXPORT jboolean JNICALL
Java_com_piano_mobile_PianoEngine_nativeIsRecording(
    JNIEnv* env, jobject thiz, jlong handle);

JNIEXPORT jint JNICALL
Java_com_piano_mobile_PianoEngine_nativeGetRecordedEventCount(
    JNIEnv* env, jobject thiz, jlong handle);

// Key information
JNIEXPORT jstring JNICALL
Java_com_piano_mobile_PianoEngine_nativeGetKeyName(
    JNIEnv* env, jobject thiz, jlong handle, jint keyNumber);

JNIEXPORT jfloat JNICALL
Java_com_piano_mobile_PianoEngine_nativeGetKeyFrequency(
    JNIEnv* env, jobject thiz, jlong handle, jint keyNumber);

} // extern "C"

#endif // ANDROID_PIANO_H
