#include "MobilePiano.h"
#include <iostream>
#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <chrono>
#include <sstream>
#include <iomanip>

// UI Colors
const SDL_Color WHITE = {255, 255, 255, 255};
const SDL_Color BLACK = {0, 0, 0, 255};
const SDL_Color GRAY = {128, 128, 128, 255};
const SDL_Color LIGHT_GRAY = {200, 200, 200, 255};
const SDL_Color DARK_GRAY = {50, 50, 50, 255};
const SDL_Color PRESSED_COLOR = {100, 200, 255, 255};
const SDL_Color BACKGROUND = {30, 30, 40, 255};
const SDL_Color UI_PANEL = {45, 45, 60, 255};

class PianoApp {
private:
    SDL_Window* window;
    SDL_Renderer* renderer;
    TTF_Font* font;
    TTF_Font* smallFont;
    MobilePiano* piano;
    
    int screenWidth;
    int screenHeight;
    bool running;
    
    // UI state
    bool showMenu;
    bool showRecordings;
    bool showSettings;
    int selectedMenuItem;
    
    std::chrono::high_resolution_clock::time_point lastFrameTime;
    
public:
    PianoApp(int width, int height) 
        : window(nullptr), renderer(nullptr), font(nullptr), smallFont(nullptr),
          screenWidth(width), screenHeight(height), running(true),
          showMenu(false), showRecordings(false), showSettings(false), 
          selectedMenuItem(0) {
        
        piano = new MobilePiano(width, height);
        lastFrameTime = std::chrono::high_resolution_clock::now();
    }
    
    ~PianoApp() {
        delete piano;
        if (font) TTF_CloseFont(font);
        if (smallFont) TTF_CloseFont(smallFont);
        if (renderer) SDL_DestroyRenderer(renderer);
        if (window) SDL_DestroyWindow(window);
        TTF_Quit();
        SDL_Quit();
    }
    
    bool initialize() {
        if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_EVENTS) < 0) {
            std::cerr << "SDL initialization failed: " << SDL_GetError() << std::endl;
            return false;
        }
        
        if (TTF_Init() < 0) {
            std::cerr << "TTF initialization failed: " << TTF_GetError() << std::endl;
            return false;
        }
        
        window = SDL_CreateWindow(
            "Mobile Piano - 88 Keys",
            SDL_WINDOWPOS_CENTERED,
            SDL_WINDOWPOS_CENTERED,
            screenWidth,
            screenHeight,
            SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE
        );
        
        if (!window) {
            std::cerr << "Window creation failed: " << SDL_GetError() << std::endl;
            return false;
        }
        
        renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
        if (!renderer) {
            std::cerr << "Renderer creation failed: " << SDL_GetError() << std::endl;
            return false;
        }
        
        // Try to load font (fallback to SDL if not available)
        font = TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 24);
        if (!font) {
            font = TTF_OpenFont("/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf", 24);
        }
        
        smallFont = TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 14);
        if (!smallFont) {
            smallFont = TTF_OpenFont("/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf", 14);
        }
        
        std::cout << "Mobile Piano initialized successfully!" << std::endl;
        std::cout << "88-key piano ready (A0 to C8)" << std::endl;
        return true;
    }
    
    void handleEvents() {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            switch (event.type) {
                case SDL_QUIT:
                    running = false;
                    break;
                    
                case SDL_WINDOWEVENT:
                    if (event.window.event == SDL_WINDOWEVENT_RESIZED) {
                        screenWidth = event.window.data1;
                        screenHeight = event.window.data2;
                        piano->setScreenSize(screenWidth, screenHeight);
                    }
                    break;
                    
                case SDL_FINGERDOWN:
                case SDL_MOUSEBUTTONDOWN: {
                    int x, y;
                    if (event.type == SDL_FINGERDOWN) {
                        x = event.tfinger.x * screenWidth;
                        y = event.tfinger.y * screenHeight;
                    } else {
                        x = event.button.x;
                        y = event.button.y;
                    }
                    
                    // Check UI buttons first
                    if (y < 60) {
                        handleUIClick(x, y);
                    } else {
                        // Piano key press
                        int touchId = (event.type == SDL_FINGERDOWN) ? 
                                     event.tfinger.fingerId : 0;
                        piano->handleTouchDown(touchId, x, y, 80);
                    }
                    break;
                }
                    
                case SDL_FINGERUP:
                case SDL_MOUSEBUTTONUP: {
                    int x, y;
                    if (event.type == SDL_FINGERUP) {
                        x = event.tfinger.x * screenWidth;
                        y = event.tfinger.y * screenHeight;
                    } else {
                        x = event.button.x;
                        y = event.button.y;
                    }
                    
                    int touchId = (event.type == SDL_FINGERUP) ? 
                                 event.tfinger.fingerId : 0;
                    piano->handleTouchUp(touchId, x, y);
                    break;
                }
                    
                case SDL_FINGERMOTION:
                case SDL_MOUSEMOTION: {
                    if (event.type == SDL_MOUSEMOTION && !(event.motion.state & SDL_BUTTON_LMASK)) {
                        break; // Only process mouse motion if button is pressed
                    }
                    
                    int x, y;
                    if (event.type == SDL_FINGERMOTION) {
                        x = event.tfinger.x * screenWidth;
                        y = event.tfinger.y * screenHeight;
                    } else {
                        x = event.motion.x;
                        y = event.motion.y;
                    }
                    
                    int touchId = (event.type == SDL_FINGERMOTION) ? 
                                 event.tfinger.fingerId : 0;
                    piano->handleTouchMove(touchId, x, y);
                    break;
                }
                    
                case SDL_KEYDOWN:
                    handleKeyPress(event.key.keysym.sym);
                    break;
            }
        }
    }
    
    void handleUIClick(int x, int y) {
        // Top UI bar is divided into sections
        int buttonWidth = screenWidth / 8;
        int section = x / buttonWidth;
        
        switch (section) {
            case 0: // Menu
                showMenu = !showMenu;
                break;
            case 1: // Record
                if (piano->getIsRecording()) {
                    piano->stopRecording();
                    piano->saveRecording("Recording_" + getCurrentTimeString());
                } else {
                    piano->startRecording();
                }
                break;
            case 2: // Recordings
                showRecordings = !showRecordings;
                break;
            case 3: // Settings
                showSettings = !showSettings;
                break;
            case 4: // Sustain
                piano->toggleSustainPedal();
                break;
            case 5: // Scroll Left
                piano->scrollKeyboard(-1);
                break;
            case 6: // Scroll Right
                piano->scrollKeyboard(1);
                break;
            case 7: // Zoom
                // Cycle through zoom levels
                break;
        }
    }
    
    void handleKeyPress(SDL_Keycode key) {
        switch (key) {
            case SDLK_ESCAPE:
                running = false;
                break;
            case SDLK_SPACE:
                piano->toggleSustainPedal();
                break;
            case SDLK_LEFT:
                piano->scrollKeyboard(-1);
                break;
            case SDLK_RIGHT:
                piano->scrollKeyboard(1);
                break;
            case SDLK_UP:
                piano->setKeyVelocity(piano->getSettings().keyVelocity + 10);
                break;
            case SDLK_DOWN:
                piano->setKeyVelocity(piano->getSettings().keyVelocity - 10);
                break;
            case SDLK_r:
                if (piano->getIsRecording()) {
                    piano->stopRecording();
                } else {
                    piano->startRecording();
                }
                break;
            case SDLK_m:
                showMenu = !showMenu;
                break;
        }
    }
    
    void update() {
        auto currentTime = std::chrono::high_resolution_clock::now();
        double deltaTime = std::chrono::duration<double>(currentTime - lastFrameTime).count();
        lastFrameTime = currentTime;
        
        piano->update(deltaTime);
    }
    
    void render() {
        // Clear screen
        SDL_SetRenderDrawColor(renderer, BACKGROUND.r, BACKGROUND.g, BACKGROUND.b, BACKGROUND.a);
        SDL_RenderClear(renderer);
        
        // Draw UI panel
        drawUIPanel();
        
        // Draw piano keys
        drawPianoKeys();
        
        // Draw overlays
        if (showMenu) drawMenu();
        if (showRecordings) drawRecordings();
        if (showSettings) drawSettings();
        
        // Draw status bar
        drawStatusBar();
        
        SDL_RenderPresent(renderer);
    }
    
    void drawUIPanel() {
        SDL_Rect panel = {0, 0, screenWidth, 60};
        SDL_SetRenderDrawColor(renderer, UI_PANEL.r, UI_PANEL.g, UI_PANEL.b, UI_PANEL.a);
        SDL_RenderFillRect(renderer, &panel);
        
        // Draw buttons
        int buttonWidth = screenWidth / 8;
        const char* labels[] = {"MENU", "REC", "LIST", "SET", "SUSTAIN", "◄", "►", "ZOOM"};
        
        for (int i = 0; i < 8; i++) {
            SDL_Rect button = {i * buttonWidth + 5, 10, buttonWidth - 10, 40};
            
            // Highlight if active
            if (i == 1 && piano->getIsRecording()) {
                SDL_SetRenderDrawColor(renderer, 255, 0, 0, 255);
            } else if (i == 4 && piano->getSettings().sustainPedal) {
                SDL_SetRenderDrawColor(renderer, 100, 200, 255, 255);
            } else {
                SDL_SetRenderDrawColor(renderer, DARK_GRAY.r, DARK_GRAY.g, DARK_GRAY.b, DARK_GRAY.a);
            }
            
            SDL_RenderFillRect(renderer, &button);
            
            // Draw label
            if (smallFont) {
                drawText(labels[i], button.x + button.w/2, button.y + button.h/2, 
                        smallFont, WHITE, true);
            }
        }
    }
    
    void drawPianoKeys() {
        const std::vector<PianoKey>& keys = piano->getKeys();
        
        // Draw white keys first
        for (const auto& key : keys) {
            if (!key.isBlack) {
                SDL_Rect rect = {
                    (int)key.x, (int)key.y, 
                    (int)key.width, (int)key.height
                };
                
                if (key.isPressed && piano->getSettings().highlightPressed) {
                    SDL_SetRenderDrawColor(renderer, PRESSED_COLOR.r, PRESSED_COLOR.g, 
                                          PRESSED_COLOR.b, PRESSED_COLOR.a);
                } else {
                    SDL_SetRenderDrawColor(renderer, WHITE.r, WHITE.g, WHITE.b, WHITE.a);
                }
                SDL_RenderFillRect(renderer, &rect);
                
                // Draw border
                SDL_SetRenderDrawColor(renderer, BLACK.r, BLACK.g, BLACK.b, BLACK.a);
                SDL_RenderDrawRect(renderer, &rect);
                
                // Draw note label
                if (piano->getSettings().showNoteLabels && smallFont) {
                    drawText(key.name.c_str(), rect.x + rect.w/2, 
                            rect.y + rect.h - 20, smallFont, BLACK, true);
                }
            }
        }
        
        // Draw black keys on top
        for (const auto& key : keys) {
            if (key.isBlack) {
                SDL_Rect rect = {
                    (int)key.x, (int)key.y,
                    (int)key.width, (int)key.height
                };
                
                if (key.isPressed && piano->getSettings().highlightPressed) {
                    SDL_SetRenderDrawColor(renderer, PRESSED_COLOR.r, PRESSED_COLOR.g,
                                          PRESSED_COLOR.b, PRESSED_COLOR.a);
                } else {
                    SDL_SetRenderDrawColor(renderer, BLACK.r, BLACK.g, BLACK.b, BLACK.a);
                }
                SDL_RenderFillRect(renderer, &rect);
                
                // Draw note label
                if (piano->getSettings().showNoteLabels && smallFont) {
                    drawText(key.name.c_str(), rect.x + rect.w/2,
                            rect.y + rect.h - 15, smallFont, WHITE, true);
                }
            }
        }
    }
    
    void drawMenu() {
        // Semi-transparent overlay
        SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 200);
        SDL_Rect overlay = {0, 0, screenWidth, screenHeight};
        SDL_RenderFillRect(renderer, &overlay);
        
        // Menu panel
        SDL_Rect menuPanel = {screenWidth/4, screenHeight/4, screenWidth/2, screenHeight/2};
        SDL_SetRenderDrawColor(renderer, UI_PANEL.r, UI_PANEL.g, UI_PANEL.b, UI_PANEL.a);
        SDL_RenderFillRect(renderer, &menuPanel);
        
        if (font) {
            drawText("MOBILE PIANO MENU", screenWidth/2, screenHeight/4 + 40, font, WHITE, true);
            drawText("88 Keys (A0-C8)", screenWidth/2, screenHeight/4 + 80, smallFont, LIGHT_GRAY, true);
            drawText("Press anywhere to close", screenWidth/2, screenHeight/4 + 120, smallFont, LIGHT_GRAY, true);
        }
    }
    
    void drawRecordings() {
        SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 200);
        SDL_Rect overlay = {0, 0, screenWidth, screenHeight};
        SDL_RenderFillRect(renderer, &overlay);
        
        SDL_Rect panel = {50, 100, screenWidth - 100, screenHeight - 200};
        SDL_SetRenderDrawColor(renderer, UI_PANEL.r, UI_PANEL.g, UI_PANEL.b, UI_PANEL.a);
        SDL_RenderFillRect(renderer, &panel);
        
        if (font) {
            drawText("RECORDINGS", screenWidth/2, 130, font, WHITE, true);
            
            auto& recordings = piano->getRecordings();
            if (recordings.empty()) {
                drawText("No recordings yet", screenWidth/2, 200, smallFont, LIGHT_GRAY, true);
            } else {
                int y = 180;
                for (size_t i = 0; i < recordings.size(); i++) {
                    std::string info = recordings[i].name + " - " + 
                                      std::to_string((int)recordings[i].duration) + "s";
                    drawText(info.c_str(), 100, y, smallFont, WHITE, false);
                    y += 30;
                }
            }
        }
    }
    
    void drawSettings() {
        SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
        SDL_SetRenderDrawColor(renderer, 0, 0, 0, 200);
        SDL_Rect overlay = {0, 0, screenWidth, screenHeight};
        SDL_RenderFillRect(renderer, &overlay);
        
        SDL_Rect panel = {100, 100, screenWidth - 200, screenHeight - 200};
        SDL_SetRenderDrawColor(renderer, UI_PANEL.r, UI_PANEL.g, UI_PANEL.b, UI_PANEL.a);
        SDL_RenderFillRect(renderer, &panel);
        
        if (font) {
            drawText("SETTINGS", screenWidth/2, 130, font, WHITE, true);
            
            int y = 180;
            const PianoSettings& settings = piano->getSettings();
            
            drawText(("Volume: " + std::to_string(settings.masterVolume) + "%").c_str(), 
                    150, y, smallFont, WHITE, false); y += 30;
            drawText(("Velocity: " + std::to_string(settings.keyVelocity)).c_str(),
                    150, y, smallFont, WHITE, false); y += 30;
            drawText(("Multi-touch: " + std::string(settings.multiTouch ? "ON" : "OFF")).c_str(),
                    150, y, smallFont, WHITE, false); y += 30;
            drawText(("Show labels: " + std::string(settings.showNoteLabels ? "ON" : "OFF")).c_str(),
                    150, y, smallFont, WHITE, false); y += 30;
        }
    }
    
    void drawStatusBar() {
        std::string status = piano->getStatusString();
        if (smallFont) {
            drawText(status.c_str(), 10, screenHeight - 25, smallFont, WHITE, false);
        }
    }
    
    void drawText(const char* text, int x, int y, TTF_Font* textFont, 
                 SDL_Color color, bool centered) {
        if (!textFont) return;
        
        SDL_Surface* surface = TTF_RenderText_Blended(textFont, text, color);
        if (!surface) return;
        
        SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
        if (!texture) {
            SDL_FreeSurface(surface);
            return;
        }
        
        SDL_Rect destRect;
        destRect.w = surface->w;
        destRect.h = surface->h;
        
        if (centered) {
            destRect.x = x - destRect.w / 2;
            destRect.y = y - destRect.h / 2;
        } else {
            destRect.x = x;
            destRect.y = y;
        }
        
        SDL_RenderCopy(renderer, texture, nullptr, &destRect);
        
        SDL_DestroyTexture(texture);
        SDL_FreeSurface(surface);
    }
    
    std::string getCurrentTimeString() {
        auto now = std::chrono::system_clock::now();
        auto time = std::chrono::system_clock::to_time_t(now);
        std::stringstream ss;
        ss << std::put_time(std::localtime(&time), "%Y%m%d_%H%M%S");
        return ss.str();
    }
    
    void run() {
        std::cout << "\n╔════════════════════════════════════════════════════════════╗\n";
        std::cout << "║            Mobile Piano - 88 Keys                         ║\n";
        std::cout << "║            Touch the keys to play!                        ║\n";
        std::cout << "╚════════════════════════════════════════════════════════════╝\n\n";
        
        while (running) {
            handleEvents();
            update();
            render();
            SDL_Delay(10); // ~60 FPS
        }
    }
    
    bool isRunning() const { return running; }
};

int main(int argc, char* argv[]) {
    // Default mobile screen size (can be adjusted)
    int width = 1024;
    int height = 768;
    
    // Parse command line arguments
    if (argc > 2) {
        width = std::atoi(argv[1]);
        height = std::atoi(argv[2]);
    }
    
    PianoApp app(width, height);
    
    if (!app.initialize()) {
        std::cerr << "Failed to initialize application" << std::endl;
        return 1;
    }
    
    app.run();
    
    std::cout << "Thank you for using Mobile Piano! 🎹" << std::endl;
    return 0;
}
