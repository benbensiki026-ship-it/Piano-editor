#ifndef IOS_PIANO_H
#define IOS_PIANO_H

#include "MobilePiano.h"

#ifdef __OBJC__
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>
#endif

// iOS-specific piano implementation
class IOSPiano : public MobilePiano {
private:
    void* audioEngine;        // AVAudioEngine* (opaque pointer for C++)
    void* audioPlayerNode;    // AVAudioPlayerNode*
    void* audioMixerNode;     // AVAudioMixerNode*
    
    bool initializeAudioEngine();
    void shutdownAudioEngine();
    void triggerHapticFeedback(int intensity);
    
public:
    IOSPiano();
    ~IOSPiano();
    
    bool initializeIOS(int screenWidth, int screenHeight);
    void handleIOSTouch(void* touches, void* event);
};

// Objective-C++ wrapper class
#ifdef __OBJC__

@interface PianoEngineWrapper : NSObject

@property (nonatomic, assign) IOSPiano* piano;

- (instancetype)initWithScreenSize:(CGSize)size;
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event;
- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event;
- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event;
- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event;

- (void)pressKey:(int)keyNumber velocity:(int)velocity;
- (void)releaseKey:(int)keyNumber;

- (void)startRecording;
- (void)stopRecording;
- (BOOL)saveRecording:(NSString *)filename;
- (BOOL)loadMidiFile:(NSString *)filename;

- (void)setTranspose:(int)semitones;
- (void)setMasterVolume:(float)volume;
- (void)toggleSustain;

- (void)startMetronome:(int)bpm beatsPerBar:(int)beatsPerBar;
- (void)stopMetronome;

- (void)loadPreset:(int)presetIndex;
- (int)getPresetCount;
- (NSString *)getPresetName:(int)index;

- (NSArray<NSNumber *> *)getPressedKeys;
- (BOOL)isRecording;
- (int)getRecordedEventCount;

- (NSString *)getKeyName:(int)keyNumber;
- (float)getKeyFrequency:(int)keyNumber;

@end

#endif // __OBJC__

#endif // IOS_PIANO_H
