# 🚀 Quick Start Guide - Mobile Piano

Get up and running with Mobile Piano in 5 minutes!

## ⚡ Super Quick Start

### Linux (Ubuntu/Debian)
```bash
# 1. Install dependencies
sudo apt-get install libsdl2-dev libsdl2-ttf-dev

# 2. Extract and build
unzip piano-mobile.zip
cd piano-mobile
make

# 3. Run!
./mobile-piano
```

### That's it! 🎹

## 🎮 First Steps

### 1. Launch the App
```bash
./mobile-piano              # Default size
./mobile-piano 1280 720     # HD
./mobile-piano 800 600      # Mobile size
```

### 2. Play Your First Notes
- **Click** or **touch** any piano key
- Try multiple keys at once (it's multi-touch!)
- **Slide** your finger/mouse across keys

### 3. Essential Controls

#### Top Bar Buttons
```
[MENU] [REC] [LIST] [SET] [SUSTAIN] [◄] [►] [ZOOM]
```

- **REC** - Start/stop recording (turns red when recording)
- **SUSTAIN** - Hold notes (turns blue when on)
- **◄ ►** - Scroll left/right across 88 keys
- **LIST** - View your recordings

#### Keyboard Shortcuts
- `SPACE` - Toggle sustain pedal
- `R` - Toggle recording
- `← →` - Scroll keyboard
- `↑ ↓` - Change velocity
- `ESC` - Exit

## 🎵 Quick Tasks

### Record a Song
```
1. Press REC (or R key)
2. Play your piece
3. Press REC again to stop
4. Auto-saved with timestamp!
```

### View Recordings
```
1. Press LIST button
2. See all recordings with durations
3. Click to play (feature ready)
```

### Adjust Settings
```
1. Press SET button
2. Change volume, velocity
3. Toggle multi-touch, labels
4. Changes apply instantly
```

### Navigate 88 Keys
```
- Use ◄ ► buttons to scroll
- Or arrow keys ← →
- Try different sections of the keyboard
- From A0 (lowest) to C8 (highest)
```

## 🔧 Troubleshooting

### "SDL2 not found"
```bash
# Ubuntu/Debian
sudo apt-get install libsdl2-dev libsdl2-ttf-dev

# Or use Makefile
make install-deps
```

### Can't see all keys
```
- Use ◄ ► to scroll
- Try higher resolution
- Adjust zoom (ZOOM button)
```

### Keys not responding
```
- Make sure window is focused
- Try clicking/touching again
- Check if SDL2 is working: ldd mobile-piano
```

## 💡 Tips

1. **Multi-touch**: Play chords! Touch 3-4 keys at once
2. **Sustain**: Hold SPACE for legato playing
3. **Recording**: Records MIDI data (notes, timing, velocity)
4. **Scrolling**: Use keyboard arrows for quick navigation
5. **Resolution**: Bigger screen = more visible keys

## 📱 Screen Sizes

Different devices, different sizes:
```bash
./mobile-piano 800 600      # Phone
./mobile-piano 1024 768     # Tablet
./mobile-piano 1280 720     # HD Monitor
./mobile-piano 1920 1080    # Full HD
```

## 🎹 Playing Tips

### For Beginners
- Start with middle keys (around C4)
- Try simple scales: C D E F G A B C
- Use one finger/mouse at first

### For Advanced
- Enable multi-touch for chords
- Use sustain for smooth transitions
- Record complex pieces
- Try glissando (slide across keys)

## 📚 Learn More

- **README.md** - Full documentation
- **FEATURES.md** - Complete feature list
- **BUILD.md** - Detailed build guide
- **ANDROID.md** - Mobile deployment

## 🎼 Example Session

```bash
# Start the app
./mobile-piano 1280 720

# Play middle C (around center)
# Click the white key labeled "C4"

# Enable sustain
# Press SPACE or click SUSTAIN button

# Start recording
# Press R or click REC

# Play a simple melody
# Click: C4 D4 E4 F4 G4

# Stop recording
# Press R or click REC again

# View your recording
# Click LIST button

# Exit
# Press ESC
```

## 🆘 Need Help?

1. Check the status bar at bottom
2. Press M for menu
3. Try different resolutions
4. Check console output for errors
5. Verify SDL2 installation: `sdl2-config --version`

## 🎊 You're Ready!

Now you know enough to:
- ✅ Play the piano
- ✅ Record performances
- ✅ Navigate 88 keys
- ✅ Adjust settings
- ✅ Use sustain pedal

**Have fun making music!** 🎹✨

---

*For advanced features and customization, see the full README.md*
