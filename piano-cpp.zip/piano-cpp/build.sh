#!/bin/bash

# Build script for C++ QWERTY Piano

echo "╔════════════════════════════════════════════════════════════╗"
echo "║         Building C++ QWERTY Piano                          ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""

# Check for g++
if ! command -v g++ &> /dev/null; then
    echo "Error: g++ not found. Please install a C++ compiler."
    exit 1
fi

echo "✓ Compiler found: $(g++ --version | head -n 1)"
echo ""

# Clean previous build
echo "Cleaning previous build..."
make clean 2>/dev/null || rm -f *.o piano

echo ""
echo "Compiling source files..."
echo "  - piano.cpp"
g++ -std=c++17 -Wall -Wextra -O2 -c piano.cpp -o piano.o

if [ $? -ne 0 ]; then
    echo "✗ Error compiling piano.cpp"
    exit 1
fi

echo "  - main.cpp"
g++ -std=c++17 -Wall -Wextra -O2 -c main.cpp -o main.o

if [ $? -ne 0 ]; then
    echo "✗ Error compiling main.cpp"
    exit 1
fi

echo ""
echo "Linking..."
g++ -std=c++17 -Wall -Wextra -O2 -o piano main.o piano.o

if [ $? -ne 0 ]; then
    echo "✗ Error linking"
    exit 1
fi

echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║         ✓ Build Successful!                                ║"
echo "╠════════════════════════════════════════════════════════════╣"
echo "║  Run the program with:  ./piano                            ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""
