# Sample MIDI Files for Testing

## Where to Find MIDI Files

1. **Free MIDI Archives:**
   - https://freemidi.org
   - https://bitmidi.com
   - https://www.midiworld.com

2. **Classical Music:**
   - https://www.classicalarchives.com
   - Public domain compositions

3. **Create Your Own:**
   - Use the built-in recording feature
   - Record simple melodies and export

## Testing the Piano

### Simple Test Melody (Mary Had a Little Lamb)
Keys: E D C D E E E (pause) D D D (pause) E E E

In QWERTY: C X Z X C C C (pause) X X X (pause) C C C

### C Major Scale
Keys: C D E F G A B C
In QWERTY (Bottom Row): Z X C V B N M (then ] for next octave and Z)

### Chord Progressions
Try playing multiple keys simultaneously:
- C Major: Z C V (C E G)
- G Major: B N (+ next octave Z with ]) (G B D)
- A Minor: N M (+ next octave Z with ]) (A C E)

## MIDI File Format Notes

The program supports standard MIDI file format (.mid):
- Format 0 (single track)
- Format 1 (multiple tracks - basic support)
- Standard MIDI events (Note On/Off)

For best compatibility, use MIDI files with:
- Simple single-track melodies
- Standard tempo (120 BPM)
- No complex controllers or sysex messages
