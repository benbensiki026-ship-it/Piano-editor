#ifndef PIANO_H
#define PIANO_H

#include <string>
#include <vector>
#include <map>
#include <memory>

// Note structure
struct Note {
    int key;           // MIDI note number (0-127)
    double frequency;  // Frequency in Hz
    std::string name;  // Note name (C4, D#5, etc.)
    bool isActive;     // Currently being played
    double startTime;  // When the note started
};

// MIDI Event structure
struct MidiEvent {
    double time;       // Time in seconds
    int note;          // MIDI note number
    int velocity;      // 0-127
    bool isNoteOn;     // true for note on, false for note off
};

// Piano class
class Piano {
private:
    std::map<char, int> keyMapping;  // QWERTY key to MIDI note mapping
    std::vector<Note> notes;
    std::vector<MidiEvent> midiEvents;
    bool recording;
    double recordStartTime;
    int octaveOffset;
    int velocity;
    bool sustainPedal;
    
    void initializeKeyMapping();
    void initializeNotes();
    double midiNoteToFrequency(int midiNote);
    std::string midiNoteToName(int midiNote);
    
public:
    Piano();
    ~Piano();
    
    // Core functionality
    void playNote(char key);
    void stopNote(char key);
    void playMidiNote(int midiNote, int velocity);
    void stopMidiNote(int midiNote);
    
    // Recording features
    void startRecording();
    void stopRecording();
    void saveRecording(const std::string& filename);
    
    // MIDI import/export
    bool loadMidiFile(const std::string& filename);
    void playMidiSequence();
    bool exportMidi(const std::string& filename);
    
    // Control features
    void increaseOctave();
    void decreaseOctave();
    void setVelocity(int vel);
    void toggleSustain();
    
    // Display
    void displayKeyboard();
    void displayHelp();
    void displayStatus();
    
    // Getters
    int getOctave() const { return octaveOffset; }
    int getVelocity() const { return velocity; }
    bool isSustainOn() const { return sustainPedal; }
    bool isRecording() const { return recording; }
};

#endif // PIANO_H
