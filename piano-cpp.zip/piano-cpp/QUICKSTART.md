# 🎹 Quick Start Guide

## Installation

### Linux/Mac:
```bash
# Extract the archive
unzip piano-cpp.zip
cd piano-cpp

# Build the program
./build.sh

# Run it!
./piano
```

### Windows:
```batch
# Extract the archive
# Open Command Prompt or PowerShell in the extracted folder

# Build the program (requires MinGW with g++)
build.bat

# Run it!
piano.exe
```

## First Steps

1. **Start the program** - You'll see a welcome screen
2. **Press F11** - View the help menu
3. **Press F10** - See the keyboard layout
4. **Start playing!** - Use Z, X, C, V, B, N, M for the bottom octave

## Try These First

### Play a Scale
Press these keys in order: `Z X C V B N M`

### Change Octave
- Press `]` to go higher
- Press `[` to go lower

### Record Something
1. Press `F1` to start recording
2. Play some notes
3. Press `F2` to stop
4. Press `F3` to save your recording

## Need Help?

- Press `F11` anytime for the help menu
- Press `F12` to see current settings
- Press `ESC` to exit

## Keyboard Reference Card

```
Piano Keys:
┌─────────────────────────────────────┐
│ Top:    I 9 O 0 P                  │
│ Middle: Q 2 W 3 E R 5 T 6 Y 7 U   │
│ Bottom: Z S X D C V G B H N J M   │
└─────────────────────────────────────┘

Controls:
[ ] = Change octave
- = = Change volume
SPACE = Sustain pedal
ESC = Exit
```

**Enjoy making music!** 🎵
