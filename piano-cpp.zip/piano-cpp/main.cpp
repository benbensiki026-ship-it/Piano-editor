#include "piano.h"
#include <iostream>
#include <thread>
#include <atomic>
#include <cstring>

#ifdef _WIN32
#include <conio.h>
#include <windows.h>
#else
#include <termios.h>
#include <unistd.h>
#include <sys/select.h>
#endif

std::atomic<bool> running(true);

// Cross-platform keyboard input handling
class KeyboardInput {
private:
#ifndef _WIN32
    struct termios oldSettings, newSettings;
#endif

public:
    KeyboardInput() {
#ifndef _WIN32
        tcgetattr(STDIN_FILENO, &oldSettings);
        newSettings = oldSettings;
        newSettings.c_lflag &= ~(ICANON | ECHO);
        tcsetattr(STDIN_FILENO, TCSANOW, &newSettings);
#endif
    }

    ~KeyboardInput() {
#ifndef _WIN32
        tcsetattr(STDIN_FILENO, TCSANOW, &oldSettings);
#endif
    }

    int getKey() {
#ifdef _WIN32
        if (_kbhit()) {
            return _getch();
        }
        return 0;
#else
        fd_set set;
        struct timeval timeout;
        FD_ZERO(&set);
        FD_SET(STDIN_FILENO, &set);
        timeout.tv_sec = 0;
        timeout.tv_usec = 10000; // 10ms timeout

        int rv = select(STDIN_FILENO + 1, &set, NULL, NULL, &timeout);
        if (rv > 0) {
            char c;
            read(STDIN_FILENO, &c, 1);
            return c;
        }
        return 0;
#endif
    }

    bool isSpecialKey(int key) {
#ifdef _WIN32
        return (key == 0 || key == 224);
#else
        return (key == 27); // ESC
#endif
    }

    int getSpecialKey() {
#ifdef _WIN32
        return _getch();
#else
        char seq[3];
        if (read(STDIN_FILENO, &seq[0], 1) != 1) return 0;
        if (read(STDIN_FILENO, &seq[1], 1) != 1) return 0;
        
        if (seq[0] == '[') {
            switch (seq[1]) {
                case 'A': return 72; // Up arrow (like F1)
                case 'B': return 80; // Down arrow (like F2)
                default: return 0;
            }
        }
        return 0;
#endif
    }
};

void clearScreen() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

void displayWelcome() {
    clearScreen();
    std::cout << R"(
    ╔════════════════════════════════════════════════════════════╗
    ║                                                            ║
    ║         ██████╗ ██╗ █████╗ ███╗   ██╗ ██████╗            ║
    ║         ██╔══██╗██║██╔══██╗████╗  ██║██╔═══██╗           ║
    ║         ██████╔╝██║███████║██╔██╗ ██║██║   ██║           ║
    ║         ██╔═══╝ ██║██╔══██║██║╚██╗██║██║   ██║           ║
    ║         ██║     ██║██║  ██║██║ ╚████║╚██████╔╝           ║
    ║         ╚═╝     ╚═╝╚═╝  ╚═╝╚═╝  ╚═══╝ ╚═════╝            ║
    ║                                                            ║
    ║              C++ QWERTY Piano Simulator                    ║
    ║                   Version 1.0                              ║
    ║                                                            ║
    ╚════════════════════════════════════════════════════════════╝

    Features:
    ✓ QWERTY keyboard input (3 octaves)
    ✓ Octave shifting (±3 octaves)
    ✓ Velocity control (0-127)
    ✓ Sustain pedal
    ✓ Recording & playback
    ✓ MIDI import/export support
    
    Press F11 for help, or any key to start...
    )" << std::endl;
}

int main(int argc, char* argv[]) {
    displayWelcome();
    
    KeyboardInput input;
    Piano piano;
    
    // Wait for initial keypress
    while (!input.getKey()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    
    clearScreen();
    piano.displayKeyboard();
    piano.displayHelp();
    
    std::cout << "\nPiano ready! Start playing...\n" << std::endl;
    
    std::map<char, bool> keyStates;
    
    while (running) {
        int key = input.getKey();
        
        if (key != 0) {
            char c = static_cast<char>(key);
            
            // Check for special keys
            if (input.isSpecialKey(key)) {
                int specialKey = input.getSpecialKey();
                
                // Function keys (platform-specific handling)
                switch (specialKey) {
                    case 59: case 72: // F1
                        piano.startRecording();
                        break;
                    case 60: case 80: // F2
                        piano.stopRecording();
                        break;
                    case 61: // F3
                        if (!piano.isRecording()) {
                            std::cout << "Enter filename to save: ";
                            std::string filename;
                            std::cin >> filename;
                            piano.saveRecording(filename + ".mid");
                        }
                        break;
                    case 63: // F5
                        std::cout << "Enter MIDI filename to load: ";
                        {
                            std::string filename;
                            std::cin >> filename;
                            piano.loadMidiFile(filename);
                        }
                        break;
                    case 64: // F6
                        piano.playMidiSequence();
                        break;
                    case 68: // F10
                        piano.displayKeyboard();
                        break;
                    case 133: // F11
                        piano.displayHelp();
                        break;
                    case 134: // F12
                        piano.displayStatus();
                        break;
                }
            }
            // Regular keys
            else if (c == 27) { // ESC
                std::cout << "\nExiting piano... Goodbye! 🎹\n" << std::endl;
                running = false;
                break;
            }
            else if (c == '[') {
                piano.decreaseOctave();
            }
            else if (c == ']') {
                piano.increaseOctave();
            }
            else if (c == '-' || c == '_') {
                piano.setVelocity(piano.getVelocity() - 10);
            }
            else if (c == '=' || c == '+') {
                piano.setVelocity(piano.getVelocity() + 10);
            }
            else if (c == ' ') {
                piano.toggleSustain();
            }
            else if (c == 'l' || c == 'L') {
                std::cout << "Enter MIDI filename to load: ";
                std::string filename;
                std::getline(std::cin, filename);
                if (!filename.empty()) {
                    piano.loadMidiFile(filename);
                }
            }
            else if (c == 'k' || c == 'K') {
                piano.displayKeyboard();
            }
            else if (c == 'h' || c == 'H') {
                piano.displayHelp();
            }
            else if (c == '?') {
                piano.displayStatus();
            }
            else {
                // Check if it's a note key
                if (!keyStates[c]) {
                    piano.playNote(c);
                    keyStates[c] = true;
                }
            }
        }
        
        // Handle key release (simplified - in real implementation you'd track this better)
        for (auto& ks : keyStates) {
            if (ks.second) {
                // Check if key is still pressed (simplified logic)
                ks.second = false;
            }
        }
        
        std::this_thread::sleep_for(std::chrono::milliseconds(10));
    }
    
    return 0;
}
