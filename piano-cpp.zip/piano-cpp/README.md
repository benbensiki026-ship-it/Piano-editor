# 🎹 C++ QWERTY Piano

A feature-rich command-line piano simulator that uses your QWERTY keyboard as a musical instrument!

## Features

✨ **Core Features:**
- 🎵 Play piano using QWERTY keyboard (3 octaves simultaneously)
- 🎚️ Octave shifting (±3 octaves, total range of 6+ octaves)
- 🔊 Velocity control (0-127)
- 🎛️ Sustain pedal toggle
- 📊 Real-time frequency display

📼 **Recording & Playback:**
- ⏺️ Record your performances
- 💾 Save recordings to MIDI files
- 📂 Load and play MIDI files
- 🎼 Export your compositions

🖥️ **User Interface:**
- 📋 Interactive help menu
- ⌨️ Visual keyboard layout display
- 📊 Real-time status information
- 🎨 Beautiful ASCII art interface

## Keyboard Layout

### Piano Keys

```
Top Row:    I  9  O  0  P         (C5, C#5, D5, D#5, E5)
Middle Row: Q  2  W  3  E  R  5  T  6  Y  7  U    (C4 - B4)
Bottom Row: Z  S  X  D  C  V  G  B  H  N  J  M    (C3 - B3)

Black keys (sharps/flats): 2, 3, 5, 6, 7, 9, 0, S, D, G, H, J
```

### Controls

| Key | Function |
|-----|----------|
| `[` | Decrease octave |
| `]` | Increase octave |
| `-` | Decrease velocity |
| `=` | Increase velocity |
| `SPACE` | Toggle sustain pedal |

### Function Keys

| Key | Function |
|-----|----------|
| `F1` | Start recording |
| `F2` | Stop recording |
| `F3` | Save recording |
| `F5` | Load MIDI file |
| `F6` | Play MIDI sequence |
| `F10` | Display keyboard layout |
| `F11` | Display help menu |
| `F12` | Display status |
| `ESC` | Exit program |

### Alternative Keys (for easier access)

| Key | Function |
|-----|----------|
| `L` | Load MIDI file |
| `K` | Display keyboard layout |
| `H` | Display help menu |
| `?` | Display status |

## Building the Program

### Prerequisites

- C++ compiler with C++17 support (g++, clang++)
- Make (optional, for using Makefile)
- Linux, macOS, or Windows with MinGW/WSL

### Compilation

**Using Make:**
```bash
make
```

**Manual compilation:**
```bash
g++ -std=c++17 -Wall -Wextra -O2 -o piano main.cpp piano.cpp
```

**Windows (MinGW):**
```bash
g++ -std=c++17 -Wall -Wextra -O2 -o piano.exe main.cpp piano.cpp
```

## Running the Program

```bash
./piano
```

On Windows:
```bash
piano.exe
```

## MIDI File Support

### Importing MIDI Files

1. Press `F5` or `L` during runtime
2. Enter the filename (with or without .mid extension)
3. The program will load and parse the MIDI file

### Recording and Exporting

1. Press `F1` to start recording
2. Play your composition
3. Press `F2` to stop recording
4. Press `F3` to save (you'll be prompted for a filename)

**Note:** The current implementation provides basic MIDI support. Full MIDI parsing and playback require additional libraries like:
- RtMidi (for real-time MIDI I/O)
- Midifile library
- PortAudio (for audio output)

## Usage Examples

### Playing a Simple Melody

1. Start the program
2. Press `Z` (C), `X` (D), `C` (E), `V` (F), `B` (G) for a C major scale
3. Use `]` to shift up an octave and play higher notes

### Recording a Performance

1. Press `F1` to start recording
2. Play your melody
3. Press `F2` when finished
4. Press `F3` and enter a filename like "my_song"
5. Your recording will be saved as "my_song.mid"

### Adjusting Dynamics

1. Press `=` repeatedly to increase velocity (louder)
2. Press `-` repeatedly to decrease velocity (softer)
3. Press `F12` to check current velocity level

### Using Sustain Pedal

1. Press `SPACE` to enable sustain
2. Notes will continue ringing after you release keys
3. Press `SPACE` again to disable sustain

## Technical Details

### Note Range

- Default octave: C4 (Middle C)
- Octave range: C1 to C7 with octave shifting
- MIDI note range: 0-127 supported
- Frequency calculation: A4 = 440 Hz standard tuning

### Architecture

- `piano.h` - Class definitions and interfaces
- `piano.cpp` - Core piano logic and MIDI handling
- `main.cpp` - User interface and input handling
- Cross-platform keyboard input (Windows & Unix-like systems)

## Limitations and Future Improvements

**Current Limitations:**
- No audio output (displays note information only)
- Simplified MIDI parsing
- No chord detection
- Single-threaded input handling

**Potential Enhancements:**
- Add audio synthesis (PortAudio, SDL2)
- Full MIDI file parsing and playback
- Multiple instrument sounds
- Metronome and tempo control
- Visual piano key highlighting
- Save/load custom key mappings
- MIDI keyboard input support
- Reverb and effects

## Troubleshooting

**Keys not responding:**
- Make sure the terminal window is in focus
- Try running in a different terminal emulator
- Check if your terminal supports the input mode

**Function keys not working:**
- Use alternative keys (L, K, H, ?)
- Different terminals may handle function keys differently

**Compilation errors:**
- Ensure C++17 support: `g++ --version`
- Try compiling with `-std=c++14` if c++17 isn't available

## License

This is free and open source software. Feel free to modify and distribute.

## Contributing

Contributions welcome! Areas for improvement:
- Audio output implementation
- Advanced MIDI features
- Better cross-platform support
- GUI version
- Additional instruments

## Author

Created with C++ for music enthusiasts and programmers alike! 🎼

---

**Enjoy making music with your keyboard!** 🎹✨
