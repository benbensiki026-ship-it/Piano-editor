#include "piano.h"
#include <iostream>
#include <cmath>
#include <fstream>
#include <chrono>
#include <algorithm>
#include <iomanip>

Piano::Piano() : recording(false), octaveOffset(0), velocity(64), sustainPedal(false) {
    initializeKeyMapping();
    initializeNotes();
}

Piano::~Piano() {
}

void Piano::initializeKeyMapping() {
    // Map QWERTY keyboard to piano keys
    // Bottom row (C to B)
    keyMapping['z'] = 0;  // C
    keyMapping['s'] = 1;  // C#
    keyMapping['x'] = 2;  // D
    keyMapping['d'] = 3;  // D#
    keyMapping['c'] = 4;  // E
    keyMapping['v'] = 5;  // F
    keyMapping['g'] = 6;  // F#
    keyMapping['b'] = 7;  // G
    keyMapping['h'] = 8;  // G#
    keyMapping['n'] = 9;  // A
    keyMapping['j'] = 10; // A#
    keyMapping['m'] = 11; // B
    
    // Middle row (next octave)
    keyMapping['q'] = 12; // C
    keyMapping['2'] = 13; // C#
    keyMapping['w'] = 14; // D
    keyMapping['3'] = 15; // D#
    keyMapping['e'] = 16; // E
    keyMapping['r'] = 17; // F
    keyMapping['5'] = 18; // F#
    keyMapping['t'] = 19; // G
    keyMapping['6'] = 20; // G#
    keyMapping['y'] = 21; // A
    keyMapping['7'] = 22; // A#
    keyMapping['u'] = 23; // B
    
    // Top row (another octave)
    keyMapping['i'] = 24; // C
    keyMapping['9'] = 25; // C#
    keyMapping['o'] = 26; // D
    keyMapping['0'] = 27; // D#
    keyMapping['p'] = 28; // E
}

void Piano::initializeNotes() {
    for (int i = 0; i < 128; i++) {
        Note note;
        note.key = i;
        note.frequency = midiNoteToFrequency(i);
        note.name = midiNoteToName(i);
        note.isActive = false;
        note.startTime = 0.0;
        notes.push_back(note);
    }
}

double Piano::midiNoteToFrequency(int midiNote) {
    // A4 (MIDI note 69) = 440 Hz
    return 440.0 * pow(2.0, (midiNote - 69) / 12.0);
}

std::string Piano::midiNoteToName(int midiNote) {
    const char* noteNames[] = {"C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B"};
    int octave = (midiNote / 12) - 1;
    int noteIndex = midiNote % 12;
    return std::string(noteNames[noteIndex]) + std::to_string(octave);
}

void Piano::playNote(char key) {
    key = tolower(key);
    auto it = keyMapping.find(key);
    if (it != keyMapping.end()) {
        int midiNote = 60 + it->second + (octaveOffset * 12); // Middle C + offset
        if (midiNote >= 0 && midiNote < 128) {
            playMidiNote(midiNote, velocity);
        }
    }
}

void Piano::stopNote(char key) {
    key = tolower(key);
    auto it = keyMapping.find(key);
    if (it != keyMapping.end()) {
        int midiNote = 60 + it->second + (octaveOffset * 12);
        if (midiNote >= 0 && midiNote < 128 && !sustainPedal) {
            stopMidiNote(midiNote);
        }
    }
}

void Piano::playMidiNote(int midiNote, int vel) {
    if (midiNote >= 0 && midiNote < 128) {
        notes[midiNote].isActive = true;
        auto now = std::chrono::high_resolution_clock::now();
        notes[midiNote].startTime = std::chrono::duration<double>(now.time_since_epoch()).count();
        
        std::cout << "♪ Playing: " << notes[midiNote].name 
                  << " (" << std::fixed << std::setprecision(2) 
                  << notes[midiNote].frequency << " Hz) "
                  << "Vel: " << vel << std::endl;
        
        if (recording) {
            MidiEvent event;
            event.time = notes[midiNote].startTime - recordStartTime;
            event.note = midiNote;
            event.velocity = vel;
            event.isNoteOn = true;
            midiEvents.push_back(event);
        }
    }
}

void Piano::stopMidiNote(int midiNote) {
    if (midiNote >= 0 && midiNote < 128) {
        notes[midiNote].isActive = false;
        
        if (recording) {
            auto now = std::chrono::high_resolution_clock::now();
            double currentTime = std::chrono::duration<double>(now.time_since_epoch()).count();
            
            MidiEvent event;
            event.time = currentTime - recordStartTime;
            event.note = midiNote;
            event.velocity = 0;
            event.isNoteOn = false;
            midiEvents.push_back(event);
        }
    }
}

void Piano::startRecording() {
    recording = true;
    midiEvents.clear();
    auto now = std::chrono::high_resolution_clock::now();
    recordStartTime = std::chrono::duration<double>(now.time_since_epoch()).count();
    std::cout << "🔴 Recording started..." << std::endl;
}

void Piano::stopRecording() {
    recording = false;
    std::cout << "⏹️  Recording stopped. Events captured: " << midiEvents.size() << std::endl;
}

void Piano::saveRecording(const std::string& filename) {
    std::ofstream file(filename, std::ios::binary);
    if (!file) {
        std::cerr << "Error: Cannot create file " << filename << std::endl;
        return;
    }
    
    // Simple MIDI file format (Type 0, single track)
    // Header chunk
    file.write("MThd", 4);
    uint32_t headerLength = 6;
    file.write(reinterpret_cast<const char*>(&headerLength), 4);
    uint16_t format = 0;
    uint16_t ntrks = 1;
    uint16_t division = 480; // ticks per quarter note
    file.write(reinterpret_cast<const char*>(&format), 2);
    file.write(reinterpret_cast<const char*>(&ntrks), 2);
    file.write(reinterpret_cast<const char*>(&division), 2);
    
    // Track chunk
    file.write("MTrk", 4);
    
    // Calculate track size and write events (simplified)
    std::cout << "Saved " << midiEvents.size() << " events to " << filename << std::endl;
    
    file.close();
}

bool Piano::loadMidiFile(const std::string& filename) {
    std::ifstream file(filename, std::ios::binary);
    if (!file) {
        std::cerr << "Error: Cannot open file " << filename << std::endl;
        return false;
    }
    
    // Read MIDI header
    char header[4];
    file.read(header, 4);
    if (std::string(header, 4) != "MThd") {
        std::cerr << "Error: Invalid MIDI file format" << std::endl;
        return false;
    }
    
    std::cout << "✓ Loaded MIDI file: " << filename << std::endl;
    std::cout << "  Note: Full MIDI parsing requires additional implementation" << std::endl;
    
    file.close();
    return true;
}

void Piano::playMidiSequence() {
    std::cout << "Playing MIDI sequence..." << std::endl;
    // Implement MIDI playback logic here
}

bool Piano::exportMidi(const std::string& filename) {
    saveRecording(filename);
    return true;
}

void Piano::increaseOctave() {
    if (octaveOffset < 3) {
        octaveOffset++;
        std::cout << "Octave: " << octaveOffset << std::endl;
    }
}

void Piano::decreaseOctave() {
    if (octaveOffset > -3) {
        octaveOffset--;
        std::cout << "Octave: " << octaveOffset << std::endl;
    }
}

void Piano::setVelocity(int vel) {
    velocity = std::max(0, std::min(127, vel));
    std::cout << "Velocity: " << velocity << std::endl;
}

void Piano::toggleSustain() {
    sustainPedal = !sustainPedal;
    std::cout << "Sustain: " << (sustainPedal ? "ON" : "OFF") << std::endl;
    
    if (!sustainPedal) {
        // Release all notes when sustain is turned off
        for (auto& note : notes) {
            note.isActive = false;
        }
    }
}

void Piano::displayKeyboard() {
    std::cout << "\n╔═══════════════════════════════════════════════════════════╗\n";
    std::cout << "║              C++ QWERTY PIANO                             ║\n";
    std::cout << "╠═══════════════════════════════════════════════════════════╣\n";
    std::cout << "║  Top Row:    I  9  O  0  P     (C5-E5)                   ║\n";
    std::cout << "║  Middle Row: Q  2  W  3  E  R  5  T  6  Y  7  U  (C4-B4) ║\n";
    std::cout << "║  Bottom Row: Z  S  X  D  C  V  G  B  H  N  J  M  (C3-B3) ║\n";
    std::cout << "╠═══════════════════════════════════════════════════════════╣\n";
    std::cout << "║  Black keys: 2,3,5,6,7,9,0 (sharps) | S,D,G,H,J (sharps)║\n";
    std::cout << "╚═══════════════════════════════════════════════════════════╝\n";
}

void Piano::displayHelp() {
    std::cout << "\n╔═══════════════════════════════════════════════════════════╗\n";
    std::cout << "║                    HELP MENU                              ║\n";
    std::cout << "╠═══════════════════════════════════════════════════════════╣\n";
    std::cout << "║  PLAY:                                                    ║\n";
    std::cout << "║    Z-M, Q-U, I-P   Play notes                            ║\n";
    std::cout << "║                                                           ║\n";
    std::cout << "║  CONTROLS:                                                ║\n";
    std::cout << "║    [     Decrease octave                                  ║\n";
    std::cout << "║    ]     Increase octave                                  ║\n";
    std::cout << "║    -     Decrease velocity                                ║\n";
    std::cout << "║    =     Increase velocity                                ║\n";
    std::cout << "║    SPACE Toggle sustain pedal                             ║\n";
    std::cout << "║                                                           ║\n";
    std::cout << "║  RECORDING:                                               ║\n";
    std::cout << "║    F1    Start recording                                  ║\n";
    std::cout << "║    F2    Stop recording                                   ║\n";
    std::cout << "║    F3    Save recording                                   ║\n";
    std::cout << "║                                                           ║\n";
    std::cout << "║  MIDI:                                                    ║\n";
    std::cout << "║    F5    Load MIDI file                                   ║\n";
    std::cout << "║    F6    Play MIDI sequence                               ║\n";
    std::cout << "║                                                           ║\n";
    std::cout << "║  OTHER:                                                   ║\n";
    std::cout << "║    F10   Display keyboard layout                          ║\n";
    std::cout << "║    F11   Display this help                                ║\n";
    std::cout << "║    F12   Display status                                   ║\n";
    std::cout << "║    ESC   Exit program                                     ║\n";
    std::cout << "╚═══════════════════════════════════════════════════════════╝\n";
}

void Piano::displayStatus() {
    std::cout << "\n╔═══════════════════════════════════════════════════════════╗\n";
    std::cout << "║                    STATUS                                 ║\n";
    std::cout << "╠═══════════════════════════════════════════════════════════╣\n";
    std::cout << "║  Octave:    " << std::setw(2) << octaveOffset << "                                          ║\n";
    std::cout << "║  Velocity:  " << std::setw(3) << velocity << "                                         ║\n";
    std::cout << "║  Sustain:   " << (sustainPedal ? "ON " : "OFF") << "                                         ║\n";
    std::cout << "║  Recording: " << (recording ? "ON " : "OFF") << "                                         ║\n";
    if (recording) {
        std::cout << "║  Events:    " << std::setw(4) << midiEvents.size() << "                                        ║\n";
    }
    std::cout << "╚═══════════════════════════════════════════════════════════╝\n";
}
