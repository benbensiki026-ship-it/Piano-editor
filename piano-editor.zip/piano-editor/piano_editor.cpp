#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <iostream>
#include <vector>
#include <string>
#include <cmath>
#include <fstream>
#include <algorithm>
#include <map>
#include <sstream>
#include <iomanip>

// Forward declarations
struct MIDINote {
    int note;
    double startTime;
    double duration;
    int velocity;
    bool selected;
    
    MIDINote() : note(0), startTime(0), duration(0), velocity(64), selected(false) {}
    MIDINote(int n, double s, double d, int v = 64) 
        : note(n), startTime(s), duration(d), velocity(v), selected(false) {}
};

struct WaterfallNote {
    int note;
    double y;
    double height;
    SDL_Color color;
    bool active;
};

enum class Mode {
    PLAYBACK,
    EDIT,
    RECORD
};

enum class Tool {
    SELECT,
    PENCIL,
    ERASER,
    MOVE
};

class PianoEditor {
private:
    SDL_Window* window;
    SDL_Renderer* renderer;
    TTF_Font* fontLarge;
    TTF_Font* fontSmall;
    
    const int SCREEN_WIDTH = 1800;
    const int SCREEN_HEIGHT = 1000;
    const int MENU_BAR_HEIGHT = 40;
    const int KEYBOARD_HEIGHT = 200;
    const int WATERFALL_HEIGHT = 760 - MENU_BAR_HEIGHT;
    const int TIMELINE_HEIGHT = 50;
    
    const int NUM_KEYS = 88;
    const int WHITE_KEY_WIDTH = 20;
    const int BLACK_KEY_WIDTH = 12;
    const int BLACK_KEY_HEIGHT = 120;
    
    std::vector<MIDINote> midiNotes;
    std::vector<WaterfallNote> waterfallNotes;
    std::vector<bool> keyPressed;
    std::vector<bool> recordedKeys;
    
    Mode currentMode;
    Tool currentTool;
    bool isPlaying;
    bool isRecording;
    double currentTime;
    double playbackSpeed;
    int scrollOffset;
    double recordStartTime;
    
    // Editor state
    bool isDragging;
    bool isSelecting;
    SDL_Point dragStart;
    SDL_Point dragCurrent;
    double snapGrid;
    bool showGrid;
    std::string filename;
    bool hasUnsavedChanges;
    
    // Menu state
    bool showFileMenu;
    bool showEditMenu;
    bool showToolsMenu;
    bool showHelpMenu;
    SDL_Rect fileMenuRect;
    SDL_Rect editMenuRect;
    SDL_Rect toolsMenuRect;
    SDL_Rect helpMenuRect;
    
    // Key layout
    std::vector<bool> isWhiteKey;
    std::vector<int> keyPositions;
    
    // Colors
    SDL_Color bgColor = {15, 15, 20, 255};
    SDL_Color menuBarColor = {30, 30, 40, 255};
    SDL_Color menuHighlightColor = {50, 50, 70, 255};
    SDL_Color gridColor = {40, 40, 50, 255};
    SDL_Color selectionColor = {100, 150, 255, 100};
    SDL_Color noteColor = {100, 180, 255, 200};
    SDL_Color noteSelectedColor = {255, 200, 100, 220};
    
public:
    PianoEditor() : window(nullptr), renderer(nullptr), fontLarge(nullptr), fontSmall(nullptr),
                    currentMode(Mode::PLAYBACK), currentTool(Tool::SELECT),
                    isPlaying(false), isRecording(false), currentTime(0.0), 
                    playbackSpeed(1.0), scrollOffset(0), recordStartTime(0.0),
                    isDragging(false), isSelecting(false), snapGrid(0.25), 
                    showGrid(true), filename("untitled.mid"), hasUnsavedChanges(false),
                    showFileMenu(false), showEditMenu(false), showToolsMenu(false), 
                    showHelpMenu(false) {
        keyPressed.resize(NUM_KEYS, false);
        recordedKeys.resize(NUM_KEYS, false);
        initializeKeyLayout();
    }
    
    ~PianoEditor() {
        cleanup();
    }
    
    bool initialize() {
        if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) {
            std::cerr << "SDL initialization failed: " << SDL_GetError() << std::endl;
            return false;
        }
        
        if (TTF_Init() < 0) {
            std::cerr << "TTF initialization failed: " << TTF_GetError() << std::endl;
            return false;
        }
        
        window = SDL_CreateWindow(
            "Piano Editor - Music Composition Studio",
            SDL_WINDOWPOS_CENTERED,
            SDL_WINDOWPOS_CENTERED,
            SCREEN_WIDTH,
            SCREEN_HEIGHT,
            SDL_WINDOW_SHOWN | SDL_WINDOW_RESIZABLE
        );
        
        if (!window) {
            std::cerr << "Window creation failed: " << SDL_GetError() << std::endl;
            return false;
        }
        
        renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
        if (!renderer) {
            std::cerr << "Renderer creation failed: " << SDL_GetError() << std::endl;
            return false;
        }
        
        // Load fonts
        fontLarge = TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 16);
        fontSmall = TTF_OpenFont("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", 12);
        
        if (!fontLarge) {
            fontLarge = TTF_OpenFont("/System/Library/Fonts/Helvetica.ttc", 16);
            fontSmall = TTF_OpenFont("/System/Library/Fonts/Helvetica.ttc", 12);
        }
        
        return true;
    }
    
    void initializeKeyLayout() {
        const bool pattern[12] = {true, false, true, false, true, true, false, true, false, true, false, true};
        
        for (int i = 0; i < NUM_KEYS; i++) {
            int noteInOctave = (i + 9) % 12;
            isWhiteKey.push_back(pattern[noteInOctave]);
        }
        
        int xPos = 50;
        for (int i = 0; i < NUM_KEYS; i++) {
            keyPositions.push_back(xPos);
            if (isWhiteKey[i]) {
                xPos += WHITE_KEY_WIDTH;
            }
        }
    }
    
    void loadMIDIFile(const std::string& filepath) {
        midiNotes.clear();
        std::ifstream file(filepath, std::ios::binary);
        
        if (!file.is_open()) {
            std::cerr << "Could not open MIDI file: " << filepath << std::endl;
            return;
        }
        
        // Simple MIDI parser
        char header[14];
        file.read(header, 14);
        
        if (std::string(header, 4) != "MThd") {
            std::cerr << "Invalid MIDI file" << std::endl;
            return;
        }
        
        std::map<int, double> noteOnTimes;
        double currentTime = 0.0;
        int tempo = 500000;
        
        while (!file.eof()) {
            char trackHeader[8];
            file.read(trackHeader, 8);
            
            if (file.gcount() < 8) break;
            if (std::string(trackHeader, 4) != "MTrk") continue;
            
            int trackLength = (unsigned char)trackHeader[4] << 24 | 
                            (unsigned char)trackHeader[5] << 16 |
                            (unsigned char)trackHeader[6] << 8 | 
                            (unsigned char)trackHeader[7];
            
            int bytesRead = 0;
            int lastStatus = 0;
            
            while (bytesRead < trackLength && !file.eof()) {
                int deltaTime = 0;
                unsigned char byte;
                do {
                    file.read((char*)&byte, 1);
                    bytesRead++;
                    deltaTime = (deltaTime << 7) | (byte & 0x7F);
                } while (byte & 0x80);
                
                currentTime += deltaTime * (tempo / 1000000.0) / 480.0;
                
                unsigned char status;
                file.read((char*)&status, 1);
                bytesRead++;
                
                if (status < 0x80) {
                    status = lastStatus;
                    file.seekg(-1, std::ios::cur);
                    bytesRead--;
                } else {
                    lastStatus = status;
                }
                
                int eventType = status & 0xF0;
                
                if (eventType == 0x90) {
                    unsigned char note, velocity;
                    file.read((char*)&note, 1);
                    file.read((char*)&velocity, 1);
                    bytesRead += 2;
                    
                    if (velocity > 0) {
                        noteOnTimes[note] = currentTime;
                    } else {
                        if (noteOnTimes.find(note) != noteOnTimes.end()) {
                            int noteNum = note - 21;
                            if (noteNum >= 0 && noteNum < 88) {
                                midiNotes.push_back(MIDINote(noteNum, noteOnTimes[note], 
                                                            currentTime - noteOnTimes[note], velocity));
                            }
                            noteOnTimes.erase(note);
                        }
                    }
                } else if (eventType == 0x80) {
                    unsigned char note, velocity;
                    file.read((char*)&note, 1);
                    file.read((char*)&velocity, 1);
                    bytesRead += 2;
                    
                    if (noteOnTimes.find(note) != noteOnTimes.end()) {
                        int noteNum = note - 21;
                        if (noteNum >= 0 && noteNum < 88) {
                            midiNotes.push_back(MIDINote(noteNum, noteOnTimes[note], 
                                                        currentTime - noteOnTimes[note], velocity));
                        }
                        noteOnTimes.erase(note);
                    }
                } else if (eventType == 0xB0 || eventType == 0xE0) {
                    file.seekg(2, std::ios::cur);
                    bytesRead += 2;
                } else if (eventType == 0xC0 || eventType == 0xD0) {
                    file.seekg(1, std::ios::cur);
                    bytesRead += 1;
                } else if (status == 0xFF) {
                    unsigned char type;
                    file.read((char*)&type, 1);
                    bytesRead++;
                    
                    int length = 0;
                    do {
                        file.read((char*)&byte, 1);
                        bytesRead++;
                        length = (length << 7) | (byte & 0x7F);
                    } while (byte & 0x80);
                    
                    if (type == 0x51 && length == 3) {
                        unsigned char t[3];
                        file.read((char*)t, 3);
                        tempo = (t[0] << 16) | (t[1] << 8) | t[2];
                        bytesRead += 3;
                    } else {
                        file.seekg(length, std::ios::cur);
                        bytesRead += length;
                    }
                } else {
                    break;
                }
            }
        }
        
        file.close();
        filename = filepath;
        hasUnsavedChanges = false;
        
        std::sort(midiNotes.begin(), midiNotes.end(), 
                 [](const MIDINote& a, const MIDINote& b) { return a.startTime < b.startTime; });
        
        std::cout << "Loaded " << midiNotes.size() << " notes from " << filepath << std::endl;
    }
    
    void saveMIDIFile(const std::string& filepath) {
        std::ofstream file(filepath, std::ios::binary);
        
        if (!file.is_open()) {
            std::cerr << "Could not save MIDI file: " << filepath << std::endl;
            return;
        }
        
        // Write header
        file.write("MThd", 4);
        file.put(0); file.put(0); file.put(0); file.put(6); // Length
        file.put(0); file.put(0); // Format 0
        file.put(0); file.put(1); // 1 track
        file.put(1); file.put(0xE0); // 480 ticks per quarter
        
        // Prepare track data
        std::vector<unsigned char> trackData;
        
        // Set tempo
        trackData.push_back(0); // Delta time
        trackData.push_back(0xFF);
        trackData.push_back(0x51);
        trackData.push_back(0x03);
        trackData.push_back(0x07);
        trackData.push_back(0xA1);
        trackData.push_back(0x20); // 120 BPM
        
        // Sort notes by start time
        std::vector<std::pair<double, MIDINote>> events;
        for (const auto& note : midiNotes) {
            events.push_back({note.startTime, note});
            events.push_back({note.startTime + note.duration, note});
        }
        std::sort(events.begin(), events.end());
        
        double lastTime = 0.0;
        for (size_t i = 0; i < events.size(); i += 2) {
            if (i >= events.size()) break;
            
            const auto& noteOn = events[i].second;
            double deltaTime = (events[i].first - lastTime) * 480.0;
            
            // Write delta time
            int dt = (int)deltaTime;
            if (dt < 128) {
                trackData.push_back(dt);
            } else {
                trackData.push_back(0x81);
                trackData.push_back(0x70);
            }
            
            // Note On
            trackData.push_back(0x90);
            trackData.push_back(noteOn.note + 21);
            trackData.push_back(noteOn.velocity);
            
            // Note Off
            dt = (int)(noteOn.duration * 480.0);
            if (dt < 128) {
                trackData.push_back(dt);
            } else {
                trackData.push_back(0x81);
                trackData.push_back(0x70);
            }
            
            trackData.push_back(0x80);
            trackData.push_back(noteOn.note + 21);
            trackData.push_back(0);
            
            lastTime = events[i].first + noteOn.duration;
        }
        
        // End of track
        trackData.push_back(0);
        trackData.push_back(0xFF);
        trackData.push_back(0x2F);
        trackData.push_back(0);
        
        // Write track header
        file.write("MTrk", 4);
        int trackLen = trackData.size();
        file.put((trackLen >> 24) & 0xFF);
        file.put((trackLen >> 16) & 0xFF);
        file.put((trackLen >> 8) & 0xFF);
        file.put(trackLen & 0xFF);
        
        // Write track data
        file.write((char*)trackData.data(), trackData.size());
        file.close();
        
        filename = filepath;
        hasUnsavedChanges = false;
        
        std::cout << "Saved " << midiNotes.size() << " notes to " << filepath << std::endl;
    }
    
    void addNote(int noteNum, double time, double duration, int velocity = 64) {
        if (snapGrid > 0) {
            time = std::round(time / snapGrid) * snapGrid;
            duration = std::round(duration / snapGrid) * snapGrid;
        }
        midiNotes.push_back(MIDINote(noteNum, time, duration, velocity));
        hasUnsavedChanges = true;
    }
    
    void deleteSelectedNotes() {
        midiNotes.erase(
            std::remove_if(midiNotes.begin(), midiNotes.end(),
                          [](const MIDINote& n) { return n.selected; }),
            midiNotes.end()
        );
        hasUnsavedChanges = true;
    }
    
    void clearSelection() {
        for (auto& note : midiNotes) {
            note.selected = false;
        }
    }
    
    void selectNotesInRect(SDL_Rect rect) {
        for (auto& note : midiNotes) {
            int x = (int)(note.startTime * 100) + 50 - scrollOffset;
            int y = MENU_BAR_HEIGHT + WATERFALL_HEIGHT - (note.note * 8);
            int w = (int)(note.duration * 100);
            int h = 8;
            
            SDL_Rect noteRect = {x, y, w, h};
            if (SDL_HasIntersection(&rect, &noteRect)) {
                note.selected = true;
            }
        }
    }
    
    void updateWaterfall(double deltaTime) {
        if (!isPlaying) return;
        
        currentTime += deltaTime * playbackSpeed;
        
        for (auto& note : waterfallNotes) {
            note.y += deltaTime * 200 * playbackSpeed;
            
            double noteScreenTime = (WATERFALL_HEIGHT - note.y) / 200.0;
            if (noteScreenTime <= 0 && !note.active) {
                note.active = true;
                keyPressed[note.note] = true;
            }
        }
        
        waterfallNotes.erase(
            std::remove_if(waterfallNotes.begin(), waterfallNotes.end(),
                          [this](const WaterfallNote& n) { return n.y > WATERFALL_HEIGHT + 100; }),
            waterfallNotes.end()
        );
        
        for (const auto& note : midiNotes) {
            if (note.startTime <= currentTime + 3.5 && 
                note.startTime > currentTime + 3.4) {
                WaterfallNote wn;
                wn.note = note.note;
                wn.y = -note.duration * 200;
                wn.height = note.duration * 200;
                
                int hue = (note.note * 30) % 360;
                wn.color = hsvToRgb(hue, 0.8, 0.9);
                wn.color.a = 200;
                wn.active = false;
                
                waterfallNotes.push_back(wn);
            }
        }
        
        for (int i = 0; i < NUM_KEYS; i++) {
            bool stillPressed = false;
            for (const auto& note : waterfallNotes) {
                if (note.note == i && note.active && note.y < WATERFALL_HEIGHT) {
                    stillPressed = true;
                    break;
                }
            }
            keyPressed[i] = stillPressed;
        }
    }
    
    void updateRecording(double deltaTime) {
        if (!isRecording) return;
        
        for (int i = 0; i < NUM_KEYS; i++) {
            if (keyPressed[i] && !recordedKeys[i]) {
                // Note started
                recordedKeys[i] = true;
            } else if (!keyPressed[i] && recordedKeys[i]) {
                // Note ended - add to MIDI
                double duration = 0.5; // Default duration
                addNote(i, recordStartTime, duration, 80);
                recordedKeys[i] = false;
            }
        }
        
        recordStartTime += deltaTime;
    }
    
    SDL_Color hsvToRgb(int h, double s, double v) {
        double c = v * s;
        double x = c * (1 - std::abs(std::fmod(h / 60.0, 2) - 1));
        double m = v - c;
        
        double r, g, b;
        if (h < 60) { r = c; g = x; b = 0; }
        else if (h < 120) { r = x; g = c; b = 0; }
        else if (h < 180) { r = 0; g = c; b = x; }
        else if (h < 240) { r = 0; g = x; b = c; }
        else if (h < 300) { r = x; g = 0; b = c; }
        else { r = c; g = 0; b = x; }
        
        SDL_Color color;
        color.r = (r + m) * 255;
        color.g = (g + m) * 255;
        color.b = (b + m) * 255;
        color.a = 255;
        return color;
    }
    
    void render() {
        SDL_SetRenderDrawColor(renderer, bgColor.r, bgColor.g, bgColor.b, 255);
        SDL_RenderClear(renderer);
        
        renderMenuBar();
        
        if (currentMode == Mode::PLAYBACK) {
            renderWaterfall();
        } else {
            renderPianoRoll();
        }
        
        renderKeyboard();
        renderStatusBar();
        
        SDL_RenderPresent(renderer);
    }
    
    void renderMenuBar() {
        SDL_SetRenderDrawColor(renderer, menuBarColor.r, menuBarColor.g, menuBarColor.b, 255);
        SDL_Rect menuBar = {0, 0, SCREEN_WIDTH, MENU_BAR_HEIGHT};
        SDL_RenderFillRect(renderer, &menuBar);
        
        if (!fontLarge) return;
        
        SDL_Color textColor = {200, 200, 200, 255};
        int xPos = 10;
        
        // File menu
        drawMenuButton("File", xPos, 10, showFileMenu);
        xPos += 60;
        
        // Edit menu
        drawMenuButton("Edit", xPos, 10, showEditMenu);
        xPos += 60;
        
        // Tools menu
        drawMenuButton("Tools", xPos, 10, showToolsMenu);
        xPos += 70;
        
        // View menu
        std::string modeText = "Mode: ";
        if (currentMode == Mode::PLAYBACK) modeText += "Playback";
        else if (currentMode == Mode::EDIT) modeText += "Edit";
        else modeText += "Record";
        drawText(modeText, xPos, 10, textColor);
        xPos += 150;
        
        // Tool indicator
        if (currentMode == Mode::EDIT) {
            std::string toolText = "Tool: ";
            if (currentTool == Tool::SELECT) toolText += "Select";
            else if (currentTool == Tool::PENCIL) toolText += "Pencil";
            else if (currentTool == Tool::ERASER) toolText += "Eraser";
            else toolText += "Move";
            drawText(toolText, xPos, 10, textColor);
        }
        
        // File status
        std::string fileStatus = filename;
        if (hasUnsavedChanges) fileStatus += " *";
        drawText(fileStatus, SCREEN_WIDTH - 300, 10, textColor);
    }
    
    void drawMenuButton(const std::string& text, int x, int y, bool highlighted) {
        if (!fontLarge) return;
        
        SDL_Color bgCol = highlighted ? menuHighlightColor : menuBarColor;
        SDL_SetRenderDrawColor(renderer, bgCol.r, bgCol.g, bgCol.b, 255);
        SDL_Rect buttonRect = {x - 5, y - 5, 55, 30};
        SDL_RenderFillRect(renderer, &buttonRect);
        
        SDL_Color textColor = {200, 200, 200, 255};
        drawText(text, x, y, textColor);
    }
    
    void drawText(const std::string& text, int x, int y, SDL_Color color) {
        if (!fontLarge) return;
        
        SDL_Surface* surface = TTF_RenderText_Blended(fontLarge, text.c_str(), color);
        if (surface) {
            SDL_Texture* texture = SDL_CreateTextureFromSurface(renderer, surface);
            SDL_Rect destRect = {x, y, surface->w, surface->h};
            SDL_RenderCopy(renderer, texture, NULL, &destRect);
            SDL_DestroyTexture(texture);
            SDL_FreeSurface(surface);
        }
    }
    
    void renderWaterfall() {
        int yOffset = MENU_BAR_HEIGHT;
        
        SDL_SetRenderDrawColor(renderer, 10, 10, 15, 255);
        SDL_Rect waterfallBg = {0, yOffset, SCREEN_WIDTH, WATERFALL_HEIGHT};
        SDL_RenderFillRect(renderer, &waterfallBg);
        
        if (showGrid) {
            SDL_SetRenderDrawColor(renderer, gridColor.r, gridColor.g, gridColor.b, 255);
            for (int i = 0; i < WATERFALL_HEIGHT; i += 50) {
                SDL_RenderDrawLine(renderer, 0, yOffset + i, SCREEN_WIDTH, yOffset + i);
            }
        }
        
        for (const auto& note : waterfallNotes) {
            if (note.note < 0 || note.note >= NUM_KEYS) continue;
            
            int x = keyPositions[note.note] - scrollOffset;
            int width = isWhiteKey[note.note] ? WHITE_KEY_WIDTH : BLACK_KEY_WIDTH;
            
            SDL_Rect noteRect;
            noteRect.x = x;
            noteRect.y = yOffset + note.y;
            noteRect.w = width;
            noteRect.h = note.height;
            
            SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
            SDL_SetRenderDrawColor(renderer, note.color.r, note.color.g, note.color.b, note.color.a);
            SDL_RenderFillRect(renderer, &noteRect);
            
            SDL_SetRenderDrawColor(renderer, note.color.r * 0.7, note.color.g * 0.7, note.color.b * 0.7, 255);
            SDL_RenderDrawRect(renderer, &noteRect);
        }
    }
    
    void renderPianoRoll() {
        int yOffset = MENU_BAR_HEIGHT;
        
        SDL_SetRenderDrawColor(renderer, 10, 10, 15, 255);
        SDL_Rect rollBg = {0, yOffset, SCREEN_WIDTH, WATERFALL_HEIGHT};
        SDL_RenderFillRect(renderer, &rollBg);
        
        // Draw grid
        if (showGrid) {
            SDL_SetRenderDrawColor(renderer, gridColor.r, gridColor.g, gridColor.b, 255);
            
            // Horizontal lines (notes)
            for (int i = 0; i < NUM_KEYS; i++) {
                int y = yOffset + WATERFALL_HEIGHT - (i * 8);
                if (isWhiteKey[i]) {
                    SDL_SetRenderDrawColor(renderer, 50, 50, 60, 255);
                } else {
                    SDL_SetRenderDrawColor(renderer, 30, 30, 40, 255);
                }
                SDL_RenderDrawLine(renderer, 0, y, SCREEN_WIDTH, y);
            }
            
            // Vertical lines (time)
            SDL_SetRenderDrawColor(renderer, gridColor.r, gridColor.g, gridColor.b, 255);
            for (int i = 0; i < 200; i++) {
                int x = (int)(i * snapGrid * 100) + 50 - scrollOffset;
                if (x < 0 || x > SCREEN_WIDTH) continue;
                SDL_RenderDrawLine(renderer, x, yOffset, x, yOffset + WATERFALL_HEIGHT);
            }
        }
        
        // Draw notes
        for (const auto& note : midiNotes) {
            int x = (int)(note.startTime * 100) + 50 - scrollOffset;
            int y = yOffset + WATERFALL_HEIGHT - (note.note * 8) - 8;
            int w = (int)(note.duration * 100);
            int h = 8;
            
            SDL_Rect noteRect = {x, y, w, h};
            
            SDL_Color color = note.selected ? noteSelectedColor : noteColor;
            SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
            SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, color.a);
            SDL_RenderFillRect(renderer, &noteRect);
            
            SDL_SetRenderDrawColor(renderer, color.r * 0.8, color.g * 0.8, color.b * 0.8, 255);
            SDL_RenderDrawRect(renderer, &noteRect);
        }
        
        // Draw selection rectangle
        if (isSelecting) {
            SDL_Rect selRect;
            selRect.x = std::min(dragStart.x, dragCurrent.x);
            selRect.y = std::min(dragStart.y, dragCurrent.y);
            selRect.w = std::abs(dragCurrent.x - dragStart.x);
            selRect.h = std::abs(dragCurrent.y - dragStart.y);
            
            SDL_SetRenderDrawBlendMode(renderer, SDL_BLENDMODE_BLEND);
            SDL_SetRenderDrawColor(renderer, selectionColor.r, selectionColor.g, 
                                  selectionColor.b, selectionColor.a);
            SDL_RenderFillRect(renderer, &selRect);
            
            SDL_SetRenderDrawColor(renderer, 100, 150, 255, 255);
            SDL_RenderDrawRect(renderer, &selRect);
        }
    }
    
    void renderKeyboard() {
        int yPos = MENU_BAR_HEIGHT + WATERFALL_HEIGHT;
        
        // White keys
        for (int i = 0; i < NUM_KEYS; i++) {
            if (!isWhiteKey[i]) continue;
            
            int x = keyPositions[i] - scrollOffset;
            SDL_Rect keyRect = {x, yPos, WHITE_KEY_WIDTH, KEYBOARD_HEIGHT};
            
            if (keyPressed[i]) {
                SDL_SetRenderDrawColor(renderer, 100, 255, 100, 255);
            } else {
                SDL_SetRenderDrawColor(renderer, 240, 240, 240, 255);
            }
            SDL_RenderFillRect(renderer, &keyRect);
            
            SDL_SetRenderDrawColor(renderer, 100, 100, 100, 255);
            SDL_RenderDrawRect(renderer, &keyRect);
        }
        
        // Black keys
        for (int i = 0; i < NUM_KEYS; i++) {
            if (isWhiteKey[i]) continue;
            
            int x = keyPositions[i] - scrollOffset - BLACK_KEY_WIDTH / 2;
            SDL_Rect keyRect = {x, yPos, BLACK_KEY_WIDTH, BLACK_KEY_HEIGHT};
            
            if (keyPressed[i]) {
                SDL_SetRenderDrawColor(renderer, 0, 200, 0, 255);
            } else {
                SDL_SetRenderDrawColor(renderer, 30, 30, 35, 255);
            }
            SDL_RenderFillRect(renderer, &keyRect);
            
            SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
            SDL_RenderDrawRect(renderer, &keyRect);
        }
    }
    
    void renderStatusBar() {
        if (!fontSmall) return;
        
        int yPos = SCREEN_HEIGHT - 25;
        SDL_Color textColor = {200, 200, 200, 255};
        
        std::stringstream status;
        status << "Time: " << std::fixed << std::setprecision(2) << currentTime << "s | ";
        status << "Speed: " << playbackSpeed << "x | ";
        status << "Notes: " << midiNotes.size() << " | ";
        status << "Grid: " << snapGrid << "s | ";
        
        if (isPlaying) status << "Playing";
        else if (isRecording) status << "Recording";
        else status << "Ready";
        
        drawText(status.str(), 10, yPos, textColor);
        
        std::string controls = "[SPACE] Play | [TAB] Mode | [E] Edit | [R] Record | [S] Save | [L] Load";
        drawText(controls, SCREEN_WIDTH - 800, yPos, textColor);
    }
    
    void handleInput() {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                SDL_Quit();
                exit(0);
            } else if (event.type == SDL_KEYDOWN) {
                handleKeyPress(event.key.keysym.sym);
            } else if (event.type == SDL_MOUSEBUTTONDOWN) {
                handleMouseDown(event.button);
            } else if (event.type == SDL_MOUSEBUTTONUP) {
                handleMouseUp(event.button);
            } else if (event.type == SDL_MOUSEMOTION) {
                handleMouseMotion(event.motion);
            }
        }
    }
    
    void handleKeyPress(SDL_Keycode key) {
        switch (key) {
            case SDLK_SPACE:
                if (currentMode == Mode::PLAYBACK) {
                    isPlaying = !isPlaying;
                }
                break;
            case SDLK_TAB:
                cycleMode();
                break;
            case SDLK_e:
                currentMode = Mode::EDIT;
                isPlaying = false;
                break;
            case SDLK_r:
                if (currentMode == Mode::RECORD) {
                    isRecording = !isRecording;
                    if (isRecording) {
                        recordStartTime = currentTime;
                    }
                } else {
                    currentMode = Mode::RECORD;
                }
                break;
            case SDLK_p:
                currentMode = Mode::PLAYBACK;
                break;
            case SDLK_s:
                if (SDL_GetModState() & KMOD_CTRL) {
                    saveMIDIFile(filename);
                }
                break;
            case SDLK_l:
                if (SDL_GetModState() & KMOD_CTRL) {
                    loadMIDIFile("song.mid");
                }
                break;
            case SDLK_n:
                if (SDL_GetModState() & KMOD_CTRL) {
                    newFile();
                }
                break;
            case SDLK_DELETE:
            case SDLK_BACKSPACE:
                if (currentMode == Mode::EDIT) {
                    deleteSelectedNotes();
                }
                break;
            case SDLK_a:
                if (SDL_GetModState() & KMOD_CTRL) {
                    selectAll();
                }
                break;
            case SDLK_g:
                showGrid = !showGrid;
                break;
            case SDLK_1:
                currentTool = Tool::SELECT;
                break;
            case SDLK_2:
                currentTool = Tool::PENCIL;
                break;
            case SDLK_3:
                currentTool = Tool::ERASER;
                break;
            case SDLK_EQUALS:
            case SDLK_PLUS:
                if (currentMode == Mode::EDIT) {
                    snapGrid = std::min(1.0, snapGrid * 2.0);
                } else {
                    playbackSpeed = std::min(3.0, playbackSpeed + 0.1);
                }
                break;
            case SDLK_MINUS:
                if (currentMode == Mode::EDIT) {
                    snapGrid = std::max(0.0625, snapGrid / 2.0);
                } else {
                    playbackSpeed = std::max(0.1, playbackSpeed - 0.1);
                }
                break;
            case SDLK_LEFT:
                scrollOffset = std::max(0, scrollOffset - 50);
                break;
            case SDLK_RIGHT:
                scrollOffset = std::min(2000, scrollOffset + 50);
                break;
            case SDLK_HOME:
                currentTime = 0.0;
                waterfallNotes.clear();
                std::fill(keyPressed.begin(), keyPressed.end(), false);
                break;
            case SDLK_q:
                if (SDL_GetModState() & KMOD_CTRL) {
                    SDL_Quit();
                    exit(0);
                }
                break;
        }
    }
    
    void handleMouseDown(SDL_MouseButtonEvent& button) {
        if (button.button == SDL_BUTTON_LEFT) {
            if (currentMode == Mode::EDIT) {
                if (currentTool == Tool::SELECT) {
                    isSelecting = true;
                    dragStart = {button.x, button.y};
                    dragCurrent = dragStart;
                    clearSelection();
                } else if (currentTool == Tool::PENCIL) {
                    // Add note at click position
                    double time = (button.x + scrollOffset - 50) / 100.0;
                    int noteNum = (MENU_BAR_HEIGHT + WATERFALL_HEIGHT - button.y) / 8;
                    if (noteNum >= 0 && noteNum < NUM_KEYS) {
                        addNote(noteNum, time, 0.5);
                    }
                } else if (currentTool == Tool::ERASER) {
                    // Delete note at click position
                    double time = (button.x + scrollOffset - 50) / 100.0;
                    int noteNum = (MENU_BAR_HEIGHT + WATERFALL_HEIGHT - button.y) / 8;
                    
                    midiNotes.erase(
                        std::remove_if(midiNotes.begin(), midiNotes.end(),
                            [time, noteNum](const MIDINote& n) {
                                return n.note == noteNum && 
                                       time >= n.startTime && 
                                       time <= n.startTime + n.duration;
                            }),
                        midiNotes.end()
                    );
                    hasUnsavedChanges = true;
                }
            }
        }
    }
    
    void handleMouseUp(SDL_MouseButtonEvent& button) {
        if (button.button == SDL_BUTTON_LEFT) {
            if (isSelecting) {
                SDL_Rect selRect;
                selRect.x = std::min(dragStart.x, dragCurrent.x);
                selRect.y = std::min(dragStart.y, dragCurrent.y);
                selRect.w = std::abs(dragCurrent.x - dragStart.x);
                selRect.h = std::abs(dragCurrent.y - dragStart.y);
                
                selectNotesInRect(selRect);
                isSelecting = false;
            }
        }
    }
    
    void handleMouseMotion(SDL_MouseMotionEvent& motion) {
        if (isSelecting) {
            dragCurrent = {motion.x, motion.y};
        }
    }
    
    void cycleMode() {
        if (currentMode == Mode::PLAYBACK) {
            currentMode = Mode::EDIT;
            isPlaying = false;
        } else if (currentMode == Mode::EDIT) {
            currentMode = Mode::RECORD;
        } else {
            currentMode = Mode::PLAYBACK;
            isRecording = false;
        }
    }
    
    void newFile() {
        midiNotes.clear();
        filename = "untitled.mid";
        hasUnsavedChanges = false;
        currentTime = 0.0;
    }
    
    void selectAll() {
        for (auto& note : midiNotes) {
            note.selected = true;
        }
    }
    
    void run() {
        Uint32 lastTime = SDL_GetTicks();
        
        while (true) {
            Uint32 currentTick = SDL_GetTicks();
            double deltaTime = (currentTick - lastTime) / 1000.0;
            lastTime = currentTick;
            
            handleInput();
            
            if (currentMode == Mode::PLAYBACK) {
                updateWaterfall(deltaTime);
            } else if (currentMode == Mode::RECORD) {
                updateRecording(deltaTime);
            }
            
            render();
            SDL_Delay(16);
        }
    }
    
    void cleanup() {
        if (fontLarge) TTF_CloseFont(fontLarge);
        if (fontSmall) TTF_CloseFont(fontSmall);
        if (renderer) SDL_DestroyRenderer(renderer);
        if (window) SDL_DestroyWindow(window);
        TTF_Quit();
        SDL_Quit();
    }
};

int main(int argc, char* argv[]) {
    PianoEditor editor;
    
    if (!editor.initialize()) {
        std::cerr << "Failed to initialize piano editor" << std::endl;
        return 1;
    }
    
    if (argc > 1) {
        editor.loadMIDIFile(argv[1]);
    }
    
    std::cout << "=== Piano Editor - Music Composition Studio ===" << std::endl;
    std::cout << "\nModes:" << std::endl;
    std::cout << "  [TAB] - Cycle modes" << std::endl;
    std::cout << "  [P] - Playback mode" << std::endl;
    std::cout << "  [E] - Edit mode" << std::endl;
    std::cout << "  [R] - Record mode" << std::endl;
    std::cout << "\nPlayback:" << std::endl;
    std::cout << "  [SPACE] - Play/Pause" << std::endl;
    std::cout << "  [+/-] - Speed up/down" << std::endl;
    std::cout << "  [HOME] - Restart" << std::endl;
    std::cout << "\nEditor:" << std::endl;
    std::cout << "  [1] - Select tool" << std::endl;
    std::cout << "  [2] - Pencil tool (add notes)" << std::endl;
    std::cout << "  [3] - Eraser tool" << std::endl;
    std::cout << "  [+/-] - Adjust grid snap" << std::endl;
    std::cout << "  [G] - Toggle grid" << std::endl;
    std::cout << "  [DELETE] - Delete selected" << std::endl;
    std::cout << "  [CTRL+A] - Select all" << std::endl;
    std::cout << "\nFile:" << std::endl;
    std::cout << "  [CTRL+N] - New file" << std::endl;
    std::cout << "  [CTRL+S] - Save" << std::endl;
    std::cout << "  [CTRL+L] - Load song.mid" << std::endl;
    std::cout << "  [CTRL+Q] - Quit" << std::endl;
    std::cout << "\nNavigation:" << std::endl;
    std::cout << "  [LEFT/RIGHT] - Scroll" << std::endl;
    
    editor.run();
    
    return 0;
}
