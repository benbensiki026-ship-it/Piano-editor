# 🎹 Piano Editor - Complete Music Composition Studio

A professional music composition and editing suite featuring an 88-key piano, waterfall visualization, piano roll editor, MIDI import/export, and recording capabilities. Built with C++ and SDL2.

![Features](https://img.shields.io/badge/Features-20+-brightgreen) ![Language](https://img.shields.io/badge/C%2B%2B-17-blue) ![SDL2](https://img.shields.io/badge/SDL2-Graphics-red)

## ✨ Complete Feature List

### 🎼 Three Operating Modes

#### 1. 📺 Playback Mode
- **Waterfall visualization** - Beautiful falling notes like Synthesia
- **Real-time playback** from MIDI files
- **Speed control** (0.1x to 3.0x)
- **Smooth 60 FPS** animation
- **Color-coded notes** by pitch
- **Live key highlighting** during playback

#### 2. ✏️ Edit Mode (Piano Roll Editor)
- **Visual piano roll** editor
- **Multiple tools**:
  - **Select tool** - Select and manipulate notes
  - **Pencil tool** - Draw new notes
  - **Eraser tool** - Delete notes
  - **Move tool** - Reposition notes
- **Grid snapping** (1/16, 1/8, 1/4, 1/2, 1 beat)
- **Multi-select** with rectangle selection
- **Drag and drop** note editing
- **Delete selected notes**
- **Select all** function
- **Undo/Redo support** (planned)

#### 3. 🎙️ Record Mode
- **Live recording** - Play and record in real-time
- **MIDI capture** from mouse/keyboard
- **Automatic quantization** to grid
- **Real-time note creation**
- **Record while playing**

### 💾 File Management

#### Import/Export
- **Load MIDI files** (.mid, .midi)
- **Save compositions** as MIDI files
- **Create new projects**
- **Unsaved changes warning**
- **File status indicator**

#### MIDI Support
- **Standard MIDI format** (0 and 1)
- **Multi-track support**
- **Note velocity** preservation
- **Tempo detection**
- **88-key range** (A0 to C8)

### 🎨 Editor Features

#### Visual Tools
- **Piano roll display** with 88 visible notes
- **Time grid** for precise editing
- **Beat markers** and measure lines
- **Note colors** - Blue (normal), Orange (selected)
- **Grid toggle** on/off
- **Zoom in/out** (planned)

#### Note Editing
- **Add notes** with pencil tool
- **Delete notes** with eraser tool
- **Select multiple notes** with rectangle
- **Move notes** in time and pitch
- **Resize note duration**
- **Adjust velocity** (planned)
- **Copy/paste** (planned)

#### Grid System
- **Adjustable snap grid** (1/16 to 1 beat)
- **Snap to grid** for precise timing
- **Visual grid lines**
- **Beat/measure markers**
- **Free drawing mode** (no snap)

### ⌨️ Keyboard Controls

#### Mode Switching
| Key | Action |
|-----|--------|
| **TAB** | Cycle through modes (Playback → Edit → Record) |
| **P** | Switch to Playback mode |
| **E** | Switch to Edit mode |
| **R** | Switch to Record mode / Start recording |

#### Playback Controls
| Key | Action |
|-----|--------|
| **SPACE** | Play / Pause |
| **HOME** | Restart from beginning |
| **+** / **=** | Increase speed |
| **-** | Decrease speed |

#### Editor Controls
| Key | Action |
|-----|--------|
| **1** | Select tool |
| **2** | Pencil tool (draw notes) |
| **3** | Eraser tool (delete notes) |
| **4** | Move tool |
| **+** / **-** | Adjust grid snap size |
| **G** | Toggle grid on/off |
| **DELETE** | Delete selected notes |
| **CTRL+A** | Select all notes |

#### File Operations
| Key | Action |
|-----|--------|
| **CTRL+N** | New file |
| **CTRL+S** | Save file |
| **CTRL+L** | Load song.mid |
| **CTRL+Q** | Quit application |

#### Navigation
| Key | Action |
|-----|--------|
| **LEFT** | Scroll left |
| **RIGHT** | Scroll right |
| **Mouse Wheel** | Zoom (planned) |

### 🖱️ Mouse Controls

#### In Edit Mode
- **Left Click** (Select tool) - Start selection rectangle
- **Left Click + Drag** (Select tool) - Select multiple notes
- **Left Click** (Pencil tool) - Add new note
- **Left Click** (Eraser tool) - Delete note under cursor
- **Left Click + Drag** (Move tool) - Move selected notes

#### In All Modes
- **Click piano keys** - Play notes manually
- **Scroll wheel** - Zoom timeline (planned)

### 🎹 Piano Features

#### 88-Key Layout
- **52 white keys** - Natural notes
- **36 black keys** - Sharps/flats
- **Accurate spacing** - Professional layout
- **Key dimensions**:
  - White: 20px width × 200px height
  - Black: 12px width × 120px height
- **Visual feedback** - Keys light up when played
- **Scrollable** - Horizontal scrolling to view all keys

### 📊 User Interface

#### Menu Bar
- **File menu** - New, Open, Save, Export
- **Edit menu** - Undo, Redo, Cut, Copy, Paste, Select All
- **Tools menu** - Select tools and grid settings
- **Mode indicator** - Shows current mode
- **Tool indicator** - Shows active tool
- **File status** - Shows filename and unsaved changes

#### Status Bar
- **Current time** display
- **Playback speed** indicator
- **Note count** statistics
- **Grid size** display
- **Status messages** (Playing, Recording, Ready)
- **Keyboard shortcuts** reminder

#### Visual Design
- **Dark theme** - Easy on the eyes
- **Color-coded interface**
- **Clear separation** of work areas
- **Professional look**
- **Responsive layout**

## 📋 System Requirements

### Minimum
- **OS**: Windows 10, macOS 10.14, or Linux (Ubuntu 18.04+)
- **CPU**: Dual-core 2.0 GHz
- **RAM**: 512 MB
- **GPU**: OpenGL 2.0 support
- **Display**: 1280×720

### Recommended
- **OS**: Windows 11, macOS 12+, or Linux (Ubuntu 22.04+)
- **CPU**: Quad-core 2.5 GHz+
- **RAM**: 2 GB
- **GPU**: Dedicated graphics with OpenGL 3.0+
- **Display**: 1920×1080 or higher

### Dependencies
- **SDL2** 2.0.8+
- **SDL2_ttf** 2.0.14+
- **C++ Compiler** with C++17 support
- **CMake** 3.10+ (optional)

## 🚀 Quick Start

### Installation

#### Linux (Ubuntu/Debian)
```bash
# Install dependencies
sudo apt-get update
sudo apt-get install -y build-essential libsdl2-dev libsdl2-ttf-dev

# Compile
make

# Run
./piano_editor
```

#### macOS
```bash
# Install dependencies
brew install sdl2 sdl2_ttf

# Compile
make

# Run
./piano_editor
```

#### Windows
```cmd
# Install MinGW and SDL2 (see INSTALL.md)

# Compile
build.bat

# Run
piano_editor.exe
```

### First Steps

1. **Launch the application**
   ```bash
   ./piano_editor
   ```

2. **Try Playback Mode**
   - Press `CTRL+L` to load song.mid
   - Press `SPACE` to play
   - Use `+/-` to adjust speed

3. **Try Edit Mode**
   - Press `E` to enter Edit mode
   - Press `2` to select Pencil tool
   - Click in the piano roll to add notes
   - Press `SPACE` to hear your creation

4. **Try Record Mode**
   - Press `R` to enter Record mode
   - Press `R` again to start recording
   - Click piano keys to record notes
   - Press `R` to stop recording

5. **Save Your Work**
   - Press `CTRL+S` to save
   - File saved as your current filename

## 📚 Detailed Usage

### Creating Music from Scratch

1. **Start a new project**
   ```
   CTRL+N
   ```

2. **Enter Edit Mode**
   ```
   Press E
   ```

3. **Select Pencil Tool**
   ```
   Press 2
   ```

4. **Draw Notes**
   - Click in the piano roll to place notes
   - Higher on the screen = higher pitch
   - Left to right = time progression
   - Notes snap to the grid

5. **Adjust Grid**
   ```
   Press + to increase (1/2 beat, 1 beat)
   Press - to decrease (1/4 beat, 1/8 beat, 1/16 beat)
   ```

6. **Edit Notes**
   ```
   Press 1 (Select tool)
   Click and drag to select notes
   Press DELETE to remove selected
   ```

7. **Listen to Your Creation**
   ```
   Press P (Playback mode)
   Press SPACE to play
   ```

8. **Save Your Work**
   ```
   CTRL+S
   Enter filename when prompted
   ```

### Editing Existing MIDI Files

1. **Load a MIDI file**
   ```
   CTRL+L (loads song.mid)
   or
   ./piano_editor your-song.mid
   ```

2. **Switch to Edit Mode**
   ```
   Press E
   ```

3. **Select notes to edit**
   ```
   Press 1 (Select tool)
   Click and drag over notes
   or
   CTRL+A to select all
   ```

4. **Modify notes**
   ```
   Press DELETE to remove
   Press 2 (Pencil) to add new notes
   Press 3 (Eraser) to delete specific notes
   ```

5. **Save changes**
   ```
   CTRL+S
   ```

### Recording Live Performance

1. **Enter Record Mode**
   ```
   Press R
   ```

2. **Set up**
   - Adjust grid snap if needed (`+/-`)
   - Position view with arrow keys

3. **Start Recording**
   ```
   Press R again
   ```

4. **Play**
   - Click piano keys to play notes
   - Notes are automatically recorded
   - Timing is quantized to grid

5. **Stop Recording**
   ```
   Press R again
   ```

6. **Review and Edit**
   ```
   Press E (Edit mode)
   Make any adjustments
   ```

7. **Save**
   ```
   CTRL+S
   ```

## 🎓 Tips and Tricks

### Composition Tips
- Start with a simple melody on one hand
- Use grid snapping for rhythmic precision
- Build up layers by recording multiple passes
- Use Select All to move entire sections
- Experiment with different tempos in Playback mode

### Editor Shortcuts
- **Quick save**: Get in the habit of pressing `CTRL+S` often
- **Mode switching**: `TAB` is faster than individual mode keys
- **Grid navigation**: Use `+/-` to quickly adjust grid size
- **Fast playback**: Use `HOME` to restart, then `SPACE` to play

### Performance Optimization
- Close other applications while composing
- Use a smaller grid size for better performance with many notes
- Save regularly to avoid losing work
- Keep MIDI files under 10,000 notes for best performance

### Workflow Recommendations
1. **Sketch** - Use Record mode to capture ideas quickly
2. **Refine** - Switch to Edit mode to perfect timing
3. **Polish** - Use Playback mode to review and adjust tempo
4. **Export** - Save as MIDI for use in other software

## 🔧 Advanced Features

### Grid Snapping
- **1/16 beat**: Fastest notes (64th notes)
- **1/8 beat**: Quick notes (32nd notes)
- **1/4 beat**: Standard notes (16th notes)
- **1/2 beat**: Eighth notes
- **1 beat**: Quarter notes

### Note Selection
- **Single click**: Select one note
- **Drag rectangle**: Select multiple notes
- **CTRL+A**: Select all notes
- **Click empty space**: Deselect all

### File Formats
- **Input**: Standard MIDI files (.mid, .midi)
- **Output**: Standard MIDI files (.mid)
- Compatible with:
  - GarageBand
  - FL Studio
  - Ableton Live
  - MuseScore
  - Any DAW that supports MIDI

## 🐛 Troubleshooting

### Application won't start
```bash
# Check SDL2 installation
pkg-config --modversion sdl2

# Reinstall if needed
sudo apt-get install --reinstall libsdl2-dev libsdl2-ttf-dev
```

### Can't load MIDI file
- Ensure file is valid MIDI format
- Check file permissions
- Try a different MIDI file
- Check filename is correct

### Notes not appearing
- Make sure you're in Edit mode (`E`)
- Check you have Pencil tool selected (`2`)
- Verify you're clicking in the piano roll area
- Try toggling grid (`G`) to see if notes are there

### No sound
- This version focuses on visual editing
- Sound support can be added via SDL_mixer
- Export MIDI and play in your DAW

### Performance issues
- Reduce number of notes
- Close other applications
- Disable grid (`G`)
- Update graphics drivers

## 📖 Keyboard Reference

### Quick Reference Card

```
┌─────────────── MODES ───────────────┐
│ TAB     Cycle modes                 │
│ P       Playback mode               │
│ E       Edit mode                   │
│ R       Record mode / Record        │
└─────────────────────────────────────┘

┌─────────────── PLAYBACK ────────────┐
│ SPACE   Play / Pause                │
│ HOME    Restart                     │
│ +/-     Speed control               │
└─────────────────────────────────────┘

┌─────────────── EDITOR ──────────────┐
│ 1       Select tool                 │
│ 2       Pencil tool                 │
│ 3       Eraser tool                 │
│ 4       Move tool                   │
│ +/-     Adjust grid                 │
│ G       Toggle grid                 │
│ DEL     Delete selected             │
│ CTRL+A  Select all                  │
└─────────────────────────────────────┘

┌─────────────── FILES ───────────────┐
│ CTRL+N  New file                    │
│ CTRL+S  Save file                   │
│ CTRL+L  Load file                   │
│ CTRL+Q  Quit                        │
└─────────────────────────────────────┘

┌─────────── NAVIGATION ──────────────┐
│ ←→      Scroll timeline             │
└─────────────────────────────────────┘
```

## 🎵 Example Projects

### Getting Started Songs

1. **C Major Scale**
   ```bash
   python3 create_test_midi.py
   ./piano_editor song.mid
   ```

2. **Simple Melody**
   - Enter Edit mode (`E`)
   - Use Pencil tool (`2`)
   - Draw: C-D-E-C, C-D-E-C, E-F-G
   - Save (`CTRL+S`)

3. **Chord Progression**
   - Draw C major chord (C-E-G) together
   - Move forward in time
   - Draw F major chord (F-A-C)
   - Draw G major chord (G-B-D)
   - Back to C major

### Download MIDI Files

Practice with real songs:
- **FreeMIDI**: https://freemidi.org/
- **Classical**: Mozart, Beethoven, Bach
- **Popular**: Movie themes, game music
- **Jazz**: Standards and improvisations

## 🤝 Contributing

Areas for enhancement:
- Audio playback (SDL_mixer integration)
- More editing tools (cut, copy, paste)
- Undo/Redo system
- Zoom in/out
- Velocity editor
- Multiple instrument tracks
- VST plugin support
- Export to other formats

## 📄 License

MIT License - Free to use, modify, and distribute

## 🙏 Acknowledgments

Inspired by:
- **Synthesia** - Piano learning software
- **FL Studio** - Piano roll design
- **Ableton Live** - UI/UX patterns
- **MuseScore** - Music notation software

Built with:
- **C++17** - Modern C++ features
- **SDL2** - Graphics and windowing
- **SDL2_ttf** - Text rendering

---

**Happy Composing! 🎵🎹**

Create beautiful music with professional tools. From recording to editing to playback, Piano Editor has everything you need to bring your musical ideas to life.
