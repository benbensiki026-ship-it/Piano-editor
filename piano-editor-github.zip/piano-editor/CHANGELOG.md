# Changelog

All notable changes to Piano Editor will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Planned for 1.0
- Audio playback using SDL_mixer
- Undo/Redo system
- Copy/paste notes
- Zoom in/out functionality
- Better file dialogs
- Velocity editor

## [0.9.0] - 2026-01-XX (Pre-release)

### Added
- Initial public release
- Three operating modes: Playback, Edit, Record
- Waterfall visualization (Synthesia-style)
- Complete piano roll editor
- Four editing tools: Select, Pencil, Eraser, Move
- MIDI file import and export
- Grid snapping system (1/16 to 1 beat)
- Multi-note selection with rectangle
- 88-key piano range (A0 to C8)
- Real-time recording mode
- Keyboard shortcuts for all major functions
- Status bar with time, speed, and note count
- Menu system (File, Edit, Tools)
- Adjustable playback speed (0.1x to 3.0x)
- Color-coded note visualization
- Grid toggle functionality
- Unsaved changes tracking
- Cross-platform support (Windows, macOS, Linux)

### Technical
- C++17 codebase
- SDL2 for graphics rendering
- SDL2_ttf for text rendering
- Custom MIDI parser
- 60 FPS rendering with VSync
- Hardware-accelerated graphics
- ~50MB memory footprint

### Documentation
- Comprehensive README
- Quick start guide
- Installation instructions for all platforms
- Keyboard shortcuts reference
- Contributing guidelines
- MIT License

### Build System
- Makefile for Linux/macOS
- Batch scripts for Windows
- Build scripts with dependency checking
- Python script for generating test MIDI files

## [0.1.0] - 2025-12-XX (Internal Alpha)

### Added
- Basic project structure
- Core rendering pipeline
- MIDI file parsing
- Simple playback functionality

---

## Version History

### Version Numbering

- **Major.Minor.Patch** format
- **Major**: Breaking changes, major new features
- **Minor**: New features, backwards compatible
- **Patch**: Bug fixes, small improvements

### Release Schedule

- **v1.0**: 2026 Q1 - Stable release with audio
- **v1.1**: 2026 Q2 - Enhanced editing features
- **v2.0**: 2026 Q3 - Multi-track and plugins

---

## Changelog Categories

### Added
New features and capabilities

### Changed
Changes to existing functionality

### Deprecated
Features that will be removed in future versions

### Removed
Features that have been removed

### Fixed
Bug fixes

### Security
Security-related fixes and improvements

---

## How to Contribute to Changelog

When submitting a PR, add your changes under the `[Unreleased]` section:

```markdown
## [Unreleased]

### Added
- Your new feature description
```

Maintainers will move entries to versioned sections on release.
