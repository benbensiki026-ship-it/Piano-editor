#!/bin/bash

echo "================================================"
echo "  Piano Editor - Music Composition Studio"
echo "  Build Script"
echo "================================================"
echo ""

# Detect OS
OS="$(uname -s)"
case "${OS}" in
    Linux*)     MACHINE=Linux;;
    Darwin*)    MACHINE=Mac;;
    *)          MACHINE="UNKNOWN:${OS}"
esac

echo "Detected OS: $MACHINE"
echo ""

# Check for g++
if ! command -v g++ &> /dev/null; then
    echo "[ERROR] g++ compiler not found!"
    echo ""
    if [ "$MACHINE" == "Linux" ]; then
        echo "Install with: sudo apt-get install build-essential"
    elif [ "$MACHINE" == "Mac" ]; then
        echo "Install with: xcode-select --install"
    fi
    exit 1
fi

echo "[✓] Compiler found: $(g++ --version | head -n 1)"

# Check for SDL2
if [ "$MACHINE" == "Linux" ]; then
    if ! pkg-config --exists sdl2; then
        echo "[ERROR] SDL2 not found!"
        echo ""
        echo "Install with:"
        echo "  sudo apt-get install libsdl2-dev libsdl2-ttf-dev"
        exit 1
    fi
    echo "[✓] SDL2 found: $(pkg-config --modversion sdl2)"
    SDL_CFLAGS=$(pkg-config --cflags sdl2)
    SDL_LIBS=$(pkg-config --libs sdl2)
    SDL_LIBS="$SDL_LIBS -lSDL2_ttf"
elif [ "$MACHINE" == "Mac" ]; then
    if [ -d "/usr/local/include/SDL2" ]; then
        SDL_CFLAGS="-I/usr/local/include/SDL2"
        SDL_LIBS="-L/usr/local/lib -lSDL2 -lSDL2_ttf"
        echo "[✓] SDL2 found: /usr/local"
    elif [ -d "/opt/homebrew/include/SDL2" ]; then
        SDL_CFLAGS="-I/opt/homebrew/include/SDL2"
        SDL_LIBS="-L/opt/homebrew/lib -lSDL2 -lSDL2_ttf"
        echo "[✓] SDL2 found: /opt/homebrew"
    else
        echo "[ERROR] SDL2 not found!"
        echo ""
        echo "Install with: brew install sdl2 sdl2_ttf"
        exit 1
    fi
fi

echo ""
echo "Compiling piano_editor.cpp..."
echo ""

# Compile
g++ -std=c++17 -Wall -O2 $SDL_CFLAGS -o piano_editor piano_editor.cpp $SDL_LIBS

if [ $? -eq 0 ]; then
    echo ""
    echo "================================================"
    echo "[SUCCESS] Build complete!"
    echo "================================================"
    echo ""
    echo "Run the application:"
    echo "  ./piano_editor"
    echo ""
    echo "Or with a MIDI file:"
    echo "  ./piano_editor song.mid"
    echo ""
    echo "Create test MIDI:"
    echo "  python3 create_test_midi.py"
    echo ""
else
    echo ""
    echo "[ERROR] Build failed!"
    echo "Check the error messages above."
    exit 1
fi
