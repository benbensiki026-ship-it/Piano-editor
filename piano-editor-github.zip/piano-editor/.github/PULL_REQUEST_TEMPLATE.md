## 📝 Description

Provide a clear and concise description of what this PR does.

Fixes #(issue number)

## 🎯 Type of Change

- [ ] 🐛 Bug fix (non-breaking change which fixes an issue)
- [ ] ✨ New feature (non-breaking change which adds functionality)
- [ ] 💥 Breaking change (fix or feature that would cause existing functionality to not work as expected)
- [ ] 📚 Documentation update
- [ ] 🎨 UI/UX improvement
- [ ] ♻️ Code refactoring (no functional changes)
- [ ] ⚡ Performance improvement
- [ ] 🧪 Test addition or update

## ✅ Checklist

- [ ] My code follows the code style of this project
- [ ] I have performed a self-review of my own code
- [ ] I have commented my code, particularly in hard-to-understand areas
- [ ] I have made corresponding changes to the documentation
- [ ] My changes generate no new warnings or errors
- [ ] I have tested this on my system
- [ ] Any dependent changes have been merged and published

## 🧪 Testing

### How Has This Been Tested?

Please describe the tests you ran to verify your changes:

- [ ] Test A: Description
- [ ] Test B: Description
- [ ] Test C: Description

### Test Configuration

- **OS**: [e.g. Ubuntu 22.04]
- **Compiler**: [e.g. GCC 11.2]
- **SDL2 Version**: [e.g. 2.0.20]

## 📸 Screenshots/Videos

If applicable, add screenshots or screen recordings to demonstrate the changes:

### Before
<!-- Add screenshot/video of the old behavior -->

### After
<!-- Add screenshot/video of the new behavior -->

## 🔗 Related Issues

List any related issues or PRs:
- Closes #
- Related to #
- Depends on #

## 📊 Performance Impact

- [ ] No performance impact
- [ ] Minor performance impact
- [ ] Significant performance improvement
- [ ] May impact performance (explain below)

**Details:**

## 💭 Additional Notes

Add any additional notes, context, or concerns here.

## 🎓 Learning

If this was your first contribution or you learned something new, feel free to share!

---

**For Reviewers:**

### Focus Areas

Please pay special attention to:
- [ ] Area 1
- [ ] Area 2
- [ ] Area 3

### Questions for Reviewers

- Question 1?
- Question 2?
