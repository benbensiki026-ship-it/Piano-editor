---
name: Bug Report
about: Report a bug to help us improve
title: '[BUG] '
labels: bug
assignees: ''
---

## 🐛 Bug Description

A clear and concise description of what the bug is.

## 📋 Steps to Reproduce

Steps to reproduce the behavior:
1. Go to '...'
2. Click on '...'
3. Press '...'
4. See error

## ✅ Expected Behavior

A clear and concise description of what you expected to happen.

## ❌ Actual Behavior

A clear and concise description of what actually happened.

## 📸 Screenshots

If applicable, add screenshots or screen recordings to help explain your problem.

## 💻 System Information

**Desktop (please complete the following information):**
- OS: [e.g. Windows 11, macOS 14, Ubuntu 22.04]
- SDL2 Version: [e.g. 2.0.20]
- Compiler: [e.g. GCC 11.2, MSVC 2022]
- Version: [e.g. 0.9.0]

## 📁 MIDI File

If the bug is related to a specific MIDI file, please attach it or provide a download link.

## 📊 Additional Context

Add any other context about the problem here. For example:
- Does it happen with all MIDI files or just specific ones?
- Does it happen in all modes or just one?
- Did this work in a previous version?

## 🔍 Possible Solution

If you have ideas about what might be causing the issue or how to fix it, please share them here.

## 📝 Logs

If applicable, paste any error messages or logs here:

```
Paste error messages here
```

---

**Checklist:**
- [ ] I have searched for similar issues before creating this one
- [ ] I have provided all the requested information
- [ ] I have included steps to reproduce
- [ ] I have attached screenshots/recordings if applicable
