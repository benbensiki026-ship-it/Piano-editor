# 🎹 Piano Editor v0.9.0 - Initial Public Release

**Release Date: January 2026**

We're thrilled to announce the first public release of Piano Editor - a free, open-source music composition studio!

---

## 🌟 Highlights

### What is Piano Editor?

Piano Editor is a comprehensive music composition tool that combines:
- **Beautiful waterfall visualization** (like Synthesia)
- **Professional piano roll editor** (like FL Studio)
- **Real-time recording** capabilities
- **Full MIDI import/export** support

Perfect for beginners learning piano and experienced composers creating music!

---

## ✨ Key Features

### 🎼 Three Operating Modes

**📺 Playback Mode**
- Watch notes fall in real-time
- Adjust playback speed (0.1x to 3.0x)
- Visual key highlighting
- 60 FPS smooth animation

**✏️ Edit Mode**
- Visual piano roll editor
- 4 professional tools (Select, Pencil, Eraser, Move)
- Grid snapping (1/16 to 1 beat)
- Multi-note selection
- Drag and drop editing

**🎙️ Record Mode**
- Live recording
- Click piano keys to capture notes
- Automatic quantization
- Real-time feedback

### 💾 File Management
- Import MIDI files (.mid, .midi)
- Export compositions as MIDI
- Create new projects
- Unsaved changes tracking
- Compatible with all DAWs

### 🎹 Piano Features
- 88-key piano range (A0 to C8)
- Realistic key layout
- Visual feedback
- Scrollable keyboard

---

## 📥 Download

### Linux (Ubuntu/Debian)
```bash
# Install dependencies
sudo apt-get install libsdl2-dev libsdl2-ttf-dev

# Download and extract
wget https://github.com/YOUR_USERNAME/piano-editor/releases/download/v0.9.0/piano-editor-v0.9.0-linux.tar.gz
tar -xzf piano-editor-v0.9.0-linux.tar.gz
cd piano-editor

# Run
./piano_editor
```

### macOS
```bash
# Install dependencies
brew install sdl2 sdl2_ttf

# Download and extract
curl -L https://github.com/YOUR_USERNAME/piano-editor/releases/download/v0.9.0/piano-editor-v0.9.0-macos.tar.gz -o piano-editor.tar.gz
tar -xzf piano-editor.tar.gz
cd piano-editor

# Run
./piano_editor
```

### Windows
1. Download `piano-editor-v0.9.0-windows.zip`
2. Extract the ZIP file
3. Run `piano_editor.exe`

### Build from Source
```bash
git clone https://github.com/YOUR_USERNAME/piano-editor.git
cd piano-editor
make
./piano_editor
```

---

## 🚀 Quick Start

```bash
# 1. Create a test MIDI file
python3 create_test_midi.py

# 2. Launch the editor
./piano_editor song.mid

# 3. Try the modes
Press E - Edit mode
Press P - Playback mode
Press R - Record mode

# 4. Start composing!
Press 2 (Pencil tool)
Click to add notes
```

---

## ⌨️ Essential Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `E` | Edit mode |
| `P` | Playback mode |
| `R` | Record mode |
| `SPACE` | Play/Pause |
| `1-4` | Select tools |
| `CTRL+S` | Save |
| `CTRL+L` | Load |
| `CTRL+N` | New file |

See [full keyboard reference](docs/SHORTCUTS.md).

---

## 📚 Documentation

- **README**: [Full documentation](README.md)
- **Quick Start**: [Get started in 5 minutes](QUICKSTART.md)
- **Contributing**: [How to contribute](CONTRIBUTING.md)
- **Roadmap**: [Future plans](ROADMAP.md)

---

## 🐛 Known Issues

### Current Limitations
- No audio playback yet (coming in v1.0)
- Undo/Redo not implemented (coming in v1.0)
- No copy/paste functionality (coming in v1.0)
- No zoom controls (coming in v1.1)

### Platform-Specific Issues

**Linux:**
- Some font rendering issues on certain distributions
- Workaround: Install DejaVu fonts

**macOS:**
- May need to allow app in Security settings
- Workaround: Right-click → Open

**Windows:**
- Requires SDL2.dll in same directory
- Included in release package

See [Issue Tracker](https://github.com/YOUR_USERNAME/piano-editor/issues) for complete list.

---

## 🎯 What's Next?

### Version 1.0 (Q1 2026)
- ✅ Audio playback using SDL_mixer
- ✅ Undo/Redo system
- ✅ Copy/paste notes
- ✅ Better file dialogs

### Version 1.1 (Q2 2026)
- ⏳ Zoom functionality
- ⏳ Velocity editor
- ⏳ Quantize function
- ⏳ Metronome

See [full roadmap](ROADMAP.md).

---

## 🤝 Contributing

We welcome contributions! Ways to help:

- 🐛 **Report bugs** - Help us improve stability
- 💡 **Suggest features** - Share your ideas
- 📝 **Improve docs** - Make it easier for others
- 💻 **Submit code** - Implement features
- ⭐ **Star the repo** - Show your support

See [Contributing Guide](CONTRIBUTING.md).

---

## 🙏 Acknowledgments

### Inspiration
- **Synthesia** - Waterfall visualization
- **FL Studio** - Piano roll design
- **Ableton Live** - Workflow concepts
- **MuseScore** - Open source music software

### Built With
- [SDL2](https://www.libsdl.org/) - Graphics
- [SDL2_ttf](https://www.libsdl.org/projects/SDL_ttf/) - Text rendering
- C++17 - Programming language

### Contributors
Special thanks to early testers and contributors!

See [full credits](README.md#-credits).

---

## 📊 Statistics

- **Lines of Code**: ~1,400
- **Features**: 15 major features
- **Development Time**: 3 months
- **Coffee Consumed**: ∞

---

## 📄 License

Piano Editor is released under the MIT License.

```
Copyright (c) 2026 Piano Editor Contributors

Permission is hereby granted, free of charge...
```

See [LICENSE](LICENSE) for full text.

---

## 🌐 Links

- **GitHub**: https://github.com/YOUR_USERNAME/piano-editor
- **Issues**: https://github.com/YOUR_USERNAME/piano-editor/issues
- **Discussions**: https://github.com/YOUR_USERNAME/piano-editor/discussions
- **Wiki**: https://github.com/YOUR_USERNAME/piano-editor/wiki

---

## 💬 Community

Join the conversation:

- **Discord**: Coming Soon
- **Reddit**: Coming Soon
- **Twitter**: Coming Soon

---

## 🎉 Thank You!

Thank you for trying Piano Editor! This is just the beginning.

We're excited to build the future of music composition together with you.

**Happy composing! 🎹🎵**

---

### Download Links

- [Linux (tar.gz)](https://github.com/YOUR_USERNAME/piano-editor/releases/download/v0.9.0/piano-editor-v0.9.0-linux.tar.gz)
- [macOS (tar.gz)](https://github.com/YOUR_USERNAME/piano-editor/releases/download/v0.9.0/piano-editor-v0.9.0-macos.tar.gz)
- [Windows (zip)](https://github.com/YOUR_USERNAME/piano-editor/releases/download/v0.9.0/piano-editor-v0.9.0-windows.zip)
- [Source Code (zip)](https://github.com/YOUR_USERNAME/piano-editor/archive/refs/tags/v0.9.0.zip)
- [Source Code (tar.gz)](https://github.com/YOUR_USERNAME/piano-editor/archive/refs/tags/v0.9.0.tar.gz)

**SHA256 Checksums**: See [CHECKSUMS.txt](https://github.com/YOUR_USERNAME/piano-editor/releases/download/v0.9.0/CHECKSUMS.txt)

---

**Release Notes Generated**: December 14, 2025
