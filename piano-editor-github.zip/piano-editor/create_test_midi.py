#!/usr/bin/env python3
"""
MIDI file generator for testing the Piano Editor.
Creates various test patterns and songs.
"""

import struct
import sys

def write_var_length(value):
    """Write a variable-length quantity"""
    result = bytearray()
    result.insert(0, value & 0x7F)
    value >>= 7
    while value > 0:
        result.insert(0, (value & 0x7F) | 0x80)
        value >>= 7
    return bytes(result)

def create_midi_file(filename, notes, tempo=500000, ticks_per_quarter=480):
    """
    Create a MIDI file from a list of notes.
    notes: list of (note_number, start_tick, duration_ticks, velocity)
    """
    
    # MIDI Header
    header = b'MThd'
    header += struct.pack('>I', 6)  # Header length
    header += struct.pack('>H', 0)  # Format 0
    header += struct.pack('>H', 1)  # One track
    header += struct.pack('>H', ticks_per_quarter)
    
    # Track events
    track_events = bytearray()
    
    # Set tempo
    track_events += b'\x00\xFF\x51\x03'
    track_events += struct.pack('>I', tempo)[1:]  # 3 bytes
    
    # Sort notes by start time
    notes_sorted = sorted(notes, key=lambda x: x[1])
    
    # Create note on/off events
    events = []
    for note, start, duration, velocity in notes_sorted:
        events.append((start, 'on', note, velocity))
        events.append((start + duration, 'off', note, 0))
    
    events.sort(key=lambda x: x[0])
    
    # Write events
    last_tick = 0
    for tick, event_type, note, velocity in events:
        delta = tick - last_tick
        track_events += write_var_length(delta)
        
        if event_type == 'on':
            track_events += bytes([0x90, note, velocity])
        else:
            track_events += bytes([0x80, note, 0])
        
        last_tick = tick
    
    # End of track
    track_events += b'\x00\xFF\x2F\x00'
    
    # Track header
    track_header = b'MTrk'
    track_header += struct.pack('>I', len(track_events))
    
    # Write file
    with open(filename, 'wb') as f:
        f.write(header)
        f.write(track_header)
        f.write(track_events)
    
    print(f"Created {filename} with {len(notes)} notes")

def create_c_major_scale():
    """Create C major scale (C4 to C5)"""
    notes = []
    scale = [60, 62, 64, 65, 67, 69, 71, 72]  # C D E F G A B C
    
    for i, note in enumerate(scale):
        notes.append((note, i * 240, 200, 80))
    
    create_midi_file('c_major_scale.mid', notes)

def create_simple_melody():
    """Create a simple melody"""
    notes = []
    
    # Twinkle Twinkle Little Star (simplified)
    melody = [
        (60, 0, 240, 80),      # C
        (60, 240, 240, 80),    # C
        (67, 480, 240, 80),    # G
        (67, 720, 240, 80),    # G
        (69, 960, 240, 80),    # A
        (69, 1200, 240, 80),   # A
        (67, 1440, 480, 80),   # G (long)
        
        (65, 1920, 240, 80),   # F
        (65, 2160, 240, 80),   # F
        (64, 2400, 240, 80),   # E
        (64, 2640, 240, 80),   # E
        (62, 2880, 240, 80),   # D
        (62, 3120, 240, 80),   # D
        (60, 3360, 480, 80),   # C (long)
    ]
    
    create_midi_file('twinkle_twinkle.mid', melody)

def create_chord_progression():
    """Create a simple chord progression"""
    notes = []
    
    # C major chord
    notes.extend([
        (60, 0, 480, 80),     # C
        (64, 0, 480, 80),     # E
        (67, 0, 480, 80),     # G
    ])
    
    # F major chord
    notes.extend([
        (65, 480, 480, 80),   # F
        (69, 480, 480, 80),   # A
        (60, 480, 480, 80),   # C
    ])
    
    # G major chord
    notes.extend([
        (67, 960, 480, 80),   # G
        (71, 960, 480, 80),   # B
        (62, 960, 480, 80),   # D
    ])
    
    # C major chord
    notes.extend([
        (60, 1440, 480, 80),  # C
        (64, 1440, 480, 80),  # E
        (67, 1440, 480, 80),  # G
    ])
    
    create_midi_file('chord_progression.mid', notes)

def create_arpeggio():
    """Create an arpeggio pattern"""
    notes = []
    
    # C major arpeggio going up and down
    pattern = [60, 64, 67, 72, 67, 64] * 2
    
    for i, note in enumerate(pattern):
        notes.append((note, i * 120, 100, 80))
    
    create_midi_file('arpeggio.mid', notes)

def create_test_song():
    """Create a comprehensive test song"""
    notes = []
    
    # Simple accompaniment pattern
    bass = [
        (48, 0, 480, 70),      # C2
        (53, 480, 480, 70),    # F2
        (55, 960, 480, 70),    # G2
        (48, 1440, 480, 70),   # C2
    ]
    
    # Melody line
    melody = [
        (72, 0, 240, 90),      # C5
        (71, 240, 240, 90),    # B4
        (69, 480, 240, 90),    # A4
        (67, 720, 240, 90),    # G4
        (65, 960, 240, 90),    # F4
        (64, 1200, 240, 90),   # E4
        (62, 1440, 240, 90),   # D4
        (60, 1680, 240, 90),   # C4
    ]
    
    # Chords
    chords = [
        (60, 0, 960, 60),      # C4
        (64, 0, 960, 60),      # E4
        (67, 0, 960, 60),      # G4
        
        (65, 960, 480, 60),    # F4
        (69, 960, 480, 60),    # A4
        (60, 960, 480, 60),    # C4
        
        (60, 1440, 480, 60),   # C4
        (64, 1440, 480, 60),   # E4
        (67, 1440, 480, 60),   # G4
    ]
    
    notes.extend(bass)
    notes.extend(melody)
    notes.extend(chords)
    
    create_midi_file('test_song.mid', notes)

def main():
    print("=== Piano Editor - MIDI Test File Generator ===")
    print("")
    
    if len(sys.argv) > 1:
        choice = sys.argv[1]
    else:
        print("Available test files:")
        print("  1. C Major Scale")
        print("  2. Twinkle Twinkle Little Star")
        print("  3. Chord Progression")
        print("  4. Arpeggio")
        print("  5. Test Song (all features)")
        print("  6. All of the above")
        print("")
        choice = input("Select (1-6): ")
    
    if choice == '1':
        create_c_major_scale()
    elif choice == '2':
        create_simple_melody()
    elif choice == '3':
        create_chord_progression()
    elif choice == '4':
        create_arpeggio()
    elif choice == '5':
        create_test_song()
    elif choice == '6':
        create_c_major_scale()
        create_simple_melody()
        create_chord_progression()
        create_arpeggio()
        create_test_song()
        print("\nAll test files created!")
    else:
        print("Creating default file (C major scale)...")
        create_c_major_scale()
    
    # Also create song.mid for quick loading
    create_c_major_scale()
    import os
    if os.path.exists('c_major_scale.mid'):
        import shutil
        shutil.copy('c_major_scale.mid', 'song.mid')
        print("Created song.mid (copy of C major scale)")
    
    print("\nTest files ready!")
    print("Load in Piano Editor with: ./piano_editor song.mid")

if __name__ == '__main__':
    main()
