# 🚀 Piano Editor - Quick Start Guide

Get started composing music in under 5 minutes!

## ⚡ Super Quick Start

```bash
# 1. Install dependencies (Linux)
sudo apt-get install -y libsdl2-dev libsdl2-ttf-dev

# 2. Build
make

# 3. Create test file
python3 create_test_midi.py

# 4. Run!
./piano_editor song.mid
```

## 🎹 Your First Composition

### 1️⃣ Start the Editor
```bash
./piano_editor
```

### 2️⃣ Enter Edit Mode
Press `E` on your keyboard

### 3️⃣ Select Pencil Tool
Press `2` to draw notes

### 4️⃣ Draw Your First Notes
- Click in the piano roll (center area)
- Higher = higher pitch
- Left to right = time
- Draw a simple melody: C-D-E-C

### 5️⃣ Play Your Creation
- Press `P` to enter Playback mode
- Press `SPACE` to play
- Listen to your music!

### 6️⃣ Save Your Work
Press `CTRL+S` to save as a MIDI file

## 🎵 Three Modes

### 📺 Playback Mode (P)
**What:** Watch notes fall like Guitar Hero
**Use:** Preview your music
**Controls:**
- `SPACE` - Play/Pause
- `+/-` - Speed up/down
- `HOME` - Restart

### ✏️ Edit Mode (E)
**What:** Draw and edit notes
**Use:** Create your composition
**Controls:**
- `1` - Select tool
- `2` - Pencil tool (draw)
- `3` - Eraser tool (delete)
- Click to add/select/delete notes

### 🎙️ Record Mode (R)
**What:** Record live performance
**Use:** Capture ideas quickly
**Controls:**
- `R` - Start/Stop recording
- Click piano keys to play

## 🎨 Quick Tools Reference

| Key | Tool | What It Does |
|-----|------|--------------|
| `1` | Select | Click and drag to select notes |
| `2` | Pencil | Click to add notes |
| `3` | Eraser | Click to delete notes |
| `G` | Grid | Toggle grid lines |
| `+/-` | Grid Size | Adjust snap resolution |

## 💾 File Operations

| Keys | Action |
|------|--------|
| `CTRL+N` | New file |
| `CTRL+S` | Save file |
| `CTRL+L` | Load song.mid |
| `CTRL+Q` | Quit |

## 🎼 Example Workflow

### Create a Simple Song

1. **Start Fresh**
   ```
   Press: CTRL+N
   ```

2. **Draw Melody**
   ```
   Press: E (Edit mode)
   Press: 2 (Pencil tool)
   Click in piano roll to add notes
   ```

3. **Adjust Timing**
   ```
   Press: 1 (Select tool)
   Drag to select notes
   ```

4. **Preview**
   ```
   Press: P (Playback mode)
   Press: SPACE to play
   ```

5. **Save**
   ```
   Press: CTRL+S
   ```

## 🎯 Pro Tips

- **Snap to grid:** Use `+/-` to adjust grid size for perfect timing
- **Quick preview:** Switch between Edit (E) and Playback (P) modes
- **Select multiple:** Hold and drag in Select mode (1)
- **Delete fast:** Use Eraser tool (3) instead of selecting and deleting
- **Speed up/slow down:** Use `+/-` in Playback mode to learn songs

## 📚 Learn More

- **Full keyboard shortcuts:** See README.md
- **Advanced features:** See documentation
- **MIDI resources:** freemidi.org, midiworld.com

## 🐛 Common Issues

**"SDL2 not found"**
```bash
sudo apt-get install libsdl2-dev libsdl2-ttf-dev
```

**"Can't see notes"**
- Make sure you're in Edit mode (`E`)
- Select Pencil tool (`2`)
- Click in the center area (piano roll)

**"No playback"**
- Enter Playback mode (`P`)
- Press `SPACE` to start
- Check you have notes in the timeline

## 🎓 Next Steps

1. **Try the test files:**
   ```bash
   python3 create_test_midi.py
   ./piano_editor twinkle_twinkle.mid
   ```

2. **Load a real song:**
   - Download MIDI from freemidi.org
   - `./piano_editor your-song.mid`

3. **Experiment:**
   - Try different grid sizes
   - Use Record mode
   - Combine Pencil and Eraser tools

## 🎹 Keyboard Cheat Sheet

```
┌─────────────────────────────────────┐
│  ESSENTIAL SHORTCUTS                │
├─────────────────────────────────────┤
│  E      Edit mode                   │
│  P      Playback mode               │
│  R      Record mode                 │
│                                     │
│  1      Select tool                 │
│  2      Pencil tool                 │
│  3      Eraser tool                 │
│                                     │
│  SPACE  Play/Pause                  │
│  CTRL+S Save                        │
│  CTRL+L Load                        │
└─────────────────────────────────────┘
```

**Ready? Let's make music! 🎵**

```bash
./piano_editor
```

Press `E`, then `2`, and start clicking to create your first masterpiece!
