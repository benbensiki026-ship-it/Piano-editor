# Contributing to Piano Editor

First off, thank you for considering contributing to Piano Editor! 🎹

## How Can I Contribute?

### 🐛 Reporting Bugs

Before creating bug reports, please check existing issues to avoid duplicates.

**Great bug reports include:**
- Clear, descriptive title
- Exact steps to reproduce
- Expected vs actual behavior
- Screenshots/recordings if applicable
- System info (OS, SDL2 version, compiler)
- MIDI file if related to file loading

**Example:**
```
Title: Notes disappear after selecting and moving

Steps:
1. Load test_song.mid
2. Enter Edit mode (E)
3. Select notes with rectangle
4. Press Delete

Expected: Selected notes should be deleted
Actual: All notes disappear

System: Ubuntu 22.04, SDL2 2.0.20, g++ 11.2
```

### 💡 Suggesting Features

Feature suggestions are welcome! Please include:
- Clear description of the feature
- Why it would be useful
- How it might work
- Any reference implementations

**Example features we'd love:**
- Audio playback (SDL_mixer)
- Copy/paste notes
- Undo/redo system
- Zoom in/out
- Velocity editor
- Multiple tracks
- Export to MP3/WAV
- VST plugin support

### 🔧 Pull Requests

**Process:**

1. **Fork** the repository
2. **Create a branch** from `main`
   ```bash
   git checkout -b feature/amazing-feature
   ```
3. **Make your changes**
   - Follow the coding style
   - Add comments for complex logic
   - Test thoroughly
4. **Commit** with clear messages
   ```bash
   git commit -m "Add velocity editor to piano roll"
   ```
5. **Push** to your fork
   ```bash
   git push origin feature/amazing-feature
   ```
6. **Open a Pull Request**

**Good PR titles:**
- ✅ "Add velocity editor with visual controls"
- ✅ "Fix note selection bug in Edit mode"
- ✅ "Improve MIDI parsing for tempo changes"
- ❌ "Update"
- ❌ "Fix bug"

**PR Description should include:**
- What changes were made
- Why the changes were needed
- How to test the changes
- Screenshots/videos if UI changes
- Related issue numbers (#123)

### 📝 Coding Style

**C++ Guidelines:**
- Use C++17 features
- Follow existing naming conventions
- CamelCase for classes: `PianoEditor`
- camelCase for functions: `renderKeyboard()`
- snake_case for variables: `current_time`
- Clear, descriptive names
- Comment complex algorithms
- Keep functions focused and small

**Code Example:**
```cpp
// Good
void renderPianoRoll() {
    drawGrid();
    drawNotes();
    drawSelectionBox();
}

// Avoid
void render() {
    // 500 lines of mixed rendering code
}
```

**Commit Messages:**
```bash
# Good
git commit -m "Add undo/redo system with command pattern"
git commit -m "Fix memory leak in MIDI parser"
git commit -m "Update README with new keyboard shortcuts"

# Avoid
git commit -m "update"
git commit -m "fix stuff"
git commit -m "asdfasdf"
```

### 🧪 Testing

Before submitting:
- ✅ Compile on your platform without warnings
- ✅ Test all three modes (Playback, Edit, Record)
- ✅ Load and save MIDI files
- ✅ Test with complex MIDI files (1000+ notes)
- ✅ Check for memory leaks (valgrind on Linux)
- ✅ Test keyboard shortcuts

**Manual Testing Checklist:**
```
□ Application launches
□ Can load MIDI file
□ Can save MIDI file
□ Playback mode works
□ Edit mode - can add notes
□ Edit mode - can delete notes
□ Edit mode - can select notes
□ Record mode works
□ Keyboard shortcuts work
□ No crashes or freezes
□ Memory usage is reasonable
```

### 📚 Documentation

Documentation improvements are valuable!

**Areas needing docs:**
- Tutorial videos
- More code examples
- API documentation
- Architecture explanation
- Performance optimization guide

### 🎨 Design Contributions

We welcome:
- UI/UX improvements
- Icons and graphics
- Color scheme suggestions
- Layout improvements
- Accessibility enhancements

## Development Setup

### Quick Setup

```bash
# Clone your fork
git clone https://github.com/YOUR_USERNAME/piano-editor.git
cd piano-editor

# Install dependencies (Ubuntu)
sudo apt-get install libsdl2-dev libsdl2-ttf-dev

# Build
make

# Run
./piano_editor
```

### Project Structure

```
piano-editor/
├── piano_editor.cpp       # Main application code
├── Makefile              # Build configuration
├── build.sh              # Linux/Mac build script
├── build.bat             # Windows build script
├── create_test_midi.py   # Test file generator
├── README.md             # Main documentation
├── QUICKSTART.md         # Quick start guide
├── CONTRIBUTING.md       # This file
├── LICENSE               # MIT License
└── .github/              # GitHub specific files
    └── workflows/        # CI/CD (future)
```

### Code Organization

```cpp
// Main classes
class PianoEditor {
    // Core components
    SDL_Window* window;
    SDL_Renderer* renderer;
    
    // State
    Mode currentMode;
    Tool currentTool;
    std::vector<MIDINote> midiNotes;
    
    // Methods organized by function
    void render();              // Rendering
    void handleInput();         // Input handling
    void loadMIDIFile();        // File operations
    void updateWaterfall();     // Game loop updates
};
```

## Feature Roadmap

### High Priority
- [ ] Audio playback (SDL_mixer)
- [ ] Undo/Redo system
- [ ] Copy/paste notes
- [ ] Zoom in/out
- [ ] Better file dialog

### Medium Priority
- [ ] Velocity editor
- [ ] Multiple tracks
- [ ] Quantize function
- [ ] Metronome
- [ ] Keyboard piano input

### Low Priority
- [ ] VST plugin support
- [ ] Export to audio formats
- [ ] MIDI controller support
- [ ] Themes/skins
- [ ] Tutorial mode

## Questions?

- 💬 Open a discussion on GitHub
- 📧 Create an issue
- 🐦 Tag us on social media (when available)

## Recognition

Contributors will be:
- Listed in README.md
- Credited in release notes
- Given contributor badge
- Mentioned in documentation

## Code of Conduct

### Our Pledge

We are committed to providing a friendly, safe, and welcoming environment for all.

**We do not tolerate:**
- Harassment or discrimination
- Trolling or insulting comments
- Personal or political attacks
- Publishing others' private information

**We encourage:**
- Respectful communication
- Constructive feedback
- Helping newcomers
- Being kind and courteous

### Enforcement

Violations may result in:
1. Warning
2. Temporary ban
3. Permanent ban

Report issues to project maintainers.

## Getting Help

**New to open source?**
- [First Contributions](https://github.com/firstcontributions/first-contributions)
- [How to Contribute to Open Source](https://opensource.guide/how-to-contribute/)

**New to C++?**
- [Learn C++](https://www.learncpp.com/)
- [C++ Reference](https://en.cppreference.com/)

**New to SDL2?**
- [Lazy Foo Tutorials](https://lazyfoo.net/tutorials/SDL/)
- [SDL2 Documentation](https://wiki.libsdl.org/)

## License

By contributing, you agree that your contributions will be licensed under the MIT License.

---

**Thank you for making Piano Editor better! 🎵**

Every contribution, no matter how small, is valued and appreciated.
